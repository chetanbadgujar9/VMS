import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AboutComponent } from './components/aboutme.component';

@NgModule({
  imports: [
    RouterModule.forChild([
      { path: 'aboutMe', component: AboutComponent }
    ])
  ],
  exports: [RouterModule]
})
export class AboutMeRoutingModule { }