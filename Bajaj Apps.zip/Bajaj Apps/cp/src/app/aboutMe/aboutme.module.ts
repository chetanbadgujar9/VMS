import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AboutComponent } from './components/aboutme.component';
import { AboutMeRoutingModule } from './aboutme-routing.module';
import { BrowserModule } from '@angular/platform-browser';
import { SharedModule } from '../shared/shared.module';
//import { DashboardService } from './services/dashboard.service';
@NgModule({
  imports: [CommonModule, AboutMeRoutingModule, SharedModule],
  declarations: [AboutComponent],
  exports: [AboutComponent],
  providers: []
})
export class AboutMeModule { }
