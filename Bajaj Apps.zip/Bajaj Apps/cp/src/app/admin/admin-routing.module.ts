import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CategoryComponent } from './components/category/category.component';
import { ProjectComponent } from './components/project/project.component';
import { GLComponent } from './components/GLApproval/GL.component';
import { RequestCancellationComponent } from './components/RequestCancellation/requestCancel.component';
import { PLComponent } from './components/PLApproval/PL.component';

@NgModule({
  imports: [
    RouterModule.forChild([
      { path: 'category', component: CategoryComponent },
      { path: 'project', component: ProjectComponent },
      { path: 'GL', component: GLComponent },
      { path: 'requestCancellation', component: RequestCancellationComponent },
      { path: 'PL', component: PLComponent }
    ])
  ],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
