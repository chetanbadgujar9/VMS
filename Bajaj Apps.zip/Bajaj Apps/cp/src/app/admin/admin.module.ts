import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProjectComponent } from './components/project/project.component';
import { CategoryComponent } from './components/category/category.component';
import { GLComponent } from './components/GLApproval/GL.component';
import { PLComponent } from './components/PLApproval/PL.component';
import { AdminRoutingModule } from './admin-routing.module';
import { BrowserModule } from '@angular/platform-browser';
import { SharedModule } from '../shared/shared.module';
import { CommonService } from '../shared/services/common.service';
import { RequestCancellationComponent } from './components/RequestCancellation/requestCancel.component';

@NgModule({
    imports: [CommonModule, AdminRoutingModule, SharedModule],
    declarations: [ProjectComponent, CategoryComponent, GLComponent, PLComponent, RequestCancellationComponent],
    exports: [ProjectComponent, CategoryComponent, GLComponent, PLComponent, RequestCancellationComponent],
    providers: [CommonService]
})
export class AdminModule { }
