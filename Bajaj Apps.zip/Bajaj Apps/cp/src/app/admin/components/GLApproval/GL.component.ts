import { Component, OnInit, NgModule, trigger, transition, style, animate, state, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { MessageService } from '../../../shared/services/message.service';
import { CommonService } from '../../../shared/services/common.service';
import { ConfirmationService } from 'primeng/primeng';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SelectItem } from 'primeng/primeng';
import { DashboardService } from '../../../dashboard/services/dashboard.service';
import { Brand } from '../../model/brand';
import { Cashmodel } from '../../../dashboard/models/cashmodel';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-gl',
    templateUrl: 'GL.component.html',
    styleUrls: ['GL.component.css'],
    providers: [ConfirmationService]
})
export class GLComponent implements OnInit {
    cashpurchaseData: any[];
    errorMessage: string;
    showVehicleForm: boolean = false;
    VehicleForm: FormGroup;
    Id: any = '';
    errorFlag: boolean = false;
    display: boolean = false;
    requestID: any;
    @Output() dashboardFlag = new EventEmitter();
    constructor(private _messageService: MessageService,
        private _commonService: CommonService,
        private _confirmationService: ConfirmationService,
        private formBuilder: FormBuilder,
        private _dashboardService: DashboardService) {
    }
    ngOnInit() {
        this.getGLPendingRequests('pending');
    }
    getGLPendingRequests(status: any) {
        this.cashpurchaseData = [];
        this._dashboardService.getAllGLPendingRequests()
            .subscribe(
            (results: any) => {
                if (results.length > 0) {
                    this.cashpurchaseData = results;
                }
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onCancelCashPurchaseRequest(request: Cashmodel) {
        this.display = true;
        this.requestID = request.ID;
    }
    CancelRequest() {
        this._dashboardService.cancelCashPurchaseRequest(this.requestID)
            .subscribe(
            (results: any) => {
                this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                this.getGLPendingRequests('pending');
                this.display = false;
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onApproveRequest(request: Cashmodel) {
        let payload = { 'ID': request.ID, 'Status': 'Approved', 'GLComments': 'Approved By Admin' };
        this._dashboardService.approveGLRequestByAdmin(payload)
            .subscribe(
            (results: any) => {
                this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                this.getGLPendingRequests('pending');
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onRejectRequest(request: Cashmodel) {
        let payload = { 'ID': request.ID, 'Status': 'Rejected', 'GLComments': 'Rejected By Admin' };
        this._dashboardService.approveGLRequestByAdmin(payload)
            .subscribe(
            (results: any) => {
                this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                this.getGLPendingRequests('pending');
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
}
