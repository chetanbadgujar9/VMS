import { Component, OnInit, NgModule, trigger, transition, style, animate, state, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { MessageService } from '../../../shared/services/message.service';
import { CommonService } from '../../../shared/services/common.service';
import { ConfirmationService } from 'primeng/primeng';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SelectItem } from 'primeng/primeng';
import { Vehicle } from '../../model/vehicle';
import { DashboardService } from '../../../dashboard/services/dashboard.service';
import { Cashmodel } from '../../../dashboard/models/cashmodel';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-pl',
    templateUrl: 'PL.component.html',
    styleUrls: ['PL.component.css'],
    providers: [ConfirmationService]
})
export class PLComponent implements OnInit {
    cashpurchaseData: any[];
    errorMessage: string;
    showVehicleForm: boolean = false;
    VehicleForm: FormGroup;
    Id: any = '';
    errorFlag: boolean = false;
    display: boolean = false;
    requestID: any;
    @Output() dashboardFlag = new EventEmitter();
    constructor(private _messageService: MessageService,
        private _commonService: CommonService,
        private _confirmationService: ConfirmationService,
        private formBuilder: FormBuilder,
        private _dashboardService: DashboardService) {
    }
    ngOnInit() {
        this.getPLPendingRequests('pending');
    }
    getPLPendingRequests(status: any) {
        this.cashpurchaseData = [];
        this._dashboardService.getAllPLPendingRequests()
            .subscribe(
            (results: any) => {
                if (results.length > 0) {
                    this.cashpurchaseData = results;
                }
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onCancelCashPurchaseRequest(request: Cashmodel) {
        this.display = true;
        this.requestID = request.ID;
    }
    CancelRequest() {
        this._dashboardService.cancelCashPurchaseRequest(this.requestID)
            .subscribe(
            (results: any) => {
                this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                this.getPLPendingRequests('pending');
                this.display = false;
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onApproveRequest(request: Cashmodel) {
        let payload = { 'ID': request.ID, 'Status': 'Approved', 'PLComments': 'Approved By Admin' };
        this._dashboardService.approvePLRequestByAdmin(payload)
            .subscribe(
            (results: any) => {
                this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                this.getPLPendingRequests('pending');
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onRejectRequest(request: Cashmodel) {
        let payload = { 'ID': request.ID, 'Status': 'Rejected', 'PLComments': 'Rejected By Admin' };
        this._dashboardService.approvePLRequestByAdmin(payload)
            .subscribe(
            (results: any) => {
                this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                this.getPLPendingRequests('pending');
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
}
