import { Component, OnInit, NgModule, trigger, transition, style, animate, state, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { MessageService } from '../../../shared/services/message.service';
import { CommonService } from '../../../shared/services/common.service';
import { ConfirmationService } from 'primeng/primeng';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SelectItem } from 'primeng/primeng';
import { Canteen } from '../../model/canteen';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-project',
    templateUrl: 'project.component.html',
    styleUrls: ['project.component.css'],
    providers: [ConfirmationService]
})
export class ProjectComponent implements OnInit {
    projectData: any[];
    errorMessage: string;
    showAddProjectFrom: boolean = false;
    AddProjectForm: FormGroup;
    Id: any = '';
    errorFlagForAddForm: boolean = false;
    maxlength: any = 100;
    title: any;
    characterleft: any;
    @Output() dashboardFlag = new EventEmitter();
    constructor(private _messageService: MessageService,
        private _commonService: CommonService,
        private _confirmationService: ConfirmationService,
        private formBuilder: FormBuilder) {
    }
    ngOnInit() {
        this.characterleft = this.maxlength;
        this.setForm();
        this.getProjectList();
    }
    setForm() {
        this.AddProjectForm = this.formBuilder.group({
            Title: ['', [Validators.required]],
            Status: ['Active', [Validators.required]]
        });
    }
    onAddProject() {
        this.Id = '';
        this.characterleft = 100;
        this.title = '';
        this.setForm();
        this.showAddProjectFrom = true;
        this.errorFlagForAddForm = false;
    }
    onCancelForm() {
        this.errorFlagForAddForm = false;
        this.characterleft = 100;
        this.showAddProjectFrom = false;
    }
    getProjectList() {
        this._commonService.getAllProject()
            .subscribe(
            (results: any) => {
                this.projectData = results;
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });

            });
    }
    countChars(Title: any) {
        if (this.maxlength >= Title.length) {
            this.characterleft = (this.maxlength) - (Title.length);
        } else {
            this.title = Title.substr(0, Title.length - 1);
        }
    }
    onEdit(project: any) {
        this.showAddProjectFrom = true;
        this.Id = project.ID;
        this.title = project.Title;
        this.AddProjectForm.setValue({
            Title: project.Title,
            Status: project.Status
        });
    }
    onSubmit({ value, valid }: { value: any, valid: boolean }) {
        if (valid) {
            value.Title = value.Title ? value.Title.replace(/'/g, "\\'").trim() : '';
            if (this.Id === '') {
                this._commonService.addProject(value)
                    .subscribe(
                    (results: any) => {
                        this.Id = '';
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getProjectList();
                        this.showAddProjectFrom = false;
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
            if (this.Id !== '') {
                value.ID = this.Id;
                this._commonService.updateProject(value)
                    .subscribe(
                    (results: any) => {
                        this.Id = '';
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getProjectList();
                        this.showAddProjectFrom = false;
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }

        } else {
            this.errorFlagForAddForm = true;
        }

    }
}
