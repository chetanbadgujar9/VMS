export class Brand {
    constructor(
        public ID: string,
        public Project: string,
        public Title: string
    ) { }
}