export class Canteen {
    constructor(
        public ID: string,
        public Title: string
    ) { }
}