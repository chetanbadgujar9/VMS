export class PlantHead {
    constructor(
        public ID: string,
        public Title: string,
        public Head: {
            "Name": string,
            "ID": string
        }
    ) { }
}