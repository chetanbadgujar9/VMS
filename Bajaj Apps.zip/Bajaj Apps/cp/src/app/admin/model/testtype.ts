export class Testtype {
    constructor(
        public ID: string,
        public TestType: string,
        public TestSubType  : string,
        public OwnerName : string,
        public OwnerEmail:string
    ) { }
}