export class Vehicle {
    constructor(
        public ID: string,
        public Model: string
    ) { }
}