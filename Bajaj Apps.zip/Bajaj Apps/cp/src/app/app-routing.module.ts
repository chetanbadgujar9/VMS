import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/index';
import { AboutComponent } from './aboutMe/components/aboutme.component';
import { CategoryComponent, GLComponent, PLComponent, ProjectComponent, RequestCancellationComponent } from './admin/index';
import { UnAuthorizedComponent } from './unAuthorized/components/unauthorized.component';
import { ViewComponent } from './view/components/view.component';
import { VoucherComponent } from './voucher/components/voucher.component';

const routes: Routes = [
  { path: 'project', component: ProjectComponent },
  { path: 'category', component: CategoryComponent },
  { path: 'PL', component: PLComponent },
  { path: 'GL', component: GLComponent },
  { path: 'requestCancellation', component: RequestCancellationComponent },
  { path: 'voucher', component: VoucherComponent },
  { path: 'aboutMe', component: AboutComponent },
  { path: 'unauthorized/:id', component: UnAuthorizedComponent },
  { path: 'view/:id', component: ViewComponent },
  { path: 'dashboard', component: DashboardComponent, pathMatch: 'full' },
  { path: 'dashboard', component: DashboardComponent, pathMatch: 'full' },
  { path: '**', component: DashboardComponent },
  { path: 'CashPurchase/dist', redirectTo: 'dashboard', pathMatch: 'full' }
];

@NgModule({
  imports: [
    RouterModule.forRoot(
      routes
    )
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }

