import { Component, OnInit } from '@angular/core';
import { Message } from 'primeng/primeng';
import { MessageService } from './shared/services/message.service';


@Component({
  moduleId: module.id,
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  implements OnInit {
  title = 'app';
  cars: any[] = [];
  msgs: Message[] = [];
  constructor(private _messageService: MessageService) {
    // console.log('Environment config', Config);
  }
  ngOnInit() {
    this._messageService.getMessages()
      .subscribe((value: Object) => {
        this.msgs = [];
        this.msgs.push(value);
      });
  }
}
