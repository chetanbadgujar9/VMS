import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Cashmodel } from '../models/cashmodel';
import { Searchmodel } from '../models/searchmodel';
import { MessageService } from '../../shared/services/message.service';
import { CommonService } from '../../shared/services/common.service';
import { DashboardService } from '../services/dashboard.service';
import { ConfirmationService } from 'primeng/primeng';
import { AuthInfo } from '../models/authInfo';
import { User } from '../models/loginUser';
/**
 * This class represents the lazy loaded AboutComponent.
 */
declare var saveAs: any;
@Component({
  moduleId: module.id,
  selector: 'sd-dashboard',
  templateUrl: 'dashboard.component.html',
  styleUrls: ['dashboard.component.css'],
  providers: [ConfirmationService]
})
export class DashboardComponent implements OnInit {
  cars: any[] = [];
  projectData: any[];
  categoryData: any[];
  cashpurchaseData: any[];
  counterData: any[];
  rmsMenu: any[];
  attachmentURL: any = {};

  /** Form Variables */
  searchForm: FormGroup;
  AddRequestForm: FormGroup;
  ApprovedRequestForm: FormGroup;
  ApproveRejectRequestForm: FormGroup;

  /** Flags Variables */
  showCashPurchaseFrom: boolean = false;
  errorFlagForAddForm: boolean = false;
  showSearchRequestForm: boolean = false;
  errorFlagForSearchForm: boolean = false;
  errorFlagForApproveForm: boolean = false;
  showApprovedCashPurchaseFrom: boolean = false;
  showCashPurchaseApproveRejectFrom: boolean = false;
  errorFlagForApproveRejectForm: boolean = false;
  onSearchClickToShowAction: boolean = false;
  checkAmountFlag: boolean = false;
  projectErr: boolean = false;
  ApproveButton: boolean = false;
  RejectButton: boolean = false;
  AttachmentURL: boolean = false;
  display: boolean = false;
  IsGLApproved: boolean = true;
  showPrint: boolean = false;
  Approval1: boolean;
  Approval2: boolean;
  isAdvanceBeforePurchase: boolean;
  requestID: any;

  /** Model Variables */
  val2: any = 'Claim';
  model: AuthInfo;
  loggedInUserData: User = new User();

  /**Character Counts variables */
  characterleftRT: any;
  characterleftMD: any;
  characterleftQ: any;
  maxlength: any = 250;
  requesttitle: any;
  quantity: any;
  desc: any;

  /**Genaral Variables */
  loggedInUser: string;
  loginName: string = '';
  status: any = 'Pending';
  headingColor: any = 'orange';
  invoiceDate: Date = new Date();
  filesDataForReceipt: any;
  filesDataForGatePass: any;
  fileUploaded: boolean = false;
  fileName: string;
  receiptName: string;
  gatePassName: string;
  checked: boolean;
  disabledGatepass: boolean = false;
  errorMessage: string;
  loggedInUserRole: any;
  binaryFileToDownload: string;
  loggedInUserGroup: string;
  invoiceamount: '';
  amount: number;
  requesttype: any;
  minDate: Date;
  loggedInUserName: string;
  platformLeaderName: string;
  CPCreatedBy: string;

  constructor(private formBuilder: FormBuilder, private _messageService: MessageService,
    private _commonService: CommonService, private _router: Router, private _confirmationService: ConfirmationService,
    private _dashboardService: DashboardService) {
    this.filesDataForReceipt = new Array<File>();
    this.filesDataForGatePass = new Array<File>();
    this.model = new AuthInfo('password', '', '');
    this.attachmentURL = {
      'FileName': '',
      'ServerRelativeUrl': ''
    };
  }
  ngOnInit() {
    this.characterleftMD = this.characterleftQ = this.characterleftRT = this.maxlength;
    // this.loginName = 'tcctest3';
    // this.loggedInUser = 'tcctest3';
    this.loginName = sessionStorage.getItem('Username') ? sessionStorage.getItem('Username').split('\\')[1] : '';
    this.loggedInUser = sessionStorage.getItem('UserTitle') ? sessionStorage.getItem('UserTitle') : '';
    this.setAddForm();
    this.setSearchForm();
    this.setApproveForm();
    this.setApproveRejectRequestForm();
    if (sessionStorage.getItem('access_token') === null) {
      this.getAuthToken();
    } else {
      this.loggedInUserData = JSON.parse(sessionStorage.getItem('loggedInUserData'));
      this.loggedInUserRole = this.loggedInUserData ? this.loggedInUserData.Role2 : '';
      this.loggedInUserGroup = this.loggedInUserData ? this.loggedInUserData.Group : '';
      this.loggedInUserName = this.loggedInUserData ? this.loggedInUserData.domainid.UserName : '';
      this.getRMSMenus();
      this.getAdminAccess(this.loginName);
      this._messageService.AddUserRole(this.loggedInUserRole);
      if (this.loggedInUserRole !== '') {
        if (sessionStorage.getItem('Status') === null) {
          sessionStorage.removeItem('Status');
          this.onPending();
        }
        else if (sessionStorage.getItem('Status') !== null) {
          if (sessionStorage.getItem('Status') === 'Closed') {
            sessionStorage.removeItem('Status');
            this.onClosed();
            if (this.loggedInUserRole.toLowerCase() === 'engineer') {
              this.getRequesterCounters();
            }
            if (this.loggedInUserRole.toLowerCase() === 'group leader') {
              this.getGLCounters();
            }
            if (this.loggedInUserRole.toLowerCase() === 'platform leader') {
              this.getL1Counters();
            }
          }
          if (sessionStorage.getItem('Status') === 'Approved') {
            sessionStorage.removeItem('Status');
            this.onApproved();
            if (this.loggedInUserRole.toLowerCase() === 'engineer') {
              this.getRequesterCounters();
            }
            if (this.loggedInUserRole.toLowerCase() === 'group leader') {
              this.getGLCounters();
            }
            if (this.loggedInUserRole.toLowerCase() === 'platform leader') {
              this.getL1Counters();
            }
          }
        }
      }
      else {
        this._router.navigate(['/unauthorized',
          'You are not Authorized to access this site due to UGP mapping does not exist. Please contact Ahead portal support team.']);
      }
    }
  }
  /** Get Auth Token */
  getAuthToken() {
    this.model.UserName = this.loginName;
    this.model.Password = '';
    this._commonService.getAuthToken(this.model)
      .subscribe(
      (results: any) => {
        this.getRMSMenus();
        this.getLoggedInUserDetails();
        this.getAdminAccess(this.loginName);
      },
      error => {
        this.errorMessage = <any>error;
        this._router.navigate(['/unauthorized',
          'You are not Authorized to access this site due to UGP mapping does not exist. Please contact Ahead portal support team.']);
      });
  }
  getLoggedInUserDetails() {
    this._commonService.getLoggedInUserDetails(this.loggedInUser)
      .subscribe(
      (results: any) => {
        if (Object.keys(results).length !== 0) {
          this.loggedInUserData = results;
          this.loggedInUserRole = this.loggedInUserData ? this.loggedInUserData.Role2 : '';
          this.loggedInUserGroup = this.loggedInUserData ? this.loggedInUserData.Group : '';
          this.loggedInUserName = this.loggedInUserData ? this.loggedInUserData.domainid.UserName : '';
          this._messageService.AddUserRole(this.loggedInUserRole);
          sessionStorage.setItem('loggedInUserName', JSON.stringify(results.UserLookup));
          sessionStorage.setItem('loggedInUserData', JSON.stringify(results));
          this.onPending();
        } else {
          this._router.navigate(['/unauthorized',
            'You are not Authorized to access this site due to UGP mapping does not exist. Please contact Ahead portal support team.']);
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  /** Get Admin Access*/
  getAdminAccess(username: any) {
    this._commonService.getAdminAccess(username)
      .subscribe((results: any) => {
        if (Object.keys(results).length !== 0) {
          this._messageService.AddAdminAccess(true);
        }
      });
  }
  getRMSMenus() {
    this._commonService.getRMSMenus()
      .subscribe(
      (results: any) => {
        this.rmsMenu = results;
        this._messageService.AddRMSMenu(this.rmsMenu);
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  /** Set Values to form Data */
  setAddForm() {
    this.AddRequestForm = this.formBuilder.group({
      RequestTitle: ['', [Validators.required]],
      Group: [this.loggedInUserGroup, [Validators.required]],
      RequestType: ['Claim'],
      Project: [''],
      Category: ['', [Validators.required]],
      MaterialDescription: ['', [Validators.required]],
      Quantity: ['', [Validators.required]],
      Amount: ['', [Validators.required]],
      Purpose: ['', [Validators.required]],
      Comments: ['', [Validators.required]]
    });
  }
  setSearchForm() {
    this.searchForm = this.formBuilder.group({
      fieldName: ['ID', [Validators.required]],
      fieldValue: ['', [Validators.required]]
    });
  }
  setApproveForm() {
    this.ApprovedRequestForm = this.formBuilder.group({
      RequestTitle: [''],
      Group: [this.loggedInUserGroup],
      RequestType: [''],
      Project: [''],
      Category: [''],
      MaterialDescription: [''],
      Quantity: [''],
      Amount: [''],
      Purpose: [''],
      Comments: [''],
      GLComments: [''],
      InvoiceDate: [''],
      InvoiceNumber: ['', [Validators.required]],
      InvoiceAmount: ['', [Validators.required]],
      OctoriAmount: ['', [Validators.required]],
      ReceiptAndGatepass: [''],
      ReceiptName: ['', [Validators.required]],
      GatePassName: [''],
      Remarks: ['', [Validators.required]]
    });
  }
  setApproveRejectRequestForm() {
    this.ApproveRejectRequestForm = this.formBuilder.group({
      RequestTitle: [''],
      Group: [this.loggedInUserGroup],
      RequestType: [''],
      Project: [''],
      Category: ['ABC'],
      MaterialDescription: [''],
      Quantity: [''],
      Amount: [''],
      Purpose: [''],
      Comments: [''],
      GLComments: ['', [Validators.required]],
      PLComments: ['', [Validators.required]],
    });
  }
  onCreateRequest() {
    this.showSearchRequestForm = false;
    this.showApprovedCashPurchaseFrom = false;
    this.showCashPurchaseApproveRejectFrom = false;
    this.projectErr = false;
    //this.onSearchClickToShowAction = false;
    this.characterleftMD = this.characterleftQ = this.characterleftRT = 250;
    this.quantity = '';
    this.desc = '';
    this.requesttitle = '';
    this.showCashPurchaseFrom = true;
    this.errorFlagForAddForm = false;
    this.getProjectMaster();
    this.getCategoryMaster();
    this.setAddForm();
  }
  onSearch() {
    this.showSearchRequestForm = true;
    this.showCashPurchaseFrom = false;
    this.showApprovedCashPurchaseFrom = false;
    this.showCashPurchaseApproveRejectFrom = false;
    this.errorFlagForSearchForm = false;
    this.setSearchForm();
  }

  /** Get master data */
  getProjectMaster() {
    this._commonService.getProjectMaster()
      .subscribe(
      (results: any) => {
        this.projectData = results;
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getCategoryMaster() {
    this._commonService.getCategoryMaster()
      .subscribe(
      (results: any) => {
        this.categoryData = results;
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }


  /**On Counter Click */
  onPending() {
    this.status = 'Pending';
    this.headingColor = 'orange';
    this.showApprovedCashPurchaseFrom = false;
    this.showCashPurchaseApproveRejectFrom = false;
    this.showCashPurchaseFrom = false;
    this.showSearchRequestForm = false;
    //this.onSearchClickToShowAction = false;
    if (this.loggedInUserRole.toLowerCase() === 'engineer') {
      this.getPendingRequest_Engg('pending');
      this.getRequesterCounters();
    }
    if (this.loggedInUserRole.toLowerCase() === 'group leader') {
      this.getPendingRequest_GL('pending');
      this.getGLCounters();
    }
    if (this.loggedInUserRole.toLowerCase() === 'platform leader') {
      this.getPendingRequest_L1('pending');
      this.getL1Counters();
    }
  }
  onApproved() {
    this.status = 'Approved';
    this.headingColor = 'green';
    this.showApprovedCashPurchaseFrom = false;
    this.showCashPurchaseApproveRejectFrom = false;
    this.showCashPurchaseFrom = false;
    this.showSearchRequestForm = false;
    //this.onSearchClickToShowAction = false;
    if (this.loggedInUserRole.toLowerCase() === 'engineer') {
      this.getPendingRequest_Engg('approved');
    }
    if (this.loggedInUserRole.toLowerCase() === 'group leader') {
      this.getPendingRequest_GL('approved');
    }
    if (this.loggedInUserRole.toLowerCase() === 'platform leader') {
      this.getPendingRequest_L1('approved');
    }
  }
  onRejected() {
    this.status = 'Rejected';
    this.headingColor = 'red';
    this.showApprovedCashPurchaseFrom = false;
    this.showCashPurchaseApproveRejectFrom = false;
    this.showCashPurchaseFrom = false;
    this.showSearchRequestForm = false;
    //this.onSearchClickToShowAction = false;
    if (this.loggedInUserRole.toLowerCase() === 'engineer') {
      this.getPendingRequest_Engg('rejected');
    }
    if (this.loggedInUserRole.toLowerCase() === 'group leader') {
      this.getPendingRequest_GL('rejected');
    }
    if (this.loggedInUserRole.toLowerCase() === 'platform leader') {
      this.getPendingRequest_L1('rejected');
    }
  }
  onClosed() {
    this.status = 'Closed';
    this.headingColor = '#26c6da';
    this.showApprovedCashPurchaseFrom = false;
    this.showCashPurchaseApproveRejectFrom = false;
    this.showCashPurchaseFrom = false;
    this.showSearchRequestForm = false;
    //this.onSearchClickToShowAction = false;
    if (this.loggedInUserRole.toLowerCase() === 'engineer') {
      this.getPendingRequest_Engg('closed');
    }
    if (this.loggedInUserRole.toLowerCase() === 'group leader') {
      this.getPendingRequest_GL('closed');
    }
    if (this.loggedInUserRole.toLowerCase() === 'platform leader') {
      this.getPendingRequest_L1('closed');
    }
  }
  /**Get Couters data */
  getPendingRequest_Engg(status: any) {
    this.cashpurchaseData = [];
    this._dashboardService.getPendingRequest_Engg(status)
      .subscribe(
      (results: any) => {
        if (results.length > 0) {
          this.cashpurchaseData = results;
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getRequesterCounters() {
    this._dashboardService.getRequesterCounters()
      .subscribe(
      (results: any) => {
        this.counterData = results;
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getPendingRequest_GL(status: any) {
    this.cashpurchaseData = [];
    this._dashboardService.getPendingRequest_GL(status)
      .subscribe(
      (results: any) => {
        if (results.length > 0) {
          this.cashpurchaseData = results;
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getGLCounters() {
    this._dashboardService.getGLCounters()
      .subscribe(
      (results: any) => {
        this.counterData = results;
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getPendingRequest_L1(status: any) {
    this.cashpurchaseData = [];
    this._dashboardService.getPendingRequest_L1(status)
      .subscribe(
      (results: any) => {
        if (results.length > 0) {
          this.cashpurchaseData = results;
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getL1Counters() {
    this._dashboardService.getL1Counters()
      .subscribe(
      (results: any) => {
        this.counterData = results;
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  /** General Functions */
  countChars(model: any, from: any) {
    if (this.maxlength >= model.length) {
      switch (from) {
        case 'RequestTitle': this.characterleftRT = (this.maxlength) - (model.length);
          break;
        case 'Description': this.characterleftMD = (this.maxlength) - (model.length);
          break;
        case 'Quantity': this.characterleftQ = (this.maxlength) - (model.length);
          break;
      }

    } else {
      switch (from) {
        case 'RequestTitle': this.requesttitle = model.substr(0, model.length - 1);
          break;
        case 'Description': this.desc = model.substr(0, model.length - 1);
          break;
        case 'Quantity': this.quantity = model.substr(0, model.length - 1);
          break;
      }

    }
  }
  onInvoiceDate(event: any) {
    this.invoiceDate = event;
  }
  checkInvoiceAmount(invoiceamount: number) {
    if (invoiceamount !== undefined) {
      if (invoiceamount > this.amount && this.requesttype === 'Claim') {
        document.getElementById('invoiceamount').hidden = false;
        document.getElementById('invoiceamount').innerHTML = 'Invoice Amount should not be greater than Amount i.e ' + this.amount;
      }
      else {
        document.getElementById('invoiceamount').hidden = true;
      }
    }
  }
  disabledSelect(request: Cashmodel) {
    if ((this.status === 'Approved') && (request.CPCreatedBy.toLowerCase() === this.loggedInUser.toLowerCase())) {
      return true;
    }
    else {
      return false;
    }
  }
  printAdvance() {
    sessionStorage.setItem('Status', 'Approved');
    this._router.navigate(['/view', this.requestID]);
  }
  onViewRequest(request: Cashmodel) {
    sessionStorage.setItem('Status', 'Closed');
    this._router.navigate(['/view', request.ID]);
  }
  onSelectRequest(request: Cashmodel) {
    this.showCashPurchaseApproveRejectFrom = false;
    this.showApprovedCashPurchaseFrom = false;
    this.showCashPurchaseFrom = false;
    this.showSearchRequestForm = false;
    this.requestID = request.ID;
    this.CPCreatedBy = request.CPCreatedBy;
    this.invoiceamount = '';
    this._dashboardService.getRequestByID(request.ID)
      .subscribe(
      (results: Cashmodel) => {
        if (Object.keys(results).length !== 0) {
          this.Approval1 = results.Approval1;
          this.Approval2 = results.Approval2;
          this.isAdvanceBeforePurchase = results.isAdvanceBeforePurchase;
          this.platformLeaderName = results.PlatformLeader ? results.PlatformLeader : '';
          this.showPrint = results.AdvanceAmount !== null ? true : false;
          if (results.GLComments === null) {
            this.IsGLApproved = false;
          }
          if (this.status === 'Pending') {
            this.showCashPurchaseApproveRejectFrom = true;
            this.ApproveRejectRequestForm = this.formBuilder.group({
              RequestTitle: results.RequestTitle,
              Group: this.loggedInUserGroup,
              RequestType: results.AdvanceAmount !== null ? 'Advance' : 'Claim',
              Project: results.Project,
              Category: results.Category,
              MaterialDescription: results.MaterialDescription,
              Quantity: results.Quantity,
              Amount: results.Amount,
              Purpose: results.Purpose,
              Comments: results.Comments,
              GLComments: '',
              PLComments: ''
            });
          }
          if (this.status === 'Approved') {
            this.showApprovedCashPurchaseFrom = true;
            this.receiptName = '';
            this.gatePassName = '';
            this.amount = results.Amount;
            this.requesttype = results.AdvanceAmount !== null ? 'Advance' : 'Claim';
            this.minDate = results.ApprovedOn2 !== null ? new Date(results.ApprovedOn2) : new Date(results.ApprovedOn);
            this.ApprovedRequestForm.setValue({
              RequestTitle: results.RequestTitle,
              Group: this.loggedInUserGroup,
              RequestType: results.AdvanceAmount !== null ? 'Advance' : 'Claim',
              Project: results.Project,
              Category: results.Category,
              MaterialDescription: results.MaterialDescription,
              Quantity: results.Quantity,
              Amount: results.Amount,
              Purpose: results.Purpose,
              Comments: results.Comments,
              GLComments: results.GLComments,
              InvoiceDate: results.ApprovedOn2 !== null ? this.formatDate(results.ApprovedOn2) : this.formatDate(results.ApprovedOn),
              InvoiceNumber: '',
              InvoiceAmount: '',
              OctoriAmount: '',
              ReceiptAndGatepass: false,
              ReceiptName: '',
              GatePassName: '',
              Remarks: '',
            });
          }
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  postFile(inputValue: any, type: string): void {
    var format = /[!@#$%^&*+\=\[\]{};':'\\|,.<>\/?]+/;
    try {
      let FileList: FileList = inputValue.target.files;
      if (FileList.length > 0) {
        if (inputValue.target.files[0].size < 10000000) {
          if (inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'docx' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'doc' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'xls' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'xlsx' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'tif' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'tiff' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'gif' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'jpeg' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'jpg' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'png' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'pdf' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'ppt' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'pptx' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'zip') {
            if (!format.test(inputValue.target.files[0].name.split('.')[0])) {
              if (type === 'Receipt') {
                this.filesDataForReceipt.length = 0;
                for (let i = 0, length = FileList.length; i < length; i++) {
                  this.filesDataForReceipt.push(FileList.item(i));
                  this.fileUploaded = true;
                  this.fileName = FileList.item(i).name;
                  this.receiptName = this.fileName;
                  //this.AttachmentURL = true;
                }
              }
              if (type === 'GatePass') {
                this.filesDataForGatePass.length = 0;
                for (let i = 0, length = FileList.length; i < length; i++) {
                  this.filesDataForGatePass.push(FileList.item(i));
                  this.fileUploaded = true;
                  this.fileName = FileList.item(i).name;
                  this.gatePassName = this.fileName;
                  //this.AttachmentURL = true;
                }
              }
            } else {
              this._messageService.addMessage({
                severity: 'error', summary: 'Error Message',
                detail: 'Please remove special characters from filename'
              });
            }
          } else {
            this._messageService.addMessage({
              severity: 'error', summary: 'Error Message',
              detail: 'Please upload document of type of supperted type'
            });
          }
        } else {
          this._messageService.addMessage({
            severity: 'error', summary: 'Error Message',
            detail: 'Please upload document of size less than 2 MB'
          });
        }
      } else {
        // this.AttachmentURL = false;
        this.receiptName = '';
      }
    } catch (error) {
      document.write(error);
    }

  }
  onCheckBox(check: boolean) {
    if (check) {
      this.disabledGatepass = true;
    }
    if (!check) {
      this.disabledGatepass = false;
    }
  }
  downloadFile(cashpurchase: Cashmodel) {
    this.attachmentURL.FileName = cashpurchase.FileName;
    this.attachmentURL.ServerRelativeUrl = cashpurchase.ServerRelativeUrl;
    this.onDownloadFile();
  }
  onDownloadFile() {
    this._dashboardService.getDownloadedFile(this.attachmentURL.ServerRelativeUrl)
      .subscribe(
      results => {
        this.binaryFileToDownload = <any>results;
        if (this.binaryFileToDownload) {
          this.Download(this.binaryFileToDownload, this.attachmentURL.ServerRelativeUrl, this.attachmentURL.FileName);
        } else { this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: 'File Not Found' }); }
      },
      error => this.errorMessage = <any>error);
  }
  Download(binaryResume: string, attachmentURL: string, FileName: string) {
    let extension;
    let fileName;
    if (FileName !== null) {
      extension = FileName.split('.')[1] ? FileName.split('.')[1] : 'CashPurchaseExt';
      fileName = FileName.split('.')[0] ? FileName.split('.')[0] : 'CashPurchaseFile';
    }
    //var link = document.createElement('a');
    //link.download = fileName;
    var byteCharacters = atob(binaryResume);
    var byteNumbers = new Array(byteCharacters.length);
    for (var i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    var byteArray = new Uint8Array(byteNumbers);

    switch (extension.toLowerCase()) {
      case 'pdf': var blob1 = new Blob([byteArray], { type: "application/pdf;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:application/pdf;charset=utf-8;base64,' + binaryResume;
        break;
      case 'xls': var blob1 = new Blob([byteArray], { type: "application/vnd.ms-excel;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:application/vnd.ms-excel;charset=utf-8;base64,' + binaryResume;
        break;
      case 'xlsx': var blob1 = new Blob([byteArray], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8;base64,' + binaryResume;
        break;
      case 'tif': var blob1 = new Blob([byteArray], { type: "image/tiff;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:image/tiff;charset=utf-8;base64,' + binaryResume;
        break;
      case 'tiff': var blob1 = new Blob([byteArray], { type: "image/tiff;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:image/tiff;charset=utf-8;base64,' + binaryResume;
        break;
      case 'gif': var blob1 = new Blob([byteArray], { type: "image/GIF;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:image/GIF;charset=utf-8;base64,' + binaryResume;
        break;
      case 'jpeg': var blob1 = new Blob([byteArray], { type: "image/jpeg;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:image/jpeg;charset=utf-8;base64,' + binaryResume;
        break;
      case 'jpg': var blob1 = new Blob([byteArray], { type: "image/jpeg;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:image/jpeg;charset=utf-8;base64,' + binaryResume;
        break;
      case 'png': var blob1 = new Blob([byteArray], { type: "image/png,charset=utf-8" });
        new saveAs(blob1, fileName + '.' + extension);
        //link.href = 'data:image/png;charset=utf-8;base64,' + binaryResume;
        break;
      case 'ppt': var blob1 = new Blob([byteArray], { type: "application/vnd.ms-powerpoint;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:application/vnd.ms-powerpoint;charset=utf-8;base64,' + binaryResume;
        break;
      case 'pptx': var blob1 = new Blob([byteArray], { type: "application/vnd.openxmlformats-officedocument.presentationml.presentation;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:application/vnd.openxmlformats-officedocument.presentationml.presentation;charset=utf-8;base64,' + binaryResume;
        break;
      case 'doc':
        var blob1 = new Blob([byteArray], { type: "application/msword;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        // link.href = 'data:application/msword;charset=utf-8;base64,' + binaryResume;
        break;
      case 'docx':
        var blob1 = new Blob([byteArray], { type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document;charset=utf-8;base64" });
        window.navigator.msSaveBlob(blob1, fileName + '.' + extension);
        // link.href = 'data:application/vnd.openxmlformats-officedocument.wordprocessingml.document;charset=utf-8;base64,' + binaryResume;
        break;
      case 'zip': var blob1 = new Blob([byteArray], { type: "application/zip;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        // link.href = 'data:application/zip;charset=utf-8;base64,' + binaryResume;
        break;
      default: // link.href = 'data:application/force-download;charset=utf-8;base64,' + binaryResume;
        break;
    }
    // document.body.appendChild(link);
    // link.click();
  }
  /**Submit Form */
  onSubmitRequest({ value, valid }: { value: Cashmodel, valid: boolean }) {
    if (valid) {
      if (value.RequestType === 'Claim') {
        value.ClaimAmount = value.Amount.toString();
      }
      if (value.RequestType === 'Advance') {
        value.AdvanceAmount = value.Amount.toString();
      }
      if (value.OctoriAmount !== undefined) {
        if (!this.isInteger(value.OctoriAmount.toString())) {
          this.errorMessage = 'Only Whole numbers are allowed for Statutary field';
          this._messageService.addMessage({ severity: 'error', summary: 'Success Message', detail: this.errorMessage });
          return;
        }
      }
      if (value.Amount !== undefined) {
        if (!this.isInteger(value.Amount.toString())) {
          this.errorMessage = 'Only Whole numbers are allowed for Amount field';
          this._messageService.addMessage({ severity: 'error', summary: 'Success Message', detail: this.errorMessage });
          return;
        }
      }
      value.CPCreatedBy = this.loggedInUser;
      value.RequestTitle = value.RequestTitle ? value.RequestTitle.replace(/'/g, "\\'").trim() : '';
      value.MaterialDescription = value.MaterialDescription ? value.MaterialDescription.replace(/'/g, "\\'").trim() : '';
      value.Purpose = value.Purpose ? value.Purpose.replace(/'/g, "\\'").trim() : '';
      value.Comments = value.Comments ? value.Comments.replace(/'/g, "\\'").trim() : '';
      if ((value.Category === 'Maintenance/Repair/Spares' || value.Category === 'Stationery')) {
        this.projectErr = false;
        if (!this.checkAmountFlag) {
          this._dashboardService.AddCashPurchase(value)
            .subscribe(
            (results: any) => {
              this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
              this.showCashPurchaseFrom = false;
              this.onPending();
            },
            error => {
              this.errorMessage = <any>error;
              this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
        }
      } else if (value.Project !== '') {
        this.projectErr = false;
        if (!this.checkAmountFlag) {
          this._dashboardService.AddCashPurchase(value)
            .subscribe(
            (results: any) => {
              this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
              this.showCashPurchaseFrom = false;
              this.onPending();
            },
            error => {
              this.errorMessage = <any>error;
              this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
        }
      } else {
        this.projectErr = true;
      }
    } else {
      this.errorFlagForAddForm = true;
    }
  }
  onSubmitApproveRejectRequest({ value, valid }: { value: Cashmodel, valid: boolean }) {
    if (value.OctoriAmount !== undefined) {
      if (!this.isInteger(value.OctoriAmount.toString())) {
        this.errorMessage = 'Only Whole numbers are allowed for Statutary field';
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
        return;
      }
    }
    if (value.Amount !== undefined) {
      if (!this.isInteger(value.Amount.toString())) {
        this.errorMessage = 'Only Whole numbers are allowed for Amount field';
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
        return;
      }
    }
    let payload = {};
    if (this.ApproveButton === true && this.loggedInUserRole === 'Group Leader' && value.GLComments !== '') {
      this.ApproveButton = false;
      this.RejectButton = false;
      payload = {
        'ID': this.requestID, 'Status': 'Approved',
        'GLComments': value.GLComments ? value.GLComments.replace(/'/g, "\\'").trim() : '',
        'Amount': value.Amount,
        'isAdvanceBeforePurchase': this.isAdvanceBeforePurchase,
        'CPCreatedBy': this.CPCreatedBy
      };
      this._dashboardService.approveRejectRequest(payload)
        .subscribe(
        (results: any) => {
          this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
          this.showCashPurchaseApproveRejectFrom = false;
          this.errorFlagForApproveRejectForm = false;
          this.onPending();
        },
        error => {
          this.errorMessage = <any>error;
          this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
        });
    } else {
      this.errorFlagForApproveRejectForm = true;
    }
    if (this.RejectButton === true && this.loggedInUserRole === 'Group Leader' && value.GLComments !== '') {
      this.ApproveButton = false;
      this.RejectButton = false;
      payload = {
        'ID': this.requestID, 'Status': 'Rejected',
        'GLComments': value.GLComments ? value.GLComments.replace(/'/g, "\\'").trim() : '',
        'Amount': value.Amount,
        'isAdvanceBeforePurchase': this.isAdvanceBeforePurchase,
        'CPCreatedBy': this.CPCreatedBy
      };
      this._dashboardService.approveRejectRequest(payload)
        .subscribe(
        (results: any) => {
          this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
          this.showCashPurchaseApproveRejectFrom = false;
          this.errorFlagForApproveRejectForm = false;
          this.onPending();
        },
        error => {
          this.errorMessage = <any>error;
          this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
        });
    } else {
      this.errorFlagForApproveRejectForm = true;
    }
    if (this.ApproveButton === true && this.loggedInUserRole === 'Platform Leader' && value.PLComments !== '') {
      if (!this.IsGLApproved) {
        this.IsGLApproved = true;
        this.ApproveButton = false;
        this.RejectButton = false;
        payload = {
          'ID': this.requestID, 'Status': 'Approved',
          'GLComments': value.PLComments ? value.PLComments.replace(/'/g, "\\'").trim() : '',
          'Amount': value.Amount,
          'isAdvanceBeforePurchase': this.isAdvanceBeforePurchase,
          'PlatformLeader': this.platformLeaderName,
          'CPCreatedBy': this.CPCreatedBy
        };
        this._dashboardService.approveRejectRequest(payload)
          .subscribe(
          (results: any) => {
            this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
            this.showCashPurchaseApproveRejectFrom = false;
            this.errorFlagForApproveRejectForm = false;
            this.onPending();
          },
          error => {
            this.errorMessage = <any>error;
            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
          });
      } else {
        this.ApproveButton = false;
        this.RejectButton = false;
        payload = {
          'ID': this.requestID, 'Status': 'Approved',
          'PLComments': value.PLComments ? value.PLComments.replace(/'/g, "\\'").trim() : '',
          'Amount': value.Amount,
          'isAdvanceBeforePurchase': this.isAdvanceBeforePurchase,
          'Approval1': true,
          'PlatformLeader': this.platformLeaderName,
          'CPCreatedBy': this.CPCreatedBy
        };
        this._dashboardService.approveRejectRequest_PL(payload)
          .subscribe(
          (results: any) => {
            this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
            this.showCashPurchaseApproveRejectFrom = false;
            this.errorFlagForApproveRejectForm = false;
            this.onPending();
          },
          error => {
            this.errorMessage = <any>error;
            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
          });
      }
    } else {
      this.errorFlagForApproveRejectForm = true;
    }
    if (this.RejectButton === true && this.loggedInUserRole === 'Platform Leader' && value.PLComments !== '') {
      if (!this.IsGLApproved) {
        this.IsGLApproved = true;
        this.ApproveButton = false;
        this.RejectButton = false;
        payload = {
          'ID': this.requestID, 'Status': 'Rejected',
          'GLComments': value.PLComments ? value.PLComments.replace(/'/g, "\\'").trim() : '',
          'Amount': value.Amount,
          'isAdvanceBeforePurchase': this.isAdvanceBeforePurchase,
          'PlatformLeader': this.platformLeaderName,
          'CPCreatedBy': this.CPCreatedBy
        };
        this._dashboardService.approveRejectRequest(payload)
          .subscribe(
          (results: any) => {
            this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
            this.showCashPurchaseApproveRejectFrom = false;
            this.errorFlagForApproveRejectForm = false;
            this.onPending();
          },
          error => {
            this.errorMessage = <any>error;
            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
          });
      } else {
        this.ApproveButton = false;
        this.RejectButton = false;
        payload = {
          'ID': this.requestID, 'Status': 'Rejected',
          'PLComments': value.PLComments ? value.PLComments.replace(/'/g, "\\'").trim() : '',
          'Amount': value.Amount,
          'isAdvanceBeforePurchase': this.isAdvanceBeforePurchase,
          'Approval1': true,
          'PlatformLeader': this.platformLeaderName,
          'CPCreatedBy': this.CPCreatedBy
        };
        this._dashboardService.approveRejectRequest_PL(payload)
          .subscribe(
          (results: any) => {
            this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
            this.showCashPurchaseApproveRejectFrom = false;
            this.errorFlagForApproveRejectForm = false;
            this.onPending();
          },
          error => {
            this.errorMessage = <any>error;
            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
          });
      }

    } else {
      this.errorFlagForApproveRejectForm = true;
    }
  }
  onSubmitSearch({ value, valid }: { value: Searchmodel, valid: boolean }) {
    if (valid) {
      this.cashpurchaseData = [];
      this.errorFlagForSearchForm = false;
      // this.onSearchClickToShowAction = true;
      this._dashboardService.getSearchResult(value)
        .subscribe(
        (results: any) => {
          if (results.length > 0) {
            this.cashpurchaseData = results;
            this.status = results[0].Status;
            switch (this.status) {
              case 'Pending': this.headingColor = 'orange';
                break;
              case 'Approved': this.headingColor = 'green';
                break;
              case 'Rejected': this.headingColor = 'red';
                break;
              case 'Closed': this.headingColor = '#26c6da';
                break;
            }
          }
        },
        error => {
          this.errorMessage = <any>error;
          this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
        });

    } else {
      this.errorFlagForSearchForm = true;
    }
  }
  onApprovedRequest({ value, valid }: { value: Cashmodel, valid: boolean }) {
    if (valid) {
      console.log(value);

      if (value.OctoriAmount !== undefined) {
        if (!this.isInteger(value.OctoriAmount.toString())) {
          this.errorMessage = 'Only Whole numbers are allowed for Statutary field';
          this._messageService.addMessage({ severity: 'error', summary: 'Success Message', detail: this.errorMessage });
          return;
        }
      }
      if (value.InvoiceAmount !== undefined) {
        if (!this.isInteger(value.InvoiceAmount.toString())) {
          this.errorMessage = 'Only Whole numbers are allowed for Amount field';
          this._messageService.addMessage({ severity: 'error', summary: 'Success Message', detail: this.errorMessage });
          return;
        }
      }
      value.ID = this.requestID;
      value.RequestTitle = value.RequestTitle ? value.RequestTitle.replace(/'/g, "\\'").trim() : '';
      value.MaterialDescription = value.MaterialDescription ? value.MaterialDescription.replace(/'/g, "\\'").trim() : '';
      value.Purpose = value.Purpose ? value.Purpose.replace(/'/g, "\\'").trim() : '';
      value.Comments = value.Comments ? value.Comments.replace(/'/g, "\\'").trim() : '';
      value.GLComments = value.GLComments ? value.GLComments.replace(/'/g, "\\'").trim() : '';
      value.Quantity = value.Quantity ? value.Quantity.replace(/'/g, "\\'").trim() : '';
      value.Remarks = value.Remarks ? value.Remarks.replace(/'/g, "\\'").trim() : '';
      value.isAdvanceBeforePurchase = this.isAdvanceBeforePurchase;
      value.Approval1 = this.Approval1;
      value.Approval2 = this.Approval2;
      this._dashboardService.closeRequest(value, this.filesDataForReceipt, this.filesDataForGatePass).then(
        (results: any) => {
          this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results });
          this.showApprovedCashPurchaseFrom = false;
          this.onPending();
        },
        (error: any) => {
          this.errorMessage = <any>error;
          this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
        });

    } else {
      this.errorFlagForApproveForm = true;
    }
  }
  onCancelForm() {
    this.showCashPurchaseFrom = false;
    this.errorFlagForAddForm = false;
  }
  onCancelApproveRejectForm() {
    this.showCashPurchaseApproveRejectFrom = false;
    this.errorFlagForApproveRejectForm = false;
  }
  onCancelApprovedForm() {
    this.showApprovedCashPurchaseFrom = false;
    this.errorFlagForApproveForm = false;
  }
  onCloseSearchForm() {
    this.showSearchRequestForm = false;
    this.errorFlagForSearchForm = false;
  }
  onCancelCashPurchaseRequest(request: Cashmodel) {
    this.display = true;
    this.requestID = request.ID;
    this._confirmationService.confirm({
      message: 'Are you sure that you want to cancel this request?',
      accept: () => {
        this._dashboardService.cancelCashPurchaseRequest(request.ID)
          .subscribe(
          (results: any) => {
            this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
            this.onPending();
          },
          error => {
            this.errorMessage = <any>error;
            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
          });
      }
    });
  }
  CancelRequest() {
    this._dashboardService.cancelCashPurchaseRequest(this.requestID)
      .subscribe(
      (results: any) => {
        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
        this.onPending();
        this.display = false;
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  // Format date in "yyyy-mm-dd" format
  formatDate(date: any) {
    let d = new Date(date);
    let month = '' + (d.getMonth() + 1);
    let day = '' + d.getDate();
    let year = d.getFullYear();
    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;

    return [month, day, year].join('/');
  }
  checkAmount(e: any) {
    if (e > 10000) {
      this.checkAmountFlag = true;
      document.getElementById('checkAmount').innerHTML = 'Amount Should Not Be Greater Than 10000';
      document.getElementById('checkAmount').style.display = 'block';
    } else {
      document.getElementById('checkAmount').style.display = 'none';
      this.checkAmountFlag = false;
    }
  }

  isInteger(amount: string): boolean {
    if (amount.indexOf('.') > 0) {
      return false;
    } else {
      return true;
    }
  }
}
