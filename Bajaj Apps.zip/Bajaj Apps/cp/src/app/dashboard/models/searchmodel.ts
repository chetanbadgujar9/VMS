export class Searchmodel {
    constructor(
        public fieldName: string,
        public fieldValue: string
    ) { }
}
