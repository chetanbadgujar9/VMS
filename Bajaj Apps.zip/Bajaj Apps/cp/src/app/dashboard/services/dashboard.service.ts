/* angular dependencies */
import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/finally';

/** Third party dependencies */
import { AuthHttp } from '../../shared/services/authHttp.service';
import { Config } from '../../shared/config/config';
import { SpinnerService } from '../../shared/spinner/spinner.service';
import { Cashmodel } from '../models/cashmodel';
import { Searchmodel } from '../models/searchmodel';

@Injectable()
export class DashboardService {
    progress: any;
    progressObserver: any;
    constructor(private http: Http,
        private authHttp: AuthHttp,
        private _spinnerService: SpinnerService) {
    }

    getMyTestData() {
        let url = Config.GetURL('/Register/getHeight');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getPendingRequest_Engg(status: any) {
        let url = Config.GetURL('/api/cashpurchase/CashPurchase/GetMyCreatedRequestsByStatus?status=' + status);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getRequesterCounters() {
        let url = Config.GetURL('/api/cashpurchase/CashPurchase/GetRequesterCounters');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getPendingRequest_GL(status: any) {
        let url = Config.GetURL('/api/cashpurchase/CashPurchase/GetGLRequestsByStatus?status=' + status);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getAllGLPendingRequests() {
        let url = Config.GetURL('/api/CashPurchase/CashPurchase/GetAllPendingGLRequests');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getAllCancellationRequests() {
        let url = Config.GetURL('/api/CashPurchase/CashPurchase/GetAllRequestForCancellation');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getGLCounters() {
        let url = Config.GetURL('/api/cashpurchase/CashPurchase/GetGLCounters');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getPendingRequest_L1(status: any) {
        let url = Config.GetURL('/api/cashpurchase/CashPurchase/GetL1RequestsByStatus?status=' + status);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getAllPLPendingRequests() {
        let url = Config.GetURL('/api/CashPurchase/CashPurchase/GetAllPendingL1Requests');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getL1Counters() {
        let url = Config.GetURL('/api/cashpurchase/CashPurchase/GetL1Counters');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    AddCashPurchase(payload: Cashmodel) {
        let url = Config.GetURL('/api/cashpurchase/CashPurchase/Post');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    approveRejectRequest(payload: any) {
        let url = Config.GetURL('/api/cachpurchase/CashPurchase/GLApprovalActionOnRequest');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    approveRejectRequest_PL(payload: any) {
        let url = Config.GetURL('/api/cachpurchase/CashPurchase/L1ApprovalActionOnRequest');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getDownloadedFile(attachment: string) {
        //Update an API
        let url = Config.GetURL('/api/cashpurchase/CashPurchase/GetAttachmentBinaryByAttachmentUrl?url=' + attachment);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    cancelCashPurchaseRequest(id: any) {
        let url = Config.GetURL('/api/cashpurchase/CashPurchase/CancelRequestByID/' + id);
        this._spinnerService.show();
        return this.authHttp.post(url, id)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getRequestByID(id: any) {
        let url = Config.GetURL('/api/cachpurchase/CashPurchase/Get/' + id);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getSearchResult(payload: Searchmodel) {
        let url = Config.GetURL('/api/cashpurchase/CashPurchase/SearchRequestsByFieldName?fieldName='
            + payload.fieldName + '&fieldValue=' + payload.fieldValue);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    approvePLRequestByAdmin(payload: any) {
        let url = Config.GetURL('/api/cashpurchase/CashPurchase/L1ApproveByAdminOnRequest');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    rejectPLRequestByAdmin(payload: any) {
        let url = Config.GetURL('/api/cashpurchase/CashPurchase/L1ApproveByAdminOnRequest');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    approveGLRequestByAdmin(payload: any) {
        let url = Config.GetURL('/api/test/CashPurchase/GLApproveByAdminOnRequest');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    rejectGLRequestByAdmin(payload: any) {
        let url = Config.GetURL('/api/test/CashPurchase/GLApproveByAdminOnRequest');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    public closeRequest(payload: any, receipt: any, gatepass: any) {
        let url = Config.GetURL('/api/CashPurchase/CashPurchase/CloseRequestWithAttachment');
        this._spinnerService.show();
        return new Promise((resolve, reject) => {
            let formData: FormData = new FormData(),
                xhr: XMLHttpRequest = new XMLHttpRequest();
            let data = { 'File': payload }
            formData.append(JSON.stringify(payload).replace(/'/g, "\\'").replace(/"/g, '$'), 'Data');
            formData.append('receiptFileName', receipt[0]);
            formData.append('gatePassFileName', gatepass[0]);

            xhr.onreadystatechange = () => {
                if (xhr.readyState === 4) {
                    if (xhr.status === 200) {
                        resolve(JSON.parse(xhr.response));
                    } else {
                        reject(xhr.response);
                    }
                }
            };
            xhr.open('POST', url, true);
            //xhr.setRequestHeader('Content-Type', undefined);
            xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem('access_token'));
            xhr.send(formData);
            this._spinnerService.hide();
        });
    }
    /**Success Handler */
    private extractData(res: Response) {
        if (res.status < 200 || res.status >= 300) {
            throw new Error('Bad response status: ' + res.status);
        }
        let body = res.json();
        return body || {};
    }
    private extractDataForValidate(res: Response) {
        if (res.status < 200 || res.status >= 300) {
            throw new Error('Bad response status: ' + res.status);
        }
        let body = res.json();
        return body || false;
    }
    /**Error Handler */
    private handleError(error: Response) {
        console.log(error);
        return Observable.throw(error.json().error || 'Server error');
    }
}