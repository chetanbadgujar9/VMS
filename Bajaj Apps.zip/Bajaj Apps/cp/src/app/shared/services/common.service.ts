/* angular dependencies */
import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/finally';
import { Router } from '@angular/router';

/** Third party dependencies */
import { SpinnerService } from '../spinner/spinner.service';
import { Config } from '../config/config';
import { AuthHttp } from '../services/authHttp.service';
import { AuthInfo } from '../../dashboard/models/authInfo';

@Injectable()
export class CommonService {
    http: Http;
    constructor(http: Http,
        private authHttp: AuthHttp,
        private _spinnerService: SpinnerService,
        private router: Router) {
        this.http = http;
    }
    onTitleClick() {
        this.router.navigate(['/brand']);
    }
    //Get user auth token
    getAuthToken(credentials: AuthInfo) {
        let authenticateUrl = Config.GetURL('/api/Auth/Token');
        let headers = new Headers();
        let credentialString: string = 'grant_type=password&username=' + credentials.UserName + '&password=' + credentials.Password;
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let options = new RequestOptions({ headers: headers });
        return this.http.post(authenticateUrl, credentialString, options)
            .map((res: Response) => {
                this.setToken(res); //this.emitAuthEvent(true);
            })
            .catch(this.handleError);
    }
    getRMSMenus() {
        let url = Config.GetURL('/api/CashPurchase/NavigationMaster/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    //Get Logged In User Data
    getLoggedInUserDetails(username: any) {
        let url = Config.GetURL('/api/testrequest/BALRMSUGP/GetUGPDetailsByUserName?userName=' + username);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }

    //  To get Group master
    getAllProject() {
        let url = Config.GetURL('/api/cachpurchase/ProjectMaster/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getProjectMaster() {
        let url = Config.GetURL('/api/cashpurchase/ProjectMaster/GetActiveProjectMaster');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    addProject(value: any) {
        let url = Config.GetURL('/api/cachpurchase/ProjectMaster/Post');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    updateProject(value: any) {
        let url = Config.GetURL('/api/cachpurchase/ProjectMaster/UpdateProjectMasterByID');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getAllCategory() {
        let url = Config.GetURL('/api/cachpurchase/CategoryMaster/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getCategoryMaster() {
        let url = Config.GetURL('/api/cashpurchase/CategoryMaster/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    addCategory(value: any) {
        let url = Config.GetURL('/api/cachpurchase/CategoryMaster/Post');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    updateCategory(value: any) {
        let url = Config.GetURL('/api/cachpurchase/CategoryMaster/UpdateCategoryMasterByID');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    deleteCategory(value: any) {
        let url = Config.GetURL('/api/cashpurchase/CategoryMaster/DeleteCategoryMasterByID/' + value);
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    //Get Admin Access
    getAdminAccess(username: any) {
        let url = Config.GetURL('/api/rms/farmadminusers/FarmAdminUsersByUserLoginName?userLoginName=' + username);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getMyData(username: any) {
        let url = Config.GetURL('/api/cashpurchase/RndUsers/GetRndUsersListByName?userName=' + username);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }

    /**Set Token in localstorage */
    private setToken(res: Response) {
        if (res.status < 200 || res.status >= 300) {
            throw new Error('Bad response status: ' + res.status);
        }
        let body = res.json();
        sessionStorage.setItem('access_token', body.access_token);
        return body || {};
    }

    /**Success Handler */
    private extractData(res: Response) {
        if (res.status < 200 || res.status >= 300) {
            throw new Error('Bad response status: ' + res.status);
        }
        let body = res.json();
        return body || {};
    }

    /**Error Handler */
    private handleError(error: Response) {
        console.log(error);
        return Observable.throw(error.json().error || 'Server error');
    }

}
