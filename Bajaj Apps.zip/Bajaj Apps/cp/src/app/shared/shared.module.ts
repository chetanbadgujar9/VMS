import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

// import { ToolbarComponent } from './toolbar/toolbar.component';
import { NavbarComponent } from './navbar/navbar.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { NameListService } from './name-list/name-list.service';
import { AuthHttp } from './services/authHttp.service';
import {
  CalendarModule, DataTableModule, GrowlModule, MultiSelectModule,
  ConfirmDialogModule, RadioButtonModule, InputTextModule, CheckboxModule,
  DialogModule, TooltipModule
} from 'primeng/primeng';
import { SpinnerComponent } from './spinner/spinner.component';
import { SpinnerService } from './spinner/spinner.service';
import { MessageService } from './services/message.service';
import { CommonService } from './services/common.service';
/**
 * Do not specify providers for modules that might be imported by a lazy loaded module.
 */

@NgModule({
  imports: [CommonModule, RouterModule],
  declarations: [ NavbarComponent, SidebarComponent, SpinnerComponent],
  exports: [ NavbarComponent,
    CommonModule, FormsModule, ReactiveFormsModule,
    RouterModule, SidebarComponent, SpinnerComponent,
    CalendarModule, DataTableModule, GrowlModule, ConfirmDialogModule, MultiSelectModule
    , RadioButtonModule, InputTextModule, TooltipModule,
    CheckboxModule, DialogModule]
})
export class SharedModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: SharedModule,
      providers: [NameListService, AuthHttp, SpinnerService, MessageService, CommonService]
    };
  }
}
