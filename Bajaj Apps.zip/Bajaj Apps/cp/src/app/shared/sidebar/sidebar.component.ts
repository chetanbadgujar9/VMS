import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Config } from '../../shared/config/config';
import { MessageService } from '../services/message.service';
import { CommonService } from '../../shared/services/common.service';
/**
 * This class represents the toolbar component.
 */
@Component({
  moduleId: module.id,
  selector: 'sd-sidebar',
  templateUrl: 'sidebar.component.html',
  styleUrls: ['sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  menuItems: any = [];
  rmsMenu: any = [];
  errorMessage: any;
  show: boolean = false;
  showRMS: boolean = true;
  hasAdminAccess: boolean = false;
  constructor(private router: Router, private _messageService: MessageService, private _commonService: CommonService) { }
  ngOnInit() {
    //System.import('../../../js/sidebar-moving-tab.js');
    this._messageService.getAdminAccess()
      .subscribe((value: any) => {
        this.hasAdminAccess = value;
      });
    this._messageService.getRMSMenu()
      .subscribe((value: any) => {
        this.rmsMenu = value;
      });
    this.menuItems = [{ path: '', title: 'Dashboard', icon: 'fa fa-home fa-fw', class: '' },
    { path: 'voucher', title: 'CP Voucher', icon: 'fa fa-file-text fa-fw', class: '' },];
  }
  check() {
    if (this.show) {
      this.show = false;
    } else {
      this.show = true;
    }
  }
  checkRMSMenu() {
    if (this.showRMS) {
      this.showRMS = false;
    } else {
      this.showRMS = true;
    }
  }
  onLogoClick() {
    window.location.href = Config.getLogoURL();
  }
  onTitleClick() {
    this.router.navigate(['/']);
  }
  onRoute(route: any) {
    this.router.navigate([route]);
  }
  menuClick(route: any) {
    sessionStorage.removeItem('Status');
    this.show = false;
    if (route === '/') {
      this._messageService.AddDashboardFlag(false);
    }
    this.router.navigate([route]);
  }
}

