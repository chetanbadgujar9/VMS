import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { UnAuthorizedComponent } from './components/unauthorized.component';

@NgModule({
    imports: [
        RouterModule.forChild([
            { path: 'unauthorized/:id', component: UnAuthorizedComponent }
        ])
    ],
    exports: [RouterModule]
})
export class UnauthorizedRoutingModule { }