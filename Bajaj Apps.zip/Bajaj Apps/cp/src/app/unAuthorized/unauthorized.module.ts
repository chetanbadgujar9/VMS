import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UnAuthorizedComponent } from './components/unauthorized.component';
import { UnauthorizedRoutingModule } from './unauthorized-routing.module';
import { BrowserModule } from '@angular/platform-browser';
import { SharedModule } from '../shared/shared.module';
@NgModule({
    imports: [CommonModule, UnauthorizedRoutingModule, SharedModule],
    declarations: [UnAuthorizedComponent],
    exports: [UnAuthorizedComponent]
})
export class UnauthorizedModule { }
