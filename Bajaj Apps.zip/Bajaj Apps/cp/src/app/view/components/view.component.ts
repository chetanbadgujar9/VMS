import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { DashboardService } from '../../dashboard/services/dashboard.service';
import { Cashmodel } from '../../dashboard/models/cashmodel';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-view',
    templateUrl: 'view.component.html',
    styleUrls: ['view.component.css']
})
export class ViewComponent implements OnInit {
    params: Params;
    viewData: any = {};
    totalClaimAmount: any = 0;
    balAmount: any = 0;
    balAmountDisplay: any = '';
    constructor(private router: Router, private route: ActivatedRoute, private _dashboardService: DashboardService, private _router: Router
    ) { }
    ngOnInit() {
        this.route.params.forEach((params: Params) => {
            this.params = params['id'];
        });
        this._dashboardService.getRequestByID(this.params)
            .subscribe(
            (results: Cashmodel) => {
                if (Object.keys(results).length !== 0) {
                    this.viewData = results;
                    if (this.viewData.InvoiceAmount !== null && this.viewData.OctoriAmount !== null) {
                        this.totalClaimAmount = this.viewData.InvoiceAmount + this.viewData.OctoriAmount;
                    }
                    else if (this.viewData.InvoiceAmount !== null && this.viewData.OctoriAmount === null) {
                        this.totalClaimAmount = this.viewData.InvoiceAmount + 0;
                    }
                    else if (this.viewData.InvoiceAmount === null && this.viewData.OctoriAmount !== null) {
                        this.totalClaimAmount = 0 + this.viewData.OctoriAmount;
                    }
                    if (results.isAdvanceBeforePurchase) {
                        this.balAmount = this.viewData.AdvanceAmount - this.totalClaimAmount;
                        if (this.balAmount < 0) {
                            this.balAmountDisplay = "Amount to be received from Finance Rs " + (this.balAmount * -1);
                        }
                        else if (this.balAmount > 0) {
                            this.balAmountDisplay = "Amount to be returned to Finance Rs " + (this.balAmount);
                        }
                    }
                    console.log('view', this.viewData);
                }
            })
    }
    print() {
        //var doc = $(printid).html();
        //var printWindow = window.open('', '', 'height=400,width=600');
        // printWindow.document.write('<html><head><title>DIV Contents</title>');
        //  printWindow.document.write('</head><body >');
        //printWindow.document.write(doc);
        //printWindow.document.write('</body></html>');
        //printWindow.document.close();
        //printWindow.print();
        var printButton = document.getElementById("printBtn");
        var closeButton = document.getElementById("closeBtn");
        printButton.style.visibility = 'hidden';
        closeButton.style.visibility = 'hidden';
        window.print();
        window.close();
        printButton.style.visibility = 'visible';
        closeButton.style.visibility = 'visible';
    }
    close() {
        this._router.navigate(['/']);
    }
}
