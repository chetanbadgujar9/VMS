import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ViewComponent } from './components/view.component';

@NgModule({
  imports: [
    RouterModule.forChild([
      { path: 'view/:id', component: ViewComponent }
    ])
  ],
  exports: [RouterModule]
})
export class ViewRoutingModule { }
