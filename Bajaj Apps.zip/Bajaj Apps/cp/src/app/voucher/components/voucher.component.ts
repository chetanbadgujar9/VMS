import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MessageService } from '../../shared/services/message.service';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-voucher',
    templateUrl: 'voucher.component.html',
    styleUrls: ['voucher.component.css']
})
export class VoucherComponent implements OnInit {
    cars: any = [];
    constructor(private _messageService: MessageService) {

    }
    ngOnInit() {
        //InIt method
        this.cars = [
            { "desc": "", "AccountHead": "Travel Advance", "Rs": "", "Ps": "", "TrCode": "1" },
            { "desc": "", "AccountHead": "Sundry Advance", "Rs": "", "Ps": "", "TrCode": "2" },
            { "desc": "", "AccountHead": "Foreign Travel Advance", "Rs": "", "Ps": "", "TrCode": "3" },
            { "desc": "", "AccountHead": "Cash Withdrawal", "Rs": "", "Ps": "", "TrCode": "4" },
            { "desc": "", "AccountHead": "Conveyance Charges", "Rs": "", "Ps": "", "TrCode": "5" },
            { "desc": "", "AccountHead": "Lunch Charges", "Rs": "", "Ps": "", "TrCode": "6" },
            { "desc": "", "AccountHead": "Telephone Charges", "Rs": "", "Ps": "", "TrCode": "7" },
            { "desc": "", "AccountHead": "Stationary", "Rs": "", "Ps": "", "TrCode": "8" },
            { "desc": "", "AccountHead": "Miscellaneous Expenses", "Rs": "", "Ps": "", "TrCode": "9" },
            { "desc": "", "AccountHead": "R & D Expenses", "Rs": "", "Ps": "", "TrCode": "10" },
            { "desc": "", "AccountHead": "Coolie Charges", "Rs": "", "Ps": "", "TrCode": "13" },
            { "desc": "", "AccountHead": "Motor car Expenses Emp", "Rs": "", "Ps": "", "TrCode": "20" },
            { "desc": "", "AccountHead": "Cash Journal Transfer", "Rs": "", "Ps": "", "TrCode": "36" }
        ]
    }
    print() {
        var printButton = document.getElementById("printBtn");
        printButton.style.visibility = 'hidden';
        window.print();
        window.close();
        printButton.style.visibility = 'visible';
    }
}
