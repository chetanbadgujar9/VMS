import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { VoucherComponent } from './components/voucher.component';

@NgModule({
  imports: [
    RouterModule.forChild([
      { path: 'voucher', component: VoucherComponent }
    ])
  ],
  exports: [RouterModule]
})
export class VoucherRoutingModule { }
