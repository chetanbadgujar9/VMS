import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { VoucherComponent } from './components/voucher.component';
import { VoucherRoutingModule } from './voucher-routing.module';
import { BrowserModule } from '@angular/platform-browser';
import { SharedModule } from '../shared/shared.module';
@NgModule({
    imports: [CommonModule, VoucherRoutingModule, SharedModule],
    declarations: [VoucherComponent],
    exports: [VoucherComponent]
})
export class VoucherModule { }
