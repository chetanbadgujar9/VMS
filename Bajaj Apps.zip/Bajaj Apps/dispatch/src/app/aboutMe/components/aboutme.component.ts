import { Component, OnInit, NgModule, trigger, transition, style, animate, state } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ConfirmationService } from 'primeng/primeng';
import { Router } from '@angular/router';
import { CommonService } from '../../shared/services/common.service';
import { MessageService } from '../../shared/services/message.service';
//import { User } from '../../dashboard/models/loginUser';
import { EmployeeInfo } from '../model/employeeInfo';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
  moduleId: module.id,
  selector: 'sd-aboutme',
  templateUrl: 'aboutme.component.html',
  styleUrls: ['aboutme.component.css'],
  providers: [ConfirmationService]
})
export class AboutComponent implements OnInit {
  /** List Varibales To Bind Data */
  employeeInfo: EmployeeInfo = new EmployeeInfo();
  userName: string;
  errorMessage: string;

  constructor(private formBuilder: FormBuilder, private _commonService: CommonService,
    private _messageService: MessageService,
    private _router: Router, private _confirmationService: ConfirmationService, ) {
  }
  ngOnInit() {
    //this.userName = 'k murali';
    if (sessionStorage.getItem('loggedInUserData')) {
      this.userName = JSON.parse(sessionStorage.getItem('loggedInUserData')).UserLookup.Name;
    } else {
      this.userName = '';
    }

    this.getMyData();
  }
  getMyData() {
    this._commonService.getMyData(this.userName)
      .subscribe(
      (results: any) => {
        if (results.length > 0)
          this.employeeInfo = results[0];
      },
      error => {
        this.errorMessage = <any>error;
        this._router.navigate(['/unauthorized',
          'You are not Authorized to access this site due to UGP mapping does not exist. Please contact Ahead portal support team.']);
      });
  }
}
