import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CountryComponent } from './components/country/country.component';
import { GMComponent } from './components/GM/gm.component';
import { PMComponent } from './components/PM/pm.component';
import { PlantComponent } from './components/plant/plant.component';
import { StoreLocationComponent } from './components/storelocation/storelocation.component';
import { DispatchGroupComponent } from './components/dispatchGroup/dispatchgroup.component';
import { TransportationModeComponent } from './components/transportationmode/transportationmode.component';
import { DomesticGLComponent } from './components/domesticGLApproval/domesticGL.component';
import { DomesticGMComponent } from './components/domesticGMApproval/domesticGM.component';
import { ExportGLComponent } from './components/exportGLApproval/exportGL.component';
import { ExportL1Component } from './components/exportL1Approval/exportL1.component';
import { ExportGMComponent } from './components/exportGMApproval/exportGM.component';
@NgModule({
  imports: [
    RouterModule.forChild([
          { path: 'country', component: CountryComponent },
          { path: 'dispatchGroup', component: DispatchGroupComponent },
          { path: 'gm', component: GMComponent },
          { path: 'plant', component: PlantComponent },
          { path: 'pm', component: PMComponent },
          { path: 'storeLocation', component: StoreLocationComponent },
          { path: 'transportationMode', component: TransportationModeComponent },
          { path: 'domesticGL', component: DomesticGLComponent },
          { path: 'domesticGM', component: DomesticGMComponent },
          { path: 'exportGL', component: ExportGLComponent },
          { path: 'exportL1', component: ExportL1Component },
          { path: 'exportGM', component: ExportGMComponent }
    ])
  ],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
