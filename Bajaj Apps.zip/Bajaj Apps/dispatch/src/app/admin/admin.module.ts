import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CountryComponent } from './components/country/country.component';
import { GMComponent } from './components/GM/gm.component';
import { PMComponent } from './components/PM/pm.component';
import { PlantComponent } from './components/plant/plant.component';
import { DispatchGroupComponent } from './components/dispatchGroup/dispatchgroup.component';
import { StoreLocationComponent } from './components/storelocation/storelocation.component';
import { DomesticGLComponent } from './components/domesticGLApproval/domesticGL.component';
import { DomesticGMComponent } from './components/domesticGMApproval/domesticGM.component';
import { ExportGLComponent } from './components/exportGLApproval/exportGL.component';
import { ExportL1Component } from './components/exportL1Approval/exportL1.component';
import { ExportGMComponent } from './components/exportGMApproval/exportGM.component';
import { TransportationModeComponent } from './components/transportationmode/transportationmode.component';
import { AdminRoutingModule } from './admin-routing.module';
import { BrowserModule } from '@angular/platform-browser';
import { SharedModule } from '../shared/shared.module';
import { CommonService } from '../shared/services/common.service';
@NgModule({
    imports: [CommonModule, AdminRoutingModule, SharedModule],
    declarations: [CountryComponent, GMComponent, PMComponent, PlantComponent, StoreLocationComponent,
        DispatchGroupComponent, TransportationModeComponent, DomesticGLComponent, DomesticGMComponent,
        ExportGLComponent, ExportL1Component, ExportGMComponent],
    exports: [CountryComponent, GMComponent, PMComponent, PlantComponent, StoreLocationComponent,
        DispatchGroupComponent, TransportationModeComponent, DomesticGLComponent, DomesticGMComponent,
        ExportGLComponent, ExportL1Component, ExportGMComponent],
    providers: [CommonService]
})
export class AdminModule { }
