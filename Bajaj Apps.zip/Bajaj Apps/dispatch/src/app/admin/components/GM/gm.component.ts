import { Component, OnInit, NgModule, trigger, transition, style, animate, state, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { MessageService } from '../../../shared/services/message.service';
import { CommonService } from '../../../shared/services/common.service';
import { ConfirmationService } from 'primeng/primeng';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SelectItem } from 'primeng/primeng';
import { Stage } from '../../model/stage';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-gm',
    templateUrl: 'gm.component.html',
    styleUrls: ['gm.component.css'],
    providers: [ConfirmationService]
})
export class GMComponent implements OnInit {
    data: any[] = [];
    GMData: any[] = [];
    GMDataEdit: any[];
    assignToUsers: any[];
    errorMessage: string;
    errorFlag: boolean = false;
    showGMForm: boolean = false;
    GMForm: FormGroup;
    Id: any = '';
    constructor(private _messageService: MessageService,
        private _commonService: CommonService,
        private _confirmationService: ConfirmationService,
        private formBuilder: FormBuilder) {
    }
    ngOnInit() {
        this._messageService.AddDashboardFlag(false);
        this.setForm();
        this.getGMList();
    }
    setForm() {
        this.GMForm = this.formBuilder.group({
            Title: [''],
        });
    }
    onAddSecurity() {
        this.setForm();
        this.showGMForm = true;
        this.errorFlag = false;
    }
    onCancel() {
        this.GMForm.setValue({
            Title: '',
        });
        this.showGMForm = false;
    }
    getGMList() {
        this.data = [];
        this.GMDataEdit = [];
        this.GMData = [];
        this._commonService.getGMList()
            .subscribe(
            (results: any) => {
                console.log(results);
                this.GMDataEdit = results;
                results.forEach((element: any) => {
                    this.GMData.push(element.GMName);
                });
                this.data = this.GMData;
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });

            });
    }

    onEdit(gm: any) {
        this.showGMForm = true;
        this.GMDataEdit.forEach(element => {
            if (element.GMName.ID === gm.ID) {
                this.Id = element.ID;
            }
        });
        this.GMForm.setValue({
            Title: gm.Name,
        });
    }
    onDelete(gm: any) {
        let id: any;
        this.GMDataEdit.forEach(element => {
            if (element.GMName.ID === gm.ID) {
                id = element.ID;
            }
        });
        this._confirmationService.confirm({
            message: 'Are you sure that you want to delete?',
            accept: () => {
                this._commonService.deleteGM(id)
                    .subscribe(
                    (results: any) => {
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getGMList();
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
        });

    }
    getAssignToUsers(event: any) {
        let query = event.query;
        this._commonService.getAssignToUsers(query)
            .subscribe(
            (results: any) => {
                this.assignToUsers = results;
                //this.assignToUsers =[ {'ID':1,'name':'Amol'},{'ID':2,'name':'Amul'}];
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onSubmit({ value, valid }: { value: any, valid: boolean }) {
        if (valid) {
            if (value.Title.Name !== undefined) {
                this.errorFlag = false;
                if (this.Id === '') {
                    let Payload = {
                        'GMName': {
                            'ID': value.Title.ID
                        }
                    };
                    this._commonService.addGM(Payload)
                        .subscribe(
                        (results: any) => {
                            this.Id = '';
                            this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                            this.getGMList();
                            this.showGMForm = false;
                        },
                        error => {
                            this.errorMessage = <any>error;
                            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                        });
                }
                if (this.Id !== '') {
                    let Payload = {
                        'GMName': {
                            'ID': value.Title.ID
                        },
                        'ID': this.Id
                    };
                    this._commonService.updateGM(Payload)
                        .subscribe(
                        (results: any) => {
                            this.Id = '';
                            this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                            this.getGMList();
                            this.showGMForm = false;
                        },
                        error => {
                            this.errorMessage = <any>error;
                            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                        });
                }
            } else {
                this.errorFlag = true;
            }
        } else {
            this.errorFlag = true;
        }

    }
}
