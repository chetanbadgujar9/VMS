import { Component, OnInit, NgModule, trigger, transition, style, animate, state, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { MessageService } from '../../../shared/services/message.service';
import { CommonService } from '../../../shared/services/common.service';
import { ConfirmationService } from 'primeng/primeng';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SelectItem } from 'primeng/primeng';
import { Stage } from '../../model/stage';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-pm',
    templateUrl: 'pm.component.html',
    styleUrls: ['pm.component.css'],
    providers: [ConfirmationService]
})
export class PMComponent implements OnInit {
    data: any[] = [];
    PMData: any[] = [];
    PMDataEdit: any[];
    assignToUsers: any[];
    brands: any[];
    errorMessage: string;
    errorFlag: boolean = false;
    showPMForm: boolean = false;
    PMForm: FormGroup;
    BrandForm: FormGroup;
    Id: any = '';
    constructor(private _messageService: MessageService,
        private _commonService: CommonService,
        private _confirmationService: ConfirmationService,
        private formBuilder: FormBuilder) {
    }
    ngOnInit() {
        this._messageService.AddDashboardFlag(false);
        this.setForm();
        this.getPMList();
    }
    setForm() {
        this.PMForm = this.formBuilder.group({
            Name: ['', [Validators.required]],
        });
        this.BrandForm = this.formBuilder.group({
            Title: ['', [Validators.required]],
        });
    }
    onAddSecurity() {
        this.setForm();
        this.showPMForm = true;
        this.errorFlag = false;
    }
    onCancel() {
        // this.PMForm.setValue({
        //     Title: '',
        // });
        // this.BrandForm.setValue({
        //     Title: '',
        // });
        this.showPMForm = false;
        this.setForm();
    }
    getPMList() {
        this.data = [];
        this.PMDataEdit = [];
        this.PMData = [];
        this._commonService.getPMList()
            .subscribe(
            (results: any) => {
                console.log(results);
                this.PMDataEdit = results;
                results.forEach((element: any) => {
                    this.PMData.push(element.BrandOwner);
                });
                this.data = this.PMDataEdit;//this.PMData;
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });

            });
    }

    onEdit(pm: any) {
        this.showPMForm = true;
        var _brand;
        // this.PMDataEdit.forEach(element => {
        //     if (element.BrandOwner.ID === pm.ID) {
        //         this.Id = element.ID;
        //     }
        //     if (element.Title === pm.ID) {
        //         _brand = element.ID;
        //     }
        // });
        this.PMForm.setValue({
            Name: pm.BrandOwner.Name,
        });
        this.BrandForm.setValue({
            Title: pm.Title,
        });
    }
    onDelete(pm: any) {
        let id: any;
        this.PMDataEdit.forEach(element => {
            if (element.BrandOwner.ID === pm.ID) {
                id = element.ID;
            }
        });
        this._confirmationService.confirm({
            message: 'Are you sure that you want to delete?',
            accept: () => {
                this._commonService.deletePM(id)
                    .subscribe(
                    (results: any) => {
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getPMList();
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
        });

    }
    getAssignToUsers(event: any) {
        let query = event.query;
        this._commonService.getAssignToUsers(query)
            .subscribe(
            (results: any) => {
                this.assignToUsers = results;
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    getBrands(event: any) {
        let query = event.query;
        this._commonService.getBrands(query)
            .subscribe(
            (results: any) => {
                this.brands = results;
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onSubmit({ value, valid }: { value: any, valid: boolean }) {
        if (valid) {
            if (value.Title.Name !== undefined) {
                this.errorFlag = false;
                if (this.Id === '') {
                    let Payload = {
                        'BrandOwner': {
                            'ID': value.Title.ID
                        }
                    };
                    this._commonService.addPM(Payload)
                        .subscribe(
                        (results: any) => {
                            this.Id = '';
                            this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                            this.getPMList();
                            this.showPMForm = false;
                        },
                        error => {
                            this.errorMessage = <any>error;
                            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                        });
                }
                if (this.Id !== '') {
                    let Payload = {
                        'BrandOwner': {
                            'ID': value.Title.ID
                        },
                        'ID': this.Id
                    };
                    this._commonService.updatePM(Payload)
                        .subscribe(
                        (results: any) => {
                            this.Id = '';
                            this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                            this.getPMList();
                            this.showPMForm = false;
                        },
                        error => {
                            this.errorMessage = <any>error;
                            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                        });
                }
            } else {
                this.errorFlag = true;
            }
        } else {
            this.errorFlag = true;
        }

    }
}
