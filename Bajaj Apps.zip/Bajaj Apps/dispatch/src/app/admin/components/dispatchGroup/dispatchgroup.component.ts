import { Component, OnInit, NgModule, trigger, transition, style, animate, state, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { MessageService } from '../../../shared/services/message.service';
import { CommonService } from '../../../shared/services/common.service';
import { ConfirmationService } from 'primeng/primeng';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SelectItem } from 'primeng/primeng';
import { System } from '../../model/system';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-dispatchgroup',
    templateUrl: 'dispatchgroup.component.html',
    styleUrls: ['dispatchgroup.component.css'],
    providers: [ConfirmationService]
})
export class DispatchGroupComponent implements OnInit {
    data: any[] = [];
    DispatchGroupData: any[] = [];
    DispatchData: any[];
    assignToUsers: any[];
    errorMessage: string;
    showDispatchGroupForm: boolean = false;
    DispatchGroupForm: FormGroup;
    Id: any = '';
    errorFlag: boolean = false;
    // @Output() dashboardFlag = new EventEmitter();
    constructor(private _messageService: MessageService,
        private _commonService: CommonService,
        private _confirmationService: ConfirmationService,
        private formBuilder: FormBuilder) {
        // this.DispatchGroupData = [];
    }
    ngOnInit() {
        this.setForm();
        this.getDispatchGroupList();
    }
    setForm() {
        this.DispatchGroupForm = this.formBuilder.group({
            Title: ['']
        });
    }
    onAddDesign() {
        this.setForm();
        this.showDispatchGroupForm = true;
        this.errorFlag = false;
    }
    onCancel() {
        this.showDispatchGroupForm = false;
    }
    getDispatchGroupList() {
        this.data = [];
        this.DispatchGroupData = [];
        this._commonService.getDispatchGroup()
            .subscribe(
            (results: any) => {
                results.forEach((element: any) => {
                    this.DispatchGroupData.push(element.DispatchUsers);
                });
                this.data = this.DispatchGroupData;
                this.DispatchData = results;
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onEdit(dispatch: any) {
        this.showDispatchGroupForm = true;
        this.DispatchData.forEach(element => {
            if (element.DispatchUsers.ID === dispatch.ID) {
                this.Id = element.ID;
            }
        });
        this.DispatchGroupForm.setValue({
            Title: dispatch.Name
        });
    }
    onDelete(dispatch: any) {
        let id: any;
        this.DispatchData.forEach(element => {
            if (element.DispatchUsers.ID === dispatch.ID) {
                id = element.ID;
            }
        });
        this._confirmationService.confirm({
            message: 'Are you sure that you want to delete?',
            accept: () => {
                this._commonService.deleteDispatchGroup(id)
                    .subscribe(
                    (results: any) => {
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getDispatchGroupList();
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
        });
    }
    getAssignToUsers(event: any) {
        let query = event.query;
        this._commonService.getAssignToUsers(query)
            .subscribe(
            (results: any) => {
                this.assignToUsers = results;
                // this.assignToUsers =[ {'ID':1,'name':'Amol'},{'ID':2,'name':'Amul'}];
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onSubmit({ value, valid }: { value: any, valid: boolean }) {
        if (valid) {
            if (value.Title.Name !== undefined) {
                this.errorFlag = false;
                if (this.Id === '') {
                    let payload = { 'DispatchUsers': { 'ID': value.Title.ID } };
                    this._commonService.addDispatchGroup(payload)
                        .subscribe(
                        (results: any) => {
                            this.Id = '';
                            this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                            this.getDispatchGroupList();
                            this.showDispatchGroupForm = false;
                        },
                        error => {
                            this.errorMessage = <any>error;
                            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                        });
                }
                if (this.Id !== '') {
                    value.ID = this.Id;
                    let payload = { 'ID': this.Id, 'DispatchUsers': { 'ID': value.Title.ID } };
                    this._commonService.updateDispatchGroup(payload)
                        .subscribe(
                        (results: any) => {
                            this.Id = '';
                            this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                            this.getDispatchGroupList();
                            this.showDispatchGroupForm = false;
                        },
                        error => {
                            this.errorMessage = <any>error;
                            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                        });
                }
            } else {
                this.errorFlag = true;
            }
        } else {
            this.errorFlag = true;
        }

    }
}
