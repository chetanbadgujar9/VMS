import { Component, OnInit, NgModule, trigger, transition, style, animate, state, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { MessageService } from '../../../shared/services/message.service';
import { CommonService } from '../../../shared/services/common.service';
import { ConfirmationService } from 'primeng/primeng';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SelectItem } from 'primeng/primeng';
import { DashboardService } from '../../../dashboard/services/dashboard.service';
import { Brand } from '../../model/brand';
import { Domestic } from '../../../dashboard/models/domestic';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-domesticgm',
    templateUrl: 'domesticGM.component.html',
    styleUrls: ['domesticGM.component.css'],
    providers: [ConfirmationService]
})
export class DomesticGMComponent implements OnInit {
    DispatchData: any[];
    cols: any[];
    loggedInUserData: any = '';
    errorFlagForApproveReject: boolean = false;
    ApproveButton: boolean = false;
    RejectButton: boolean = false;
    ApproveRejectRequestForm: FormGroup;
    Id: any = '';
    errorFlag: boolean = false;
    errorMessage: any;
    constructor(private _messageService: MessageService,
        private _commonService: CommonService,
        private _confirmationService: ConfirmationService,
        private _dashboardservice: DashboardService,
        private formBuilder: FormBuilder) {
    }
    ngOnInit() {
        this.getAllGMPendingRequest();
    }
    getAllGMPendingRequest() {
        this.DispatchData = [];
        this._commonService.getAllPendingGLRequest_Admin('7. Pending with GM/VP')
            .subscribe(
            (results: any) => {
                if (results.length > 0) {
                    this.DispatchData = results;
                }
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onApproveRequest(request: Domestic) {
        this._confirmationService.confirm({
            message: 'Are you sure that you want to Approve Request?',
            accept: () => {
                let payload = {
                    'ID': request.ID,
                    'GMApproval': '2. Approved',
                    'DispatchDestination': request.DispatchDestination,
                    'DispatchMode': request.DispatchMode,
                    'DispatchType': request.DispatchType,
                    'GMComments': request.GMComments,
                    'CreatedBy': request.CreatedBy,
                    'CreatedBy1': request.CreatedBy1
                };
                this._commonService.gmApproval_Admin(payload)
                    .subscribe(
                    (results: any) => {
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getAllGMPendingRequest();
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
        });
    }
    onRejectRequest(request: Domestic) {
        this._confirmationService.confirm({
            message: 'Are you sure that you want to Reject Request?',
            accept: () => {
                let payload = {
                    'ID': request.ID,
                    'GMApproval': '3. Rejected',
                    'DispatchDestination': request.DispatchDestination,
                    'DispatchMode': request.DispatchMode,
                    'DispatchType': request.DispatchType,
                    'GMComments': request.GMComments,
                    'CreatedBy': request.CreatedBy,
                    'CreatedBy1': request.CreatedBy1
                };
                this._commonService.gmApproval_Admin(payload)
                    .subscribe(
                    (results: any) => {
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getAllGMPendingRequest();
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
        });
    }

}
