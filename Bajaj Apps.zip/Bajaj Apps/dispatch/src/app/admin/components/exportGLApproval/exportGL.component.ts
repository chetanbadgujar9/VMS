import { Component, OnInit, NgModule, trigger, transition, style, animate, state, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { MessageService } from '../../../shared/services/message.service';
import { CommonService } from '../../../shared/services/common.service';
import { ConfirmationService } from 'primeng/primeng';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SelectItem } from 'primeng/primeng';
import { DashboardService } from '../../../dashboard/services/dashboard.service';
import { Brand } from '../../model/brand';
import { Export } from '../../../export/models/export';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-exportgl',
    templateUrl: 'exportGL.component.html',
    styleUrls: ['exportGL.component.css'],
    providers: [ConfirmationService]
})
export class ExportGLComponent implements OnInit {
    DispatchData: any[];
    cols: any[];
    loggedInUserData: any = '';
    errorFlagForApproveReject: boolean = false;
    ApproveButton: boolean = false;
    RejectButton: boolean = false;
    ApproveRejectRequestForm: FormGroup;
    Id: any = '';
    errorFlag: boolean = false;
    errorMessage: any;
    constructor(private _messageService: MessageService,
        private _commonService: CommonService,
        private _confirmationService: ConfirmationService,
        private _dashboardservice: DashboardService,
        private formBuilder: FormBuilder) {
    }
    ngOnInit() {
        this.getAllGLPendingRequest();
    }
    getAllGLPendingRequest() {
        this.DispatchData = [];
        this._commonService.getAllExportPendingGLRequest_Admin('1. Pending with GL')
            .subscribe(
            (results: any) => {
                if (results.length > 0) {
                    this.DispatchData = results;
                }
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onApproveRequest(request: Export) {
        this._confirmationService.confirm({
            message: 'Are you sure that you want to Approve Request?',
            accept: () => {
                let payload = {
                    'ID': request.ID,
                    'GLApproval': '2. Approved',
                    'DispatchMode': request.DispatchMode,
                    'DispatchType': request.DispatchType,
                    'GLComments': request.GLComments,
                    'CreatedBy': request.CreatedBy,
                    'CreatedBy1': request.CreatedBy1
                };
                this._commonService.glExportApproval_Admin(payload)
                    .subscribe(
                    (results: any) => {
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getAllGLPendingRequest();
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
        });
    }
    onRejectRequest(request: Export) {
        this._confirmationService.confirm({
            message: 'Are you sure that you want to Reject Request?',
            accept: () => {
                let payload = {
                    'ID': request.ID,
                    'GLApproval': '3. Rejected',
                    'DispatchMode': request.DispatchMode,
                    'DispatchType': request.DispatchType,
                    'GLComments': request.GLComments,
                    'CreatedBy': request.CreatedBy,
                    'CreatedBy1': request.CreatedBy1
                };
                this._commonService.glExportApproval_Admin(payload)
                    .subscribe(
                    (results: any) => {
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getAllGLPendingRequest();
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
        });
    }
}
