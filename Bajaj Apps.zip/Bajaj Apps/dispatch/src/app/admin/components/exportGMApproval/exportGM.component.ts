import { Component, OnInit, NgModule, trigger, transition, style, animate, state, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { MessageService } from '../../../shared/services/message.service';
import { CommonService } from '../../../shared/services/common.service';
import { ConfirmationService } from 'primeng/primeng';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SelectItem } from 'primeng/primeng';
import { DashboardService } from '../../../dashboard/services/dashboard.service';
import { Brand } from '../../model/brand';
import { Export } from '../../../export/models/export';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-exportgm',
    templateUrl: 'exportGM.component.html',
    styleUrls: ['exportGM.component.css'],
    providers: [ConfirmationService]
})
export class ExportGMComponent implements OnInit {
    DispatchData: any[];
    cols: any[];
    loggedInUserData: any = '';
    errorFlagForApproveReject: boolean = false;
    ApproveButton: boolean = false;
    RejectButton: boolean = false;
    ApproveRejectRequestForm: FormGroup;
    Id: any = '';
    errorFlag: boolean = false;
    errorMessage: any;
    constructor(private _messageService: MessageService,
        private _commonService: CommonService,
        private _confirmationService: ConfirmationService,
        private _dashboardservice: DashboardService,
        private formBuilder: FormBuilder) {
    }
    ngOnInit() {
        this.getAllGMPendingRequest();
    }
    getAllGMPendingRequest() {
        this.DispatchData = [];
        this._commonService.getAllExportPendingGLRequest_Admin('3. Pending with GM/VP')
            .subscribe(
            (results: any) => {
                if (results.length > 0) {
                    this.DispatchData = results;
                }
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onApproveRequest(request: Export) {
        this._confirmationService.confirm({
            message: 'Are you sure that you want to Approve Request?',
            accept: () => {
                let payload = {
                    'ID': request.ID,
                    'GMApproval': '2. Approved',
                    'DispatchMode': request.DispatchMode,
                    'DispatchType': request.DispatchType,
                    'GMComments': request.GMComments,
                    'CreatedBy': request.CreatedBy,
                    'CreatedBy1': request.CreatedBy1
                };
                this._commonService.gmExportApproval_Admin(payload)
                    .subscribe(
                    (results: any) => {
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getAllGMPendingRequest();
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
        });
    }
    onRejectRequest(request: Export) {
        this._confirmationService.confirm({
            message: 'Are you sure that you want to Reject Request?',
            accept: () => {
                let payload = {
                    'ID': request.ID,
                    'GMApproval': '3. Rejected',
                    'DispatchMode': request.DispatchMode,
                    'DispatchType': request.DispatchType,
                    'GMComments': request.GMComments,
                    'CreatedBy': request.CreatedBy,
                    'CreatedBy1': request.CreatedBy1
                };
                this._commonService.gmExportApproval_Admin(payload)
                    .subscribe(
                    (results: any) => {
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getAllGMPendingRequest();
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
        });
    }
}
