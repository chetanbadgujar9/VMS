import { Component, OnInit, NgModule, trigger, transition, style, animate, state, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { MessageService } from '../../../shared/services/message.service';
import { CommonService } from '../../../shared/services/common.service';
import { ConfirmationService } from 'primeng/primeng';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SelectItem } from 'primeng/primeng';
import { Stage } from '../../model/stage';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-transportationmode',
    templateUrl: 'transportationmode.component.html',
    styleUrls: ['transportationmode.component.css'],
    providers: [ConfirmationService]
})
export class TransportationModeComponent implements OnInit {
    TransportationData: any[] = [];
    errorMessage: string;
    showTransportationForm: boolean = false;
    TransportationForm: FormGroup;
    Id: any = '';
    errorFlag: boolean = false;
    constructor(private _messageService: MessageService,
        private _commonService: CommonService,
        private _confirmationService: ConfirmationService,
        private formBuilder: FormBuilder) {
    }
    ngOnInit() {
        this.setForm();
        this.getTransportationList();
    }
    setForm() {
        this.TransportationForm = this.formBuilder.group({
            Title: ['', [Validators.required]]
        });
    }
    onAddTransportation() {
        this.setForm();
        this.errorFlag = false;
        this.showTransportationForm = true;
    }
    onCancel() {
        this.showTransportationForm = false;
    }
    getTransportationList() {
        this._commonService.getTransportationMode()
            .subscribe(
            (results: any) => {
                this.TransportationData = results;
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onEdit(country: any) {
        this.showTransportationForm = true;
        this.Id = country.ID;
        this.TransportationForm.setValue({
            Title: country.Title ? country.Title : ''
        });
    }
    onDelete(brand: any) {
        this._confirmationService.confirm({
            message: 'Are you sure that you want to delete?',
            accept: () => {
                this._commonService.deleteTransportationMode(brand)
                    .subscribe(
                    (results: any) => {
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getTransportationList();
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
        });
    }
    onSubmit({ value, valid }: { value: any, valid: boolean }) {
        if (valid) {
            value.Title = value.Title ? value.Title.replace(/'/g, "\\'").trim() : '';
            if (this.Id === '') {
                this._commonService.addTransportationMode(value)
                    .subscribe(
                    (results: any) => {
                        this.Id = '';
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getTransportationList();
                        this.showTransportationForm = false;
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
            if (this.Id !== '') {
                value.ID = this.Id;
                this._commonService.updateTransportationMode(value)
                    .subscribe(
                    (results: any) => {
                        this.Id = '';
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getTransportationList();
                        this.showTransportationForm = false;
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }

        } else {
            this.errorFlag = true;
        }

    }
}
