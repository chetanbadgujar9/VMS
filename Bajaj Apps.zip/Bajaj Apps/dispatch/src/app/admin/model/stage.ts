export class Stage {
    constructor(
        public ID: string,
        public Title: string
    ) { }
}