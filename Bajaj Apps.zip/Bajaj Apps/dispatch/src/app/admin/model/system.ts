export class System {
    constructor(
        public ID: string,
        public Group: string,
        public SubGroup: string,
        public QMEmail1: string,
        public QMEmail2: string,
        public QMEmail3: string,
        public QMEmail4: string,
        public QMEmail5: string,
        public QMEmail6: string,
        public QMEmail7: string,
        public QMEmail8: string,
        public QMEmail9: string,
        public QMEmail10: string
    ) { }
}