export class Testtype {
    constructor(
        public ID: string,
        public TestType: string,
        public TestSubType: string,
        public OwnerName: { "ID": number, "name": string },
        public OwnerEmail: string
    ) { }
}