import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/index';
import { AboutComponent } from './aboutMe/components/aboutme.component';
import {
  CountryComponent
  , DispatchGroupComponent
  , DomesticGLComponent
  , DomesticGMComponent
  , ExportGLComponent
  , ExportGMComponent
  , ExportL1Component
  , GMComponent
  , PlantComponent
  , PMComponent
  , StoreLocationComponent
  , TransportationModeComponent
} from './admin/index';
import { UnAuthorizedComponent } from './unAuthorized/components/unauthorized.component';
import { ExportComponent } from './export/components/export.component';

const routes: Routes = [
  { path: 'country', component: CountryComponent },
  { path: 'dispatchGroup', component: DispatchGroupComponent },
  { path: 'gm', component: GMComponent },
  { path: 'plant', component: PlantComponent },
  { path: 'pm', component: PMComponent },
  { path: 'storeLocation', component: StoreLocationComponent },
  { path: 'transportationMode', component: TransportationModeComponent },
  { path: 'domesticGL', component: DomesticGLComponent },
  { path: 'domesticGM', component: DomesticGMComponent },
  { path: 'exportGL', component: ExportGLComponent },
  { path: 'exportL1', component: ExportL1Component },
  { path: 'exportGM', component: ExportGMComponent },
  { path: 'aboutMe', component: AboutComponent },
  { path: 'unauthorized/:id', component: UnAuthorizedComponent },
  { path: 'export', component: ExportComponent },
  { path: 'domestic', component: DashboardComponent, pathMatch: 'full' },
  { path: '**', component: DashboardComponent },
  { path: 'DispatchRequestApp/dist', redirectTo: 'domestic', pathMatch: 'full' }
];

@NgModule({
  imports: [
    RouterModule.forRoot(
      routes
    )
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }

