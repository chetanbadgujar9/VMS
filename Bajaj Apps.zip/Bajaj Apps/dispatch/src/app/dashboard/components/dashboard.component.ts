import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthInfo } from '../models/authInfo';
import { CommonService } from '../../shared/services/common.service';
import { MessageService } from '../../shared/services/message.service';
import { DashboardService } from '../services/dashboard.service';
import { Domestic } from '../models/domestic';
import { User } from '../models/loginUser';
import { DISABLED } from '@angular/forms/src/model';
import { constants } from '../models/constants';
declare var saveAs: any;
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
  moduleId: module.id,
  selector: 'sd-dashboard',
  templateUrl: 'dashboard.component.html',
  styleUrls: ['dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  cars: any[] = [];
  rmsMenu: any[];
  brandData: any[];
  dispatchType: any[];
  transportationMode: any[];
  plantData: any[];
  DomesticData: any[];
  counterData: any[];
  GMApprovalData: Domestic;
  StoreApprovalData: Domestic;
  viewData: Domestic;
  attachmentURL: any = {};

  /** Flags Variables */
  flag: boolean = true;
  showDomesticAddForm: boolean = false;
  showApproveRejectForm_GL: boolean = false;
  showActionForm_Req: boolean = false;
  showActionForm_GM: boolean = false;
  showActionForm_Store: boolean = false;
  showViewForm: boolean = false;
  errorFlagForAdd: boolean = false;
  disabledSubmit: boolean = false;
  disabledVendorCode: boolean = false;
  disabledVendorName: boolean = false;
  disabledPR: boolean = false;
  disabledPlant: boolean = false;
  errorFlagForApproveReject_GL: boolean = false;
  errorFlagForReview_Req: boolean = false;
  ApproveButton_GL: boolean = false;
  RejectButton_GL: boolean = false;
  errRequesterComments: boolean = false;
  errGMVPComments: boolean = false;
  errDispatchDetails: boolean = false;
  errStoreComments: boolean = false;
  errGDNote: boolean = false;
  errGRNNo: boolean = false;
  errSAPUpdate: boolean = false;
  errSAPStatus: boolean = false;
  isReturnable: boolean = true;

  /**General Variables */
  loggedInUser: string;
  loginName: string;
  errorMessage: string;
  minDate: Date;
  filesData: any;
  fileName: string = '';
  contactno: any = '';
  userRole: any;
  status: any = constants.PendingwithGL; // '1. Pending with GL';
  headingColor: any = constants.PendingwithGL_Color;
  loggedInUserRole: string;
  requestID: any;
  attachmnet: any;
  CreatedBy: any;
  returnableDate: Date;
  dispatchDate: Date;
  CreatedBy1: any;
  binaryFileToDownload: string;
  StoreAllCounter: any;
  errorFlagForSearch: boolean = false;
  /** Model Variable */
  model: AuthInfo;
  loggedInUserData: User = new User();

  /** Form Varialbes */
  AddDomesticForm: FormGroup;
  ApproveReject_GL: FormGroup;
  SubmitAction_Req: FormGroup;
  showSearchForm: boolean = false;
  SearchDispatchForm: FormGroup;

  constructor(private _commonService: CommonService, private _messageService: MessageService,
    private _router: Router, private formBuilder: FormBuilder, private _dashboardService: DashboardService) {
    this.model = new AuthInfo('password', '', '');
    this.filesData = new Array<File>();
    this.attachmentURL = {
      'FileName': '',
      'ServerRelativeUrl': ''
    };
  }

  ngOnInit() {
    this.flag = true;
    this.minDate = new Date();
    // this.loginName = 'cnt_shaileshs';
    // this.loggedInUser = 'shailesh sangekar';

    // this.loginName = 'tcctest2';
    // this.loggedInUser = 'tcctest2';

    this.loginName = sessionStorage.getItem('Username') ? sessionStorage.getItem('Username').split('\\')[1] : '';
    this.loggedInUser = sessionStorage.getItem('UserTitle') ? sessionStorage.getItem('UserTitle') : '';
    this.setAddDomesticForm();
    this.setApproveReject_GL();
    this.setSubmitAction_Req();
    this.setSearchDispatchForm();
    this.dispatchType = [{ 'Title': '1. Chargeable' },
    { 'Title': '2. Not Charged' },
    { 'Title': '4. Loan Basis' },
    { 'Title': '6. Stock Transfer Order' }];
    if (sessionStorage.getItem('access_token') === null) {
      this.getAuthToken();
    } else {
      this.getRMSMenus();
      this.getAdminAccess(this.loginName);
      this.getGMList();
    }
    this.isReturnable = true;
  }
  /** Entry Point */
  getAuthToken() {
    this.model.UserName = this.loginName;
    this.model.Password = '';
    this._commonService.getAuthToken(this.model)
      .subscribe(
      (results: any) => {
        this.getRMSMenus();
        this.getAdminAccess(this.loginName);
        this.getGMList();
      },
      error => {
        this.errorMessage = <any>error;
        this._router.navigate(['/unauthorized',
          'You are not Authorized to access this site due to UGP mapping does not exist. Please contact Ahead portal support team.']);
      });
  }
  getRMSMenus() {
    this._commonService.getRMSMenus()
      .subscribe(
      (results: any) => {
        this.rmsMenu = results;
        this._messageService.AddRMSMenu(this.rmsMenu);
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getAdminAccess(username: any) {
    this._commonService.getAdminAccess(username)
      .subscribe((results: any) => {
        if (Object.keys(results).length !== 0) {
          this._messageService.AddAdminAccess(true);
        }
      });
  }
  getGMList() {
    this._commonService.getGMList()
      .subscribe((results: any) => {
        if (results[0].GMName.Name === this.loggedInUser) {
          this.userRole = 'GM';
          sessionStorage.setItem('USER_ROLE', this.userRole);
          this._messageService.AddUserRole(this.userRole);
          this.getCounter_GM();
          this.onGLPending_GM();
          this.getLoggedInUserDetails();
        } else {
          this.getDispatchGroupList();
        }
      });
  }
  getDispatchGroupList() {
    this._commonService.getDispatchGroupList(this.loggedInUser)
      .subscribe((results: any) => {
        if (Object.keys(results).length > 0) {
          this.userRole = 'Store';
          sessionStorage.setItem('USER_ROLE', this.userRole);
          this._messageService.AddUserRole(this.userRole);
          this.getCounters_Stores();
          this.onGLPending();
          this.getLoggedInUserDetails();
        } else {
          this.getLoggedInUserDetails();
        }
      });
  }
  getLoggedInUserDetails() {
    this._commonService.getLoggedInUserDetails(this.loggedInUser ? this.loggedInUser : '')
      .subscribe(
      (results: any) => {
        if (Object.keys(results).length !== 0) {
          this.loggedInUserData = results;
          this.loggedInUserRole = results.Role2;
          this._messageService.AddUserRole(this.loggedInUserRole);
          sessionStorage.setItem('loggedInUserName', results.domainid.UserName);
          sessionStorage.setItem('loggedInUserRole', this.loggedInUserRole);
          sessionStorage.setItem('loggedInUserData', JSON.stringify(results));
          if (this.userRole !== 'Store') {
            if (this.loggedInUserRole.toLowerCase() === 'engineer' || this.loggedInUserRole.toLowerCase() === 'designer') {
              this.userRole = 'Requester';
              sessionStorage.setItem('USER_ROLE', this.userRole);
              this._messageService.AddUserRole(this.userRole);
              this.getCounters_Requester();
              this.onGLPending();
            } else if (this.loggedInUserRole.toLowerCase() === 'group leader') {
              this.userRole = 'GL';
              sessionStorage.setItem('USER_ROLE', this.userRole);
              this._messageService.AddUserRole(this.userRole);
              this.getCounters_GL();
              this.onGLPending_GL();
            } else if (this.loggedInUserRole.toLowerCase() === 'platform leader') {
              if (this.userRole !== 'GM') {
                this.userRole = 'L1';
                sessionStorage.setItem('USER_ROLE', this.userRole);
                this._messageService.AddUserRole(this.userRole);
                this.getCounters_GL();
                this.onGLPending_GL();
              }

              // this._router.navigate(['/export']);
            }
          }
        } else {
          this._router.navigate(['/unauthorized',
            'You are not Authorized to access this site due to User mapping does not exist. Please contact Ahead portal support team.']);
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }

  /** on Counter Click */
  onGLPending() {
    this.hideForms();
    this.status = constants.PendingwithGL; // '1. Pending with GL';
    this.headingColor = constants.PendingwithGL_Color;
    if (this.userRole === 'Store') {
      this.getStoreTotalCount(this.status);
      this.getDocmesticDispatchReq_Store(this.status);
    }
    if (this.userRole === 'Requester') {
      this.getDocmesticDispatchReq_Requester(this.status);
    }
    if (this.userRole === 'GL' || this.userRole === 'L1') {
      this.getDocmesticDispatchReq_GL(this.status);
    }
  }
  onGMPending() {
    this.hideForms();
    this.status = constants.PendingwithGMVP; // '7. Pending with GM/VP';
    this.headingColor = constants.PendingwithGMVP_Color;
    if (this.userRole === 'Store') {
      this.getStoreTotalCount(this.status);
      this.getDocmesticDispatchReq_Store(this.status);
    }
    if (this.userRole === 'Requester') {
      this.getDocmesticDispatchReq_Requester(this.status);
    }
  }
  onStoresPending() {
    this.hideForms();
    this.errDispatchDetails = false;
    this.errStoreComments = false;
    this.errSAPStatus = false;
    this.errGDNote = false;
    this.errGRNNo = false;
    this.errSAPUpdate = false;
    this.status = constants.PendingwithStores; // '2. Pending with Stores';
    this.headingColor = constants.PendingwithStores_Color;
    if (this.userRole === 'Store') {
      this.getStoreTotalCount(this.status);
      this.getDocmesticDispatchReq_Store(this.status);
    }
    if (this.userRole === 'Requester') {
      this.getDocmesticDispatchReq_Requester(this.status);
    }
  }
  onSAPPending() {
    this.hideForms();
    this.errDispatchDetails = false;
    this.errStoreComments = false;
    this.errSAPStatus = false;
    this.errGDNote = false;
    this.errGRNNo = false;
    this.errSAPUpdate = false;
    this.status = constants.PendingwithSAPTeam; // '9. Pending with SAP Team';
    this.headingColor = constants.PendingwithSAPTeam_Color;
    if (this.userRole === 'Store') {
      this.getStoreTotalCount(this.status);
      this.getDocmesticDispatchReq_Store(this.status);
    }
    if (this.userRole === 'Requester') {
      this.getDocmesticDispatchReq_Requester(this.status);
    }
  }
  onRequesterPending() {
    this.hideForms();
    this.status = constants.PendingwithRequester; // '6. Pending with Requester';
    this.headingColor = constants.PendingwithRequester_Color;
    if (this.userRole === 'Store') {
      this.getStoreTotalCount(this.status);
      this.getDocmesticDispatchReq_Store(this.status);
    }
    if (this.userRole === 'Requester') {
      this.getDocmesticDispatchReq_Requester(this.status);
    }
  }
  onMaterialInPending() {
    this.hideForms();
    this.errDispatchDetails = false;
    this.errStoreComments = false;
    this.errSAPStatus = false;
    this.errGDNote = false;
    this.errGRNNo = false;
    this.errSAPUpdate = false;
    this.status = constants.PendingforMaterialIn; // '10. Pending for Material In';
    this.headingColor = constants.PendingforMaterialIn_Color;
    if (this.userRole === 'Store') {
      this.getStoreTotalCount(this.status);
      this.getDocmesticDispatchReq_Store(this.status);
    }
    if (this.userRole === 'Requester') {
      this.getDocmesticDispatchReq_Requester(this.status);
    }
  }
  onGLReject() {
    this.hideForms();
    this.status = constants.RejectedbyGL; // '4. Rejected by GL';
    this.headingColor = constants.RejectedbyGL_Color;
    if (this.userRole === 'Store') {
      this.getStoreTotalCount(this.status);
      this.getDocmesticDispatchReq_Store(this.status);
    }
    if (this.userRole === 'Requester') {
      this.getDocmesticDispatchReq_Requester(this.status);
    }
  }
  onGMReject() {
    this.hideForms();
    this.status = constants.RejectedbyGMVP; // '8. Rejected by GM/VP';
    this.headingColor = constants.RejectedbyGMVP_Color;
    if (this.userRole === 'Store') {
      this.getStoreTotalCount(this.status);
      this.getDocmesticDispatchReq_Store(this.status);
    }
    if (this.userRole === 'Requester') {
      this.getDocmesticDispatchReq_Requester(this.status);
    }
  }
  onReviewed() {
    this.hideForms();
    this.status = constants.ReviewRequest; // '12. Review Request';
    this.headingColor = constants.ReviewRequest_Color;
    if (this.userRole === 'Store') {
      this.getStoreTotalCount(this.status);
      this.getDocmesticDispatchReq_Store(this.status);
    }
    if (this.userRole === 'Requester') {
      this.getDocmesticDispatchReq_Requester(this.status);
    }
  }
  onCancelled() {
    this.hideForms();
    this.status = constants.CancelRequest; // '13. Cancel Request';
    this.headingColor = constants.CancelRequest_Color;
    if (this.userRole === 'Store') {
      this.getStoreTotalCount(this.status);
      this.getDocmesticDispatchReq_Store(this.status);
    }
    if (this.userRole === 'Requester') {
      this.getDocmesticDispatchReq_Requester(this.status);
    }
  }
  onDispatched() {
    this.hideForms();
    this.status = constants.Dispatched; // '3. Dispatched';
    this.headingColor = constants.Dispatched_Color;
    if (this.userRole === 'Store') {
      this.getStoreTotalCount(this.status);
      this.getDocmesticDispatchReq_Store(this.status);
    }
    if (this.userRole === 'Requester') {
      this.getDocmesticDispatchReq_Requester(this.status);
    }
  }
  onPartiallyDispatched() {
    this.hideForms();
    this.status = constants.DispatchedPartially; // '5. Dispatched Partially';
    this.headingColor = constants.DispatchedPartially_Color;
    if (this.userRole === 'Store') {
      this.getStoreTotalCount(this.status);
      this.getDocmesticDispatchReq_Store(this.status);
    }
    if (this.userRole === 'Requester') {
      this.getDocmesticDispatchReq_Requester(this.status);
    }
  }
  onMaterialReceived() {
    this.hideForms();
    this.status = constants.MaterialReceivedRequestClosed; // '11. Material Received-Request Closed';
    this.headingColor = constants.MaterialReceivedRequestClosed_Color;
    if (this.userRole === 'Store') {
      this.getStoreTotalCount(this.status);
      this.getDocmesticDispatchReq_Store(this.status);
    }
    if (this.userRole === 'Requester') {
      this.getDocmesticDispatchReq_Requester(this.status);
    }
  }

  // GL Couters
  onGLApproved_GL() {
    this.hideForms();
    this.status = constants.ApprovedGL; // 'Approved';
    this.headingColor = constants.ApprovedGL_Color;
    this.getDocmesticDispatchReq_GL(this.status);
  }
  onGLReject_GL() {
    this.hideForms();
    this.status = constants.RejectedbyGL;// 'Rejected';
    this.headingColor = constants.RejectedbyGL_Color;
    this.getDocmesticDispatchReq_GL(this.status);

  }
  onGLPending_GL() {
    this.hideForms();
    this.status = constants.PendingGL; // 'Pending';
    this.headingColor = constants.PendingGL_Color;
    this.getDocmesticDispatchReq_GL(this.status);
  }

  // GM Couters
  onGLApproved_GM() {
    this.hideForms();
    this.status = constants.ApprovedGM;
    this.headingColor = constants.ApprovedGM_Color;
    this.getDocmesticDispatchReq_GM(this.status);
  }
  onGLReject_GM() {
    this.hideForms();
    this.status = constants.RejectedGM;
    this.headingColor = constants.RejectedGM_Color;
    this.getDocmesticDispatchReq_GM(this.status);

  }
  onGLPending_GM() {
    this.hideForms();
    this.status = constants.PendingGM;
    this.headingColor = constants.PendingGM_Color;
    this.getDocmesticDispatchReq_GM(this.status);
  }

  getCounter_GM() {
    this._dashboardService.getCounter_GM()
      .subscribe(
      (results: any) => {
        this.counterData = results;
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getStoreTotalCount(status: any) {
    this._dashboardService.getStoreTotalCount(status)
      .subscribe(
      (results: any) => {
        this.StoreAllCounter = results;
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getCounters_Stores() {
    this._dashboardService.getCounters_Stores()
      .subscribe(
      (results: any) => {
        this.counterData = results;
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getCounters_Requester() {
    this._dashboardService.getCounters_Requester()
      .subscribe(
      (results: any) => {
        this.counterData = results;
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getCounters_GL() {
    this._dashboardService.getCounters_GL()
      .subscribe(
      (results: any) => {
        this.counterData = results;
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }

  getDocmesticDispatchReq_GM(status: any) {
    this.DomesticData = [];
    this._dashboardService.getDocmesticDispatchReq_GM(status)
      .subscribe((results: any) => {
        if (results.length > 0) {
          this.DomesticData = results;
        }
      });
  }
  viewAllStoreRequest() {
    this.DomesticData = [];
    this._dashboardService.viewAllStoreRequest(this.status)
      .subscribe(
      (results: any) => {
        if (results.length > 0) {
          this.DomesticData = results;
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getDocmesticDispatchReq_Store(status: any) {
    this.DomesticData = [];
    this._dashboardService.getDocmesticDispatchReq_Store(status)
      .subscribe((results: any) => {
        if (results.length > 0) {
          this.DomesticData = results;
        }
      });
  }
  getDocmesticDispatchReq_Requester(status: any) {
    this.DomesticData = [];
    this._dashboardService.getDocmesticDispatchReq_Requester(status)
      .subscribe((results: any) => {
        if (results.length > 0) {
          this.DomesticData = results;
        }
      });
  }
  getDocmesticDispatchReq_GL(status: any) {
    this.DomesticData = [];
    this._dashboardService.getDocmesticDispatchReq_GL(status)
      .subscribe((results: any) => {
        if (results.length > 0) {
          this.DomesticData = results;
        }
      });
  }

  /** General Functons */
  onAddRequest() {
    this.hideForms();
    this.showDomesticAddForm = true;
    this.errorFlagForAdd = false;
    this.disabledSubmit = false;
    this.showSearchForm = false;
    this.fileName = '';
    this.contactno = '';
    this.setAddDomesticForm();
    this.getBrandMaster();
    this.getTransportationMode();
    this.getPlantMaster();
  }

  onSearch() {
    this.showDomesticAddForm = false;
    this.showViewForm = false;
    // this.showRMGPSelectForm = false;
    // this.showRMGPViewForm = false;
    this.errorFlagForSearch = false;
    this.showSearchForm = true;
    // this.setSearchRMGPForm();
  }

  setSearchDispatchForm() {
    this.SearchDispatchForm = this.formBuilder.group({
      DispatchNo: ['', [Validators.required]]
    });
  }
  onCancelSearchForm() {
    this.showSearchForm = false;
    this.setSearchDispatchForm();
  }

  onSubmitSearchDispatchRequest({ value, valid }: { value: any, valid: boolean }) {
    if (valid) {
      this._dashboardService.searchByDispatchRequestID(value.DispatchNo)
        .subscribe(
        (results: any) => {
          if (results.length > 0) {
            this.DomesticData = results;
            this.status = results[0].Status;
            switch (this.status) {
              case constants.PendingwithGL: this.headingColor = constants.PendingwithGL_Color;
                break;
              case constants.PendingwithGMVP: this.headingColor = constants.PendingwithGMVP_Color;
                break;
              case constants.PendingwithStores: this.headingColor = constants.PendingwithStores_Color;
                break;
              case constants.PendingwithSAPTeam: this.headingColor = constants.PendingwithSAPTeam_Color;
                break;
              case constants.PendingwithRequester: this.headingColor = constants.PendingwithRequester_Color;
                break;
              case constants.PendingforMaterialIn: this.headingColor = constants.PendingforMaterialIn_Color;
                break;
              case constants.RejectedbyGL: this.headingColor = constants.RejectedbyGL_Color;
                break;
              case constants.RejectedbyGMVP: this.headingColor = constants.RejectedbyGMVP_Color;
                break;
              case constants.ReviewRequest: this.headingColor = constants.ReviewRequest_Color;
                break;
              case constants.CancelRequest: this.headingColor = constants.CancelRequest_Color;
                break;
              case constants.Dispatched: this.headingColor = constants.Dispatched_Color;
                break;
              case constants.DispatchedPartially: this.headingColor = constants.DispatchedPartially_Color;
                break;
              case constants.MaterialReceivedRequestClosed: this.headingColor = constants.MaterialReceivedRequestClosed_Color;
                break;
              case constants.ApprovedGL: this.headingColor = constants.ApprovedGL_Color;
                break;
              case constants.RejectedGL: this.headingColor = constants.RejectedGL_Color;
                break;
              case constants.PendingGL: this.headingColor = constants.PendingGL_Color;
                break;
              case constants.ApprovedGM: this.headingColor = constants.ApprovedGM_Color;
                break;
              case constants.RejectedGM: this.headingColor = constants.RejectedGM_Color;
                break;
              case constants.PendingGM: this.headingColor = constants.PendingGM_Color;
                break;

            }
          } else {
            this.DomesticData = [];
          }
        },
        error => {
          this.errorMessage = <any>error;
          this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
        });
    } else {
      this.errorFlagForSearch = true;
    }
  }

  onDispatchDestination(val: any) {
    if (val === '1. Plant') {
      this.dispatchType = [{ 'Title': '1. Chargeable' },
      { 'Title': '2. Not Charged' },
      { 'Title': '4. Loan Basis' },
      { 'Title': '6. Stock Transfer Order' }];
      this.AddDomesticForm.controls['VendorCode'].setValue(' ');
      this.AddDomesticForm.controls['VendorName'].setValue(' ');
      this.AddDomesticForm.controls['VendorCode'].disable();
      this.AddDomesticForm.controls['VendorName'].disable();
      this.AddDomesticForm.controls['PR'].setValue('');
      this.AddDomesticForm.controls['Plant'].setValue('');
      this.AddDomesticForm.controls['PR'].enable();
      this.AddDomesticForm.controls['Plant'].enable();
      this.AddDomesticForm.controls['DispatchMode'].setValue('2. Non-Returnable');
      this.AddDomesticForm.controls['DispatchType'].setValue('6. Stock Transfer Order');
      this.AddDomesticForm.controls['DispatchMode'].disable();
      this.AddDomesticForm.controls['DispatchType'].disable();
    }
    if (val === '2. Vendor') {
      this.AddDomesticForm.controls['VendorCode'].setValue('');
      this.AddDomesticForm.controls['VendorName'].setValue('');
      this.AddDomesticForm.controls['VendorCode'].enable();
      this.AddDomesticForm.controls['VendorName'].enable();
      this.AddDomesticForm.controls['DispatchMode'].setValue('');
      this.AddDomesticForm.controls['DispatchType'].setValue('');
      this.AddDomesticForm.controls['PR'].setValue(' ');
      this.AddDomesticForm.controls['Plant'].setValue(' ');
      this.AddDomesticForm.controls['PR'].disable();
      this.AddDomesticForm.controls['Plant'].disable();
      this.AddDomesticForm.controls['DispatchMode'].enable();
      this.AddDomesticForm.controls['DispatchType'].enable();
    }
  }
  onDispatchMode(val: any) {
    if (val === '1. Returnable') {
      this.dispatchType = [];
      this.dispatchType = [{ 'Title': '4. Loan Basis' }, { 'Title': '5. Job Work' }];
      this.AddDomesticForm.controls['DispatchType'].setValue('');
      this.isReturnable = true;
    }
    if (val === '2. Non-Returnable' || val === '3. Processing') {
      this.dispatchType = [];
      this.dispatchType = [{ 'Title': '1. Chargeable' }, { 'Title': '2. Not Charged' }];
      this.AddDomesticForm.controls['DispatchType'].setValue('');
      this.isReturnable = false;
    }
  }
  onStatus(val: any) {
    if (val === '14. Continue Request') {
      this.SubmitAction_Req.controls['RequesterComments'].enable();
    } else {
      this.SubmitAction_Req.controls['RequesterComments'].disable();
    }
  }
  downloadFile(RMGP: Domestic) {
    this.attachmentURL.FileName = RMGP.AttachmentFiles[0].FileName;
    this.attachmentURL.ServerRelativeUrl = RMGP.AttachmentFiles[0].ServerRelativeUrl;
    this.onDownloadFile();
  }
  onDownloadFile() {
    this._dashboardService.getDownloadedFile(this.attachmentURL.ServerRelativeUrl)
      .subscribe(
      results => {
        this.binaryFileToDownload = <any>results;
        if (this.binaryFileToDownload) {
          this.Download(this.binaryFileToDownload, this.attachmentURL.ServerRelativeUrl, this.attachmentURL.FileName);
        } else { this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: 'File Not Found' }); }
      },
      error => this.errorMessage = <any>error);
  }
  Download(binaryResume: string, attachmentURL: string, FileName: string) {
    let extension;
    let fileName;
    if (FileName !== null) {
      extension = FileName.split('.')[1] ? FileName.split('.')[1] : 'RMGPExt';
      fileName = FileName.split('.')[0] ? FileName.split('.')[0] : 'RMGPFile';
    }
    // var link = document.createElement('a');
    // link.download = fileName;
    var byteCharacters = atob(binaryResume);
    var byteNumbers = new Array(byteCharacters.length);
    for (var i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    var byteArray = new Uint8Array(byteNumbers);

    switch (extension.toLowerCase()) {
      case 'pdf': var blob1 = new Blob([byteArray], { type: 'application/pdf;charset=utf-8;base64' });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:application/pdf;charset=utf-8;base64,' + binaryResume;
        break;
      case 'xls': var blob1 = new Blob([byteArray], { type: 'application/vnd.ms-excel;charset=utf-8;base64' });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:application/vnd.ms-excel;charset=utf-8;base64,' + binaryResume;
        break;
      case 'xlsx': var blob1 = new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8;base64' });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8;base64,' + binaryResume;
        break;
      case 'tif': var blob1 = new Blob([byteArray], { type: 'image/tiff;charset=utf-8;base64' });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:image/tiff;charset=utf-8;base64,' + binaryResume;
        break;
      case 'tiff': var blob1 = new Blob([byteArray], { type: 'image/tiff;charset=utf-8;base64' });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:image/tiff;charset=utf-8;base64,' + binaryResume;
        break;
      case 'gif': var blob1 = new Blob([byteArray], { type: 'image/GIF;charset=utf-8;base64' });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:image/GIF;charset=utf-8;base64,' + binaryResume;
        break;
      case 'jpeg': var blob1 = new Blob([byteArray], { type: 'image/jpeg;charset=utf-8;base64' });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:image/jpeg;charset=utf-8;base64,' + binaryResume;
        break;
      case 'jpg': var blob1 = new Blob([byteArray], { type: 'image/jpeg;charset=utf-8;base64' });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:image/jpeg;charset=utf-8;base64,' + binaryResume;
        break;
      case 'png': var blob1 = new Blob([byteArray], { type: 'image/png,charset=utf-8' });
        new saveAs(blob1, fileName + '.' + extension);
        //link.href = 'data:image/png;charset=utf-8;base64,' + binaryResume;
        break;
      case 'ppt': var blob1 = new Blob([byteArray], { type: 'application/vnd.ms-powerpoint;charset=utf-8;base64' });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:application/vnd.ms-powerpoint;charset=utf-8;base64,' + binaryResume;
        break;
      case 'pptx': var blob1 = new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.presentationml.presentation;charset=utf-8;base64' });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:application/vnd.openxmlformats-officedocument.presentationml.presentation;charset=utf-8;base64,' + binaryResume;
        break;
      case 'doc':
        var blob1 = new Blob([byteArray], { type: 'application/msword;charset=utf-8;base64' });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:application/msword;charset=utf-8;base64,' + binaryResume;
        break;
      case 'docx':
        var blob1 = new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document;charset=utf-8;base64' });
        window.navigator.msSaveBlob(blob1, fileName + '.' + extension);
        // link.href = 'data:application/vnd.openxmlformats-officedocument.wordprocessingml.document;charset=utf-8;base64,' + binaryResume;
        break;
      case 'zip': var blob1 = new Blob([byteArray], { type: 'application/zip;charset=utf-8;base64' });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:application/zip;charset=utf-8;base64,' + binaryResume;
        break;
      default: //link.href = 'data:application/force-download;charset=utf-8;base64,' + binaryResume;
        break;
    }
    //document.body.appendChild(link);
    //link.click();
  }
  postFile(inputValue: any, type: string): void {
    var format = /[!@#$%^&*+\=\[\]{};':'\\|,.<>\/?]+/;
    try {
      let FileList: FileList = inputValue.target.files;
      if (FileList.length > 0) {
        if (inputValue.target.files[0].size < 10000000) {
          if (inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'docx' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'doc' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'xls' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'xlsx' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'tif' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'tiff' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'gif' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'jpeg' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'jpg' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'png' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'pdf' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'ppt' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'pptx' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'zip') {
            if (!format.test(inputValue.target.files[0].name.split('.')[0])) {
              this.filesData.length = 0;
              for (let i = 0, length = FileList.length; i < length; i++) {
                this.filesData.push(FileList.item(i));
                this.fileName = FileList.item(i).name;
              }
            } else {
              this._messageService.addMessage({
                severity: 'error', summary: 'Error Message',
                detail: 'Please remove special characters from filename'
              });
            }
          } else {
            this._messageService.addMessage({
              severity: 'error', summary: 'Error Message',
              detail: 'Please upload document of type of supperted type'
            });
          }
        } else {
          this._messageService.addMessage({
            severity: 'error', summary: 'Error Message',
            detail: 'Please upload document of size less than 2 MB'
          });
        }
      } else {
        // this.AttachmentURL = false;
        this.fileName = '';
      }
    } catch (error) {
      document.write(error);
    }

  }
  validateContactNum(num: any) {
    let maxlength = 10;
    if (maxlength >= num.toString().length) {
      //
    } else {
      this.contactno = num.toString().substr(0, num.toString().length - 1);
    }

  }
  hideForms() {
    this.showActionForm_GM = false;
    this.showActionForm_Req = false;
    this.showActionForm_Store = false;
    this.showApproveRejectForm_GL = false;
    this.showDomesticAddForm = false;
    this.showViewForm = false;
    this.onCancelSearchForm();
  }
  /** Masters */
  getBrandMaster() {
    this._commonService.getBrandDataDispatch()
      .subscribe(
      (results: any) => {
        this.brandData = results;
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getTransportationMode() {
    this._commonService.getTransportationMode()
      .subscribe(
      (results: any) => {
        this.transportationMode = results;
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getPlantMaster() {
    this._commonService.getPlantMaster()
      .subscribe(
      (results: any) => {
        this.plantData = results;
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }

  /** Set Form Functions */
  setAddDomesticForm() {
    this.AddDomesticForm = this.formBuilder.group({
      From: ['', [Validators.required]],
      DispatchDestination: ['', [Validators.required]],
      DispatchMode: ['', [Validators.required]],
      DispatchType: ['', [Validators.required]],
      DispatchDate: [new Date(), [Validators.required]],
      TransportationMode: ['', [Validators.required]],
      Brand: ['', [Validators.required]],
      ItemCode: ['', Validators.compose([Validators.required, Validators.max(254)])],
      ItemDescription: ['', Validators.compose([Validators.required, Validators.max(254)])],
      Quantity: ['', [Validators.required]],
      PR: ['', [Validators.required]],
      Plant: ['', [Validators.required]],
      VendorCode: ['', [Validators.required]],
      VendorName: ['', [Validators.required]],
      ServicePONo: [''],
      ContactPerson: [''],
      ContactDetail: [''],
      ContactMobileNumber: ['', [Validators.required]],
      ContactEmailID: [''],
      Returnableate: [new Date()],
      PackingInstructions: [''],
      RequesterComments: [''],
      ReasonForDispatch: ['', [Validators.required]],
    });
  }
  setApproveReject_GL() {
    this.ApproveReject_GL = this.formBuilder.group({
      From: [''],
      DispatchDestination: [''],
      DispatchMode: [''],
      DispatchType: [''],
      DispatchDate: [new Date()],
      TransportationMode: [''],
      Brand: [''],
      ItemCode: [''],
      ItemDescription: [''],
      Quantity: [''],
      PR: [''],
      Plant: [''],
      VendorCode: [''],
      VendorName: [''],
      ServicePONo: [''],
      ContactPerson: [''],
      ContactDetail: [''],
      ContactMobileNumber: [''],
      ContactEmailID: [''],
      Returnableate: [new Date()],
      PackingInstructions: [''],
      RequesterComments: [''],
      ReasonForDispatch: [''],
      GLComments: ['', [Validators.required]]
    });
  }
  setSubmitAction_Req() {
    this.SubmitAction_Req = this.formBuilder.group({
      Title: [''],
      From: [''],
      DispatchDestination: [''],
      DispatchMode: [''],
      DispatchType: [''],
      DispatchDate: [new Date()],
      TransportationMode: [''],
      Brand: [''],
      ItemCode: [''],
      ItemDescription: [''],
      Quantity: [''],
      PR: [''],
      Plant: [''],
      VendorCode: [''],
      VendorName: [''],
      ServicePONo: [''],
      ContactPerson: [''],
      ContactDetail: [''],
      ContactMobileNumber: [''],
      ContactEmailID: [''],
      Returnableate: [new Date()],
      PackingInstructions: [''],
      ReasonForDispatch: [''],
      NeedInfoStatus: ['', [Validators.required]],
      GMComments: [''],
      GMApproval: [''],
      GLApproval: [''],
      GLComments: [''],
      Status: ['', [Validators.required]],
      RequesterComments: ['']
    });
  }
  onViewRequest(request: Domestic) {
    this.showActionForm_GM = false;
    this.showActionForm_Req = false;
    this.showActionForm_Store = false;
    this.showApproveRejectForm_GL = false;
    this.showDomesticAddForm = false;
    this.onCancelSearchForm();
    this._dashboardService.getRequestByID(request.ID)
      .subscribe(
      (results: Domestic) => {
        if (Object.keys(results).length !== 0) {
          this.viewData = results;
          this.showViewForm = true;
        }
      });
  }
  onSelectRequest(request: Domestic) {
    this.showViewForm = false;
    this.requestID = request.ID;
    this._dashboardService.getRequestByID(request.ID)
      .subscribe(
      (results: Domestic) => {
        if (Object.keys(results).length !== 0) {
          this.CreatedBy = results.CreatedBy;
          this.attachmnet = results.Attachments;
          this.CreatedBy1 = results.CreatedBy1 ? results.CreatedBy1 : '';
          if (this.userRole === 'GL' || this.userRole === 'L1') {
            this.showApproveRejectForm_GL = true;
            this.errorFlagForApproveReject_GL = false;
            this.ApproveReject_GL.setValue({
              From: results.From ? results.From : '',
              DispatchDestination: results.DispatchDestination ? results.DispatchDestination : '',
              DispatchMode: results.DispatchMode ? results.DispatchMode : '',
              DispatchType: results.DispatchType ? results.DispatchType : '',
              DispatchDate: results.DispatchDate ? new Date(results.DispatchDate) : '',
              TransportationMode: results.TransportationMode ? results.TransportationMode : '',
              Brand: results.Brand ? results.Brand : '',
              ItemCode: results.ItemCode ? results.ItemCode : '',
              ItemDescription: results.ItemDescription ? results.ItemDescription : '',
              Quantity: results.Quantity ? results.Quantity : '',
              PR: results.PR ? results.PR : '',
              Plant: results.Plant ? results.Plant : '',
              VendorCode: results.VendorCode ? results.VendorCode : '',
              VendorName: results.VendorName ? results.VendorName : '',
              ServicePONo: results.ServicePONo ? results.ServicePONo : '',
              ContactPerson: results.ContactPerson ? results.ContactPerson : '',
              ContactDetail: results.ContactDetail ? results.ContactDetail : '',
              ContactMobileNumber: results.ContactMobileNumber ? results.ContactMobileNumber : '',
              ContactEmailID: results.ContactEmailID ? results.ContactEmailID : '',
              Returnableate: results.Returnableate ? new Date(results.Returnableate) : '',
              PackingInstructions: results.PackingInstructions ? results.PackingInstructions : '',
              RequesterComments: results.RequesterComments ? results.RequesterComments : '',
              ReasonForDispatch: results.ReasonForDispatch ? results.ReasonForDispatch : '',
              GLComments: ''
            });
          }
          if (this.userRole === 'Requester' && this.status === '12. Review Request') {
            this.showActionForm_Req = true;
            this.errorFlagForReview_Req = false;
            this.errRequesterComments = false;
            this.SubmitAction_Req.setValue({
              Title: results.Title ? results.Title : '',
              From: results.From ? results.From : '',
              DispatchDestination: results.DispatchDestination ? results.DispatchDestination : '',
              DispatchMode: results.DispatchMode ? results.DispatchMode : '',
              DispatchType: results.DispatchType ? results.DispatchType : '',
              DispatchDate: results.DispatchDate ? new Date(results.DispatchDate) : '',
              TransportationMode: results.TransportationMode ? results.TransportationMode : '',
              Brand: results.Brand ? results.Brand : '',
              ItemCode: results.ItemCode ? results.ItemCode : '',
              ItemDescription: results.ItemDescription ? results.ItemDescription : '',
              Quantity: results.Quantity ? results.Quantity : '',
              PR: results.PR ? results.PR : '',
              Plant: results.Plant ? results.Plant : '',
              VendorCode: results.VendorCode ? results.VendorCode : '',
              VendorName: results.VendorName ? results.VendorName : '',
              ServicePONo: results.ServicePONo ? results.ServicePONo : '',
              ContactPerson: results.ContactPerson ? results.ContactPerson : '',
              ContactDetail: results.ContactDetail ? results.ContactDetail : '',
              ContactMobileNumber: results.ContactMobileNumber ? results.ContactMobileNumber : '',
              ContactEmailID: results.ContactEmailID ? results.ContactEmailID : '',
              Returnableate: results.Returnableate ? new Date(results.Returnableate) : '',
              PackingInstructions: results.PackingInstructions ? results.PackingInstructions : '',
              ReasonForDispatch: results.ReasonForDispatch ? results.ReasonForDispatch : '',
              NeedInfoStatus: results.NeedInfoStatus ? results.NeedInfoStatus : '',
              GMComments: results.GMComments ? results.GMComments : '',
              GMApproval: results.GMApproval ? results.GMApproval : '',
              GLComments: results.GLComments ? results.GLComments : '',
              GLApproval: results.GLApproval ? results.GLApproval : '',
              Status: '',
              RequesterComments: ''
            });
          }
          if (this.userRole === 'Requester' && this.status === '6. Pending with Requester') {
            this.showActionForm_Req = true;
            this.errorFlagForReview_Req = false;
            this.errRequesterComments = false;
            this.SubmitAction_Req.setValue({
              Title: results.Title ? results.Title : '',
              From: results.From ? results.From : '',
              DispatchDestination: results.DispatchDestination ? results.DispatchDestination : '',
              DispatchMode: results.DispatchMode ? results.DispatchMode : '',
              DispatchType: results.DispatchType ? results.DispatchType : '',
              DispatchDate: results.DispatchDate ? new Date(results.DispatchDate) : '',
              TransportationMode: results.TransportationMode ? results.TransportationMode : '',
              Brand: results.Brand ? results.Brand : '',
              ItemCode: results.ItemCode ? results.ItemCode : '',
              ItemDescription: results.ItemDescription ? results.ItemDescription : '',
              Quantity: results.Quantity ? results.Quantity : '',
              PR: results.PR ? results.PR : '',
              Plant: results.Plant ? results.Plant : '',
              VendorCode: results.VendorCode ? results.VendorCode : '',
              VendorName: results.VendorName ? results.VendorName : '',
              ServicePONo: results.ServicePONo ? results.ServicePONo : '',
              ContactPerson: results.ContactPerson ? results.ContactPerson : '',
              ContactDetail: results.ContactDetail ? results.ContactDetail : '',
              ContactMobileNumber: results.ContactMobileNumber ? results.ContactMobileNumber : '',
              ContactEmailID: results.ContactEmailID ? results.ContactEmailID : '',
              Returnableate: results.Returnableate ? new Date(results.Returnableate) : '',
              PackingInstructions: results.PackingInstructions ? results.PackingInstructions : '',
              ReasonForDispatch: results.ReasonForDispatch ? results.ReasonForDispatch : '',
              NeedInfoStatus: '',
              GMComments: results.GMComments ? results.GMComments : '',
              GMApproval: results.GMApproval ? results.GMApproval : '',
              GLComments: results.GLComments ? results.GLComments : '',
              GLApproval: results.GLApproval ? results.GLApproval : '',
              Status: results.Status ? results.Status : '',
              RequesterComments: ''
            });
          }
          if (this.userRole === 'Requester' && this.status === '2. Pending with Stores') {
            this.showActionForm_Req = true;
            this.errorFlagForReview_Req = false;
            this.errRequesterComments = false;
            this.SubmitAction_Req.setValue({
              Title: results.Title ? results.Title : '',
              From: results.From ? results.From : '',
              DispatchDestination: results.DispatchDestination ? results.DispatchDestination : '',
              DispatchMode: results.DispatchMode ? results.DispatchMode : '',
              DispatchType: results.DispatchType ? results.DispatchType : '',
              DispatchDate: results.DispatchDate ? new Date(results.DispatchDate) : '',
              TransportationMode: results.TransportationMode ? results.TransportationMode : '',
              Brand: results.Brand ? results.Brand : '',
              ItemCode: results.ItemCode ? results.ItemCode : '',
              ItemDescription: results.ItemDescription ? results.ItemDescription : '',
              Quantity: results.Quantity ? results.Quantity : '',
              PR: results.PR ? results.PR : '',
              Plant: results.Plant ? results.Plant : '',
              VendorCode: results.VendorCode ? results.VendorCode : '',
              VendorName: results.VendorName ? results.VendorName : '',
              ServicePONo: results.ServicePONo ? results.ServicePONo : '',
              ContactPerson: results.ContactPerson ? results.ContactPerson : '',
              ContactDetail: results.ContactDetail ? results.ContactDetail : '',
              ContactMobileNumber: results.ContactMobileNumber ? results.ContactMobileNumber : '',
              ContactEmailID: results.ContactEmailID ? results.ContactEmailID : '',
              Returnableate: results.Returnableate ? new Date(results.Returnableate) : '',
              PackingInstructions: results.PackingInstructions ? results.PackingInstructions : '',
              ReasonForDispatch: results.ReasonForDispatch ? results.ReasonForDispatch : '',
              NeedInfoStatus: '',
              GMComments: results.GMComments ? results.GMComments : '',
              GMApproval: results.GMApproval ? results.GMApproval : '',
              GLComments: results.GLComments ? results.GLComments : '',
              GLApproval: results.GLApproval ? results.GLApproval : '',
              Status: results.Status ? results.Status : '',
              RequesterComments: ''
            });
          }
          if (this.userRole === 'GM') {
            this.GMApprovalData = results;
            this.showActionForm_GM = true;
            this.errGMVPComments = false;
          }
          if (this.userRole === 'Store' && this.status === '2. Pending with Stores') {
            this.StoreApprovalData = results;
            this.showActionForm_Store = true;
            this.errSAPStatus = false;
            this.errSAPUpdate = false;
            this.errGDNote = false;
            this.errGRNNo = false;
            this.errStoreComments = false;
            this.errDispatchDetails = false;
          }
          if (this.userRole === 'Store' && this.status === '10. Pending for Material In') {
            this.StoreApprovalData = results;
            this.showActionForm_Store = true;
            this.errSAPStatus = false;
            this.errSAPUpdate = false;
            this.errGDNote = false;
            this.errGRNNo = false;
            this.errStoreComments = false;
            this.errDispatchDetails = false;
          }
          if (this.userRole === 'Store' && this.status === '9. Pending with SAP Team') {
            this.StoreApprovalData = results;
            this.showActionForm_Store = true;
            this.errSAPStatus = false;
            this.errSAPUpdate = false;
            this.errGDNote = false;
            this.errGRNNo = false;
            this.errStoreComments = false;
            this.errDispatchDetails = false;
          }
          if (this.userRole === 'Store' && this.status === '5. Dispatched Partially') {
            this.StoreApprovalData = results;
            this.showActionForm_Store = true;
            this.errSAPStatus = false;
            this.errSAPUpdate = false;
            this.errGDNote = false;
            this.errGRNNo = false;
            this.errStoreComments = false;
            this.errDispatchDetails = false;
          }
        }
      });
  }

  /**Submit Actions */
  onSubmitDomestic({ value, valid }: { value: Domestic, valid: boolean }) {
    if (valid) {
      value.ItemCode = value.ItemCode ? value.ItemCode.replace(/'/g, "\\'").trim() : '';
      value.ItemDescription = value.ItemDescription ? value.ItemDescription.replace(/'/g, "\\'").trim() : '';
      value.PR = value.PR ? value.PR.replace(/'/g, "\\'").trim() : '';
      value.VendorCode = value.VendorCode ? value.VendorCode.replace(/'/g, "\\'").trim() : '';
      value.VendorName = value.VendorName ? value.VendorName.replace(/'/g, "\\'").trim() : '';
      value.ContactPerson = value.ContactPerson ? value.ContactPerson.replace(/'/g, "\\'").trim() : '';
      value.ContactDetail = value.ContactDetail ? value.ContactDetail.replace(/'/g, "\\'").trim() : '';
      value.PackingInstructions = value.PackingInstructions ? value.PackingInstructions.replace(/'/g, "\\'").trim() : '';
      value.RequesterComments = value.RequesterComments ? value.RequesterComments.replace(/'/g, "\\'").trim() : '';
      value.ReasonForDispatch = value.ReasonForDispatch ? value.ReasonForDispatch.replace(/'/g, "\\'").trim() : '';
      value.DispatchDate = this.dispatchDate ? this.dispatchDate : new Date();
      value.Returnableate = this.returnableDate ? this.returnableDate : new Date();
      value.CreatedBy1 = this.loggedInUser;
      value.DispatchType = value.DispatchDestination === '1. Plant' ? '6. Stock Transfer Order' : value.DispatchType;
      value.DispatchMode = value.DispatchDestination === '1. Plant' ? '2. Non-Returnable' : value.DispatchMode;
      this.disabledSubmit = true;
      if (this.fileName === '') {
        this._dashboardService.SubmitDomesticRequest(value)
          .subscribe(
          (results: any) => {
            this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
            this.disabledSubmit = false;
            this.showDomesticAddForm = false;
            this.getCounters_Requester();
            this.onGLPending();
          },
          error => {
            this.errorMessage = <any>error;
            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
          });
      }
      if (this.fileName !== '') {
        this._dashboardService.SubmitDomesticRequestWithAttachment(value, this.filesData).then(
          (results: any) => {
            this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results });
            this.disabledSubmit = false;
            this.showDomesticAddForm = false;
            this.getCounters_Requester();
            this.onGLPending();
          },
          (error: any) => {
            this.errorMessage = <any>error;
            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
          });
      }
    } else {
      this.errorFlagForAdd = true;
    }
  }
  onSubmitApproveReject_GL({ value, valid }: { value: Domestic, valid: boolean }) {
    if (valid) {
      value.GLComments = value.GLComments ? value.GLComments.replace(/'/g, "\\'").trim() : '';
      let payload = {};
      if (this.ApproveButton_GL) {
        this.ApproveButton_GL = false;
        this.RejectButton_GL = false;
        payload = {
          'ID': this.requestID,
          'GLApproval': '2. Approved',
          'DispatchDestination': value.DispatchDestination,
          'DispatchMode': value.DispatchMode,
          'DispatchType': value.DispatchType,
          'GLComments': value.GLComments,
          'CreatedBy': this.CreatedBy,
          'CreatedBy1': this.CreatedBy1,
        };
      }
      if (this.RejectButton_GL) {
        this.ApproveButton_GL = false;
        this.RejectButton_GL = false;
        payload = {
          'ID': this.requestID,
          'GLApproval': '3. Rejected',
          'DispatchDestination': value.DispatchDestination,
          'DispatchMode': value.DispatchMode,
          'DispatchType': value.DispatchType,
          'GLComments': value.GLComments,
          'CreatedBy': this.CreatedBy,
          'CreatedBy1': this.CreatedBy1
        };
      }
      this._dashboardService.ApproveReject_GL(payload)
        .subscribe(
        (results: any) => {
          this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
          this.showApproveRejectForm_GL = false;
          this.getCounters_GL();
          this.onGLPending_GL();
        },
        error => {
          this.errorMessage = <any>error;
          this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
        });
    } else {
      this.errorFlagForApproveReject_GL = true;
    }
  }
  onSubmitAction_Requester({ value, valid }: { value: Domestic, valid: boolean }) {
    if (valid) {
      let payload = {};
      value.RequesterComments = value.RequesterComments ? value.RequesterComments.replace(/'/g, "\\'").trim() : '';
      if (this.status === '12. Review Request') {
        if (value.Status === '14. Continue Request' && value.RequesterComments !== '') {
          this.errRequesterComments = false;
          payload = {
            'ID': this.requestID,
            'Status': value.Status,
            'DispatchDestination': value.DispatchDestination,
            'DispatchMode': value.DispatchMode,
            'DispatchType': value.DispatchType,
            'RequesterComments': value.RequesterComments,
            'CreatedBy': this.CreatedBy,
            'CreatedBy1': this.CreatedBy1
          };
          this._dashboardService.SubmitAction_Req(payload)
            .subscribe(
            (results: any) => {
              this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
              this.showActionForm_Req = false;
              this.getCounters_Requester();
              this.onReviewed();
            },
            error => {
              this.errorMessage = <any>error;
              this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
        } else if (value.Status === '13. Cancel Request') {
          this.errRequesterComments = false;
          payload = {
            'ID': this.requestID,
            'Status': value.Status,
            'DispatchDestination': value.DispatchDestination,
            'DispatchMode': value.DispatchMode,
            'DispatchType': value.DispatchType,
            'RequesterComments': value.RequesterComments,
            'CreatedBy': this.CreatedBy,
            'CreatedBy1': this.CreatedBy1
          }
          this._dashboardService.SubmitAction_Req(payload)
            .subscribe(
            (results: any) => {
              this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
              this.showActionForm_Req = false;
              this.getCounters_Requester();
              this.onReviewed();
            },
            error => {
              this.errorMessage = <any>error;
              this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
        } else {
          this.errRequesterComments = true;
        }
      }
      if (this.status === '6. Pending with Requester' || this.status === '2. Pending with Stores') {
        if (value.RequesterComments !== '' && value.RequesterComments !== null) {
          this.errRequesterComments = false;
          payload = {
            'ID': this.requestID,
            'Status': value.Status,
            'DispatchDestination': value.DispatchDestination,
            'DispatchMode': value.DispatchMode,
            'DispatchType': value.DispatchType,
            'RequesterComments': value.RequesterComments,
            'CreatedBy': this.CreatedBy,
            'NeedInfoStatus': value.NeedInfoStatus,
            'CreatedBy1': this.CreatedBy1
          };
          this._dashboardService.SubmitAction_Req(payload)
            .subscribe(
            (results: any) => {
              this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
              this.showActionForm_Req = false;
              this.getCounters_Requester();
              if (this.status === '6. Pending with Requester') {
                this.onRequesterPending();
              }
              if (this.status === '2. Pending with Stores') {
                this.onStoresPending();
              }
            },
            error => {
              this.errorMessage = <any>error;
              this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
        } else {
          this.errRequesterComments = true;
        }
      }

    } else {
      this.errorFlagForReview_Req = true;
    }
  }
  SubmitApprove_GM() {
    if (this.GMApprovalData.GMComments !== null) {
      if (this.GMApprovalData.GMComments !== '') {
        this.GMApprovalData.GMComments = this.GMApprovalData.GMComments ? this.GMApprovalData.GMComments.replace(/'/g, "\\'").trim() : '';
        this.errGMVPComments = false;
        let payload = {
          'ID': this.requestID,
          'GMApproval': '2. Approved',
          'DispatchDestination': this.GMApprovalData.DispatchDestination,
          'DispatchMode': this.GMApprovalData.DispatchMode,
          'DispatchType': this.GMApprovalData.DispatchType,
          'GMComments': this.GMApprovalData.GMComments,
          'CreatedBy': this.CreatedBy,
          'CreatedBy1': this.CreatedBy1
        };
        this._dashboardService.SubmitAction_GM(payload)
          .subscribe(
          (results: any) => {
            this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
            this.showActionForm_GM = false;
            this.getCounter_GM();
            this.onGLPending_GM();
          },
          error => {
            this.errorMessage = <any>error;
            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
          });
      } else {
        this.errGMVPComments = true;
      }
    } else {
      this.errGMVPComments = true;
    }
  }
  SubmitReject_GM() {
    if (this.GMApprovalData.GMComments !== null) {
      if (this.GMApprovalData.GMComments !== '') {
        this.GMApprovalData.GMComments = this.GMApprovalData.GMComments ? this.GMApprovalData.GMComments.replace(/'/g, "\\'").trim() : '';
        this.errGMVPComments = false;
        let payload = {
          'ID': this.requestID,
          'GMApproval': '3. Rejected',
          'DispatchDestination': this.GMApprovalData.DispatchDestination,
          'DispatchMode': this.GMApprovalData.DispatchMode,
          'DispatchType': this.GMApprovalData.DispatchType,
          'GMComments': this.GMApprovalData.GMComments,
          'CreatedBy': this.CreatedBy,
          'CreatedBy1': this.CreatedBy1
        };
        this._dashboardService.SubmitAction_GM(payload)
          .subscribe(
          (results: any) => {
            this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
            this.showActionForm_GM = false;
            this.getCounter_GM();
            this.onGLPending_GM();
          },
          error => {
            this.errorMessage = <any>error;
            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
          });
      } else {
        this.errGMVPComments = true;
      }
    } else {
      this.errGMVPComments = true;
    }
  }
  SubmitApprove_Store() {
    // For Pending With Stores Status
    if (this.status === '2. Pending with Stores') {
      if (this.StoreApprovalData.Status === '3. Dispatched' || this.StoreApprovalData.Status === '5. Dispatched Partially') {
        if (this.StoreApprovalData.GDNote !== null && this.StoreApprovalData.GDNote !== "") {
          this.errGDNote = false;
          if (this.StoreApprovalData.StoresComments !== null && this.StoreApprovalData.StoresComments !== "") {
            this.errStoreComments = false;
            if (this.StoreApprovalData.DispatchDetails !== null && this.StoreApprovalData.DispatchDetails !== "") {
              this.errDispatchDetails = false;
              this.StoreApprovalData.StoresComments = this.StoreApprovalData.StoresComments ?
                this.StoreApprovalData.StoresComments.replace(/'/g, "\\'").trim() : '';
              this.StoreApprovalData.DispatchDetails = this.StoreApprovalData.DispatchDetails ?
                this.StoreApprovalData.DispatchDetails.replace(/'/g, "\\'").trim() : '';
              let payload = {
                'ID': this.requestID,
                'Status': this.StoreApprovalData.Status,
                'DispatchDestination': this.StoreApprovalData.DispatchDestination,
                'DispatchMode': this.StoreApprovalData.DispatchMode,
                'DispatchType': this.StoreApprovalData.DispatchType,
                'CreatedBy': this.CreatedBy,
                'NeedInfoStatus': this.StoreApprovalData.NeedInfoStatus,
                'SAPDataUpdated': this.StoreApprovalData.SAPDataUpdated,
                'GDNote': this.StoreApprovalData.GDNote,
                'StoresComments': this.StoreApprovalData.StoresComments,
                'DispatchDetails': this.StoreApprovalData.DispatchDetails,
                'CreatedBy1': this.CreatedBy1
              }
              this._dashboardService.SubmitAction_Store(payload)
                .subscribe(
                (results: any) => {
                  this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                  this.showActionForm_Store = false;
                  this.getCounters_Stores();
                  if (this.status === '2. Pending with Stores') {
                    this.onStoresPending();
                  } else if (this.status === '10. Pending for Material In') {
                    this.onMaterialInPending();
                  }
                },
                error => {
                  this.errorMessage = <any>error;
                  this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                });
            } else {
              this.errDispatchDetails = true;
            }
          } else {
            this.errStoreComments = true;
          }
        } else {
          this.errGDNote = true;
        }
      }
      else {
        this.errGDNote = false;
        if (this.StoreApprovalData.StoresComments !== null && this.StoreApprovalData.StoresComments !== '') {
          this.errStoreComments = false;
          this.errDispatchDetails = false;
          this.StoreApprovalData.StoresComments = this.StoreApprovalData.StoresComments ?
            this.StoreApprovalData.StoresComments.replace(/'/g, "\\'").trim() : '';
          this.StoreApprovalData.DispatchDetails = this.StoreApprovalData.DispatchDetails ?
            this.StoreApprovalData.DispatchDetails.replace(/'/g, "\\'").trim() : '';
          let payload = {
            'ID': this.requestID,
            'Status': this.StoreApprovalData.Status,
            'DispatchDestination': this.StoreApprovalData.DispatchDestination,
            'DispatchMode': this.StoreApprovalData.DispatchMode,
            'DispatchType': this.StoreApprovalData.DispatchType,
            'CreatedBy': this.CreatedBy,
            'NeedInfoStatus': this.StoreApprovalData.NeedInfoStatus,
            'SAPDataUpdated': this.StoreApprovalData.SAPDataUpdated,
            'GDNote': this.StoreApprovalData.GDNote,
            'StoresComments': this.StoreApprovalData.StoresComments,
            'DispatchDetails': this.StoreApprovalData.DispatchDetails,
            'CreatedBy1': this.CreatedBy1
          };
          this._dashboardService.SubmitAction_Store(payload)
            .subscribe(
            (results: any) => {
              this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
              this.showActionForm_Store = false;
              this.getCounters_Stores();
              if (this.status === '2. Pending with Stores') {
                this.onStoresPending();
              } else if (this.status === '10. Pending for Material In') {
                this.onMaterialInPending();
              }
            },
            error => {
              this.errorMessage = <any>error;
              this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
        } else {
          this.errStoreComments = true;
        }
      }
    }

    // For Pending With MAterial IN Status
    if (this.status === '10. Pending for Material In') {
      if (this.StoreApprovalData.Status === '11. Material Received-Request Closed') {
        if (this.StoreApprovalData.GRNNo !== null && this.StoreApprovalData.GRNNo !== '') {
          this.errGRNNo = false;
          if (this.StoreApprovalData.StoresComments !== null && this.StoreApprovalData.StoresComments !== '') {
            this.errStoreComments = false;
            if (this.StoreApprovalData.DispatchDetails !== null && this.StoreApprovalData.DispatchDetails !== '') {
              this.errDispatchDetails = false;
              this.StoreApprovalData.StoresComments = this.StoreApprovalData.StoresComments ?
                this.StoreApprovalData.StoresComments.replace(/'/g, "\\'").trim() : '';
              this.StoreApprovalData.DispatchDetails = this.StoreApprovalData.DispatchDetails ?
                this.StoreApprovalData.DispatchDetails.replace(/'/g, "\\'").trim() : '';
              let payload = {
                'ID': this.requestID,
                'Status': this.StoreApprovalData.Status,
                'DispatchDestination': this.StoreApprovalData.DispatchDestination,
                'DispatchMode': this.StoreApprovalData.DispatchMode,
                'DispatchType': this.StoreApprovalData.DispatchType,
                'CreatedBy': this.CreatedBy,
                'NeedInfoStatus': this.StoreApprovalData.NeedInfoStatus,
                'SAPDataUpdated': this.StoreApprovalData.SAPDataUpdated,
                'GRNNo': this.StoreApprovalData.GRNNo,
                'StoresComments': this.StoreApprovalData.StoresComments,
                'DispatchDetails': this.StoreApprovalData.DispatchDetails,
                'CreatedBy1': this.CreatedBy1
              }
              this._dashboardService.SubmitAction_Store(payload)
                .subscribe(
                (results: any) => {
                  this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                  this.showActionForm_Store = false;
                  this.getCounters_Stores();
                  if (this.status === '2. Pending with Stores') {
                    this.onStoresPending();
                  } else if (this.status === '10. Pending for Material In') {
                    this.onMaterialInPending();
                  }
                },
                error => {
                  this.errorMessage = <any>error;
                  this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                });
            } else {
              this.errDispatchDetails = true;
            }
          } else {
            this.errStoreComments = true;
          }
        } else {
          this.errGRNNo = true;
        }
      } else {
        this.errGRNNo = false;
        if (this.StoreApprovalData.StoresComments !== null && this.StoreApprovalData.StoresComments !== '') {
          this.errStoreComments = false;
          if (this.StoreApprovalData.DispatchDetails !== null && this.StoreApprovalData.DispatchDetails !== '') {
            this.errDispatchDetails = false;
            this.StoreApprovalData.StoresComments = this.StoreApprovalData.StoresComments ?
              this.StoreApprovalData.StoresComments.replace(/'/g, "\\'").trim() : '';
            this.StoreApprovalData.DispatchDetails = this.StoreApprovalData.DispatchDetails ?
              this.StoreApprovalData.DispatchDetails.replace(/'/g, "\\'").trim() : '';
            let payload = {
              'ID': this.requestID,
              'Status': this.StoreApprovalData.Status,
              'DispatchDestination': this.StoreApprovalData.DispatchDestination,
              'DispatchMode': this.StoreApprovalData.DispatchMode,
              'DispatchType': this.StoreApprovalData.DispatchType,
              'CreatedBy': this.CreatedBy,
              'NeedInfoStatus': this.StoreApprovalData.NeedInfoStatus,
              'SAPDataUpdated': this.StoreApprovalData.SAPDataUpdated,
              'GRNNo': this.StoreApprovalData.GRNNo,
              'StoresComments': this.StoreApprovalData.StoresComments,
              'DispatchDetails': this.StoreApprovalData.DispatchDetails,
              'CreatedBy1': this.CreatedBy1
            };
            this._dashboardService.SubmitAction_Store(payload)
              .subscribe(
              (results: any) => {
                this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                this.showActionForm_Store = false;
                this.getCounters_Stores();
                if (this.status === '2. Pending with Stores') {
                  this.onStoresPending();
                } else if (this.status === '10. Pending for Material In') {
                  this.onMaterialInPending();
                }
              },
              error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
              });
          } else {
            this.errDispatchDetails = true;
          }
        } else {
          this.errStoreComments = true;
        }
      }
    }

    // For Pending SAP Team Status
    if (this.status === '9. Pending with SAP Team') {
      if (this.StoreApprovalData.Status !== '9. Pending With SAP Team') {
        this.errSAPStatus = false;
        if (this.StoreApprovalData.SAPDataUpdated) {
          this.errSAPUpdate = false;
          this.StoreApprovalData.StoresComments = this.StoreApprovalData.StoresComments ?
            this.StoreApprovalData.StoresComments.replace(/'/g, "\\'").trim() : '';
          this.StoreApprovalData.GDNote = this.StoreApprovalData.GDNote ? this.StoreApprovalData.GDNote.replace(/'/g, "\\'").trim() : '';
          let payload = {
            'ID': this.requestID,
            'Status': this.StoreApprovalData.Status,
            'DispatchDestination': this.StoreApprovalData.DispatchDestination,
            'DispatchMode': this.StoreApprovalData.DispatchMode,
            'DispatchType': this.StoreApprovalData.DispatchType,
            'CreatedBy': this.CreatedBy,
            'SAPDataUpdated': this.StoreApprovalData.SAPDataUpdated,
            'GDNote': this.StoreApprovalData.GDNote,
            'StoresComments': this.StoreApprovalData.StoresComments,
            'NeedInfoStatus': this.StoreApprovalData.NeedInfoStatus,
            'CreatedBy1': this.CreatedBy1
          };
          this._dashboardService.SubmitAction_Store(payload)
            .subscribe(
            (results: any) => {
              this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
              this.showActionForm_Store = false;
              this.getCounters_Stores();
              this.onSAPPending();
            },
            error => {
              this.errorMessage = <any>error;
              this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
        } else {
          this.errSAPUpdate = true;
        }
      } else {
        this.errSAPStatus = true;
      }
    }
    // For Dispatched Partially
    if (this.status === '5. Dispatched Partially') {
      this.errGRNNo = false;
      if (this.StoreApprovalData.StoresComments !== null && this.StoreApprovalData.StoresComments !== '') {
        this.errStoreComments = false;
        if (this.StoreApprovalData.DispatchDetails !== null && this.StoreApprovalData.DispatchDetails !== '') {
          this.errDispatchDetails = false;
          this.StoreApprovalData.StoresComments = this.StoreApprovalData.StoresComments ?
            this.StoreApprovalData.StoresComments.replace(/'/g, "\\'").trim() : '';
          this.StoreApprovalData.DispatchDetails = this.StoreApprovalData.DispatchDetails ?
            this.StoreApprovalData.DispatchDetails.replace(/'/g, "\\'").trim() : '';
          let payload = {
            'ID': this.requestID,
            'Status': this.StoreApprovalData.Status,
            'DispatchDestination': this.StoreApprovalData.DispatchDestination,
            'DispatchMode': this.StoreApprovalData.DispatchMode,
            'DispatchType': this.StoreApprovalData.DispatchType,
            'CreatedBy': this.CreatedBy,
            'NeedInfoStatus': this.StoreApprovalData.NeedInfoStatus,
            'SAPDataUpdated': this.StoreApprovalData.SAPDataUpdated,
            'GRNNo': this.StoreApprovalData.GRNNo,
            'StoresComments': this.StoreApprovalData.StoresComments,
            'DispatchDetails': this.StoreApprovalData.DispatchDetails,
            'CreatedBy1': this.CreatedBy1
          };
          this._dashboardService.SubmitAction_Store(payload)
            .subscribe(
            (results: any) => {
              if (results.StatusCode = 1) {
                this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                this.showActionForm_Store = false;
                this.getStoreTotalCount(this.status);
                this.getDocmesticDispatchReq_Store(this.status);
              } else {
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: results.ErrorMsg });
              }
            },
            error => {
              this.errorMessage = <any>error;
              this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
        } else {
          this.errDispatchDetails = true;
        }
      } else {
        this.errStoreComments = true;
      }
    }
  }
  onCancelAddForm() {
    this.showDomesticAddForm = false;
  }
  onCancelApproveRejectForm_GL() {
    this.showApproveRejectForm_GL = false;
  }
  onCancelActionForm_Req() {
    this.showActionForm_Req = false;
  }
  onCancelActionForm_GM() {
    this.showActionForm_GM = false;
  }
  onCancelActionForm_Store() {
    this.showActionForm_Store = false;
  }
  onCloseViewRequest() {
    this.showViewForm = false;
  }
  onDispatchDate(event: any) {
    this.dispatchDate = event;
  }
  onReturnableDate(event: any) {
    this.returnableDate = event;
  }
}
