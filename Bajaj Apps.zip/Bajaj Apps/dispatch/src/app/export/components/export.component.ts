import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthInfo } from '../../dashboard/models/authInfo';
import { ConfirmationService } from 'primeng/primeng';
import { CommonService } from '../../shared/services/common.service';
import { MessageService } from '../../shared/services/message.service';
import { ExportService } from '../services/export.service';
import { Domestic } from '../../dashboard/models/domestic';
import { Export } from '../models/export';
import { User } from '../../dashboard/models/loginUser';
import { constants } from '../models/constants';
declare var saveAs: any;
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
  moduleId: module.id,
  selector: 'sd-export',
  templateUrl: 'export.component.html',
  styleUrls: ['export.component.css'],
  providers: [ConfirmationService]
})
export class ExportComponent implements OnInit {
  cars: any[] = [];
  rmsMenu: any[];
  brandData: any[];
  dispatchType: any[];
  transportationMode: any[];
  countryData: any[];
  ExportData: any[];
  counterData: any[];
  GMApprovalData: Export;
  StoreApprovalData: Export;
  L1ApprovalData: Export;
  viewData: Export;
  editData: Export;
  attachmentURL: any = {};

  /** Flags Variables */
  showExportAddForm: boolean = false;
  showApproveRejectForm_GL: boolean = false;
  showActionForm_Req: boolean = false;
  showActionForm_GM: boolean = false;
  showActionForm_L1: boolean = false;
  showActionForm_Store: boolean = false;
  showViewForm: boolean = false;
  showActionForm_Edit: boolean = false;
  errorFlagForAdd: boolean = false;
  disabledSubmit: boolean = false;
  disabledVendorCode: boolean = false;
  disabledVendorName: boolean = false;
  disabledPR: boolean = false;
  disabledPlant: boolean = false;
  errorFlagForApproveReject_GL: boolean = false;
  errorFlagForReview_Req: boolean = false;
  ApproveButton_GL: boolean = false;
  RejectButton_GL: boolean = false;
  errRequesterComments: boolean = false;
  errGMVPComments: boolean = false;
  errL1Comments: boolean = false;
  errDispatchDetails: boolean = false;
  errStoreComments: boolean = false;
  errGDNote: boolean = false;
  errGRNNo: boolean = false;
  errSAPUpdate: boolean = false;
  errSAPStatus: boolean = false;
  isReturnable: boolean = true;

  /**General Variables */
  loggedInUser: string;
  errorMessage: string;
  minDate: Date;
  filesData: any;
  fileName: string = '';
  contactno: any = '';
  userRole: any;
  status: any = constants.PendingwithGL;// '1. Pending with GL';
  headingColor: any = constants.PendingwithGL;//'#3cbc8d';
  loggedInUserRole: string;
  requestID: any;
  attachmnet: any;
  CreatedBy: any;
  returnableDate: Date;
  dispatchDate: Date;
  CreatedBy1: any;
  binaryFileToDownload: string;
  StoreAllCounter: any;
  showSearchForm: boolean = false;
  errorFlagForSearch: boolean = false;

  /** Model Variable */
  model: AuthInfo;
  loggedInUserData: User = new User();

  /** Form Varialbes */
  AddExportForm: FormGroup;
  ApproveReject_GL: FormGroup;
  SubmitAction_Req: FormGroup;
  SearchExportForm: FormGroup;

  constructor(private _commonService: CommonService, private _messageService: MessageService,
    private _router: Router, private formBuilder: FormBuilder, private _exportService: ExportService,
    private _confirmationService: ConfirmationService) {
    this.model = new AuthInfo('password', '', '');
    this.filesData = new Array<File>();
    this.attachmentURL = {
      'FileName': '',
      'ServerRelativeUrl': ''
    };
  }

  ngOnInit() {
    this.minDate = new Date();
    this.userRole = sessionStorage.getItem('USER_ROLE');
    this.loggedInUser = sessionStorage.getItem('UserTitle') ? sessionStorage.getItem('UserTitle') : '';
    this.setAddExportForm();
    this.setApproveReject_GL();
    this.setSubmitAction_Req();
    this.setSearchDispatchForm();
    this.dispatchType = [{ 'Title': '1. Chargeable' },
    { 'Title': '2. Not Charged' }, { 'Title': '4. Loan Basis' },
    { 'Title': '6. Stock Transfer Order' }];

    /** Entry Point */
    if (this.userRole === 'Requester') {
      this.getCounters_Requester();
      this.onGLPending();
    } else if (this.userRole === 'GL') {
      this.getCounters_GL();
      this.onGLPending_GL();
    } else if (this.userRole === 'Store') {
      this.getCounters_Stores();
      this.onGLPending();
    } else if (this.userRole === 'GM' || this.userRole === 'L1') {
      this.getCounter_GM();
      this.onGLPending_GM();
    }
    this.isReturnable = true;
  }

  /** on Counter Click */
  onGLPending() {
    this.hideForms();
    this.status = constants.PendingwithGL;//'1. Pending with GL';
    this.headingColor = constants.PendingwithGL_Color;//'#3cbc8d';
    if (this.userRole === 'Store') {
      this.getStoreTotalCount(this.status);
      this.getExportDispatchReq_Store(this.status);
    }
    if (this.userRole === 'Requester') {
      this.getExportDispatchReq_Requester(this.status);
    }
    if (this.userRole === 'GL') {
      this.getExportDispatchReq_GL(this.status);
    }
  }
  onGMPending() {
    this.hideForms();
    this.status = constants.PendingwithGMVP;//'3. Pending with GM/VP';
    this.headingColor = constants.PendingwithGMVP_Color;// '#fac552';
    if (this.userRole === 'Store') {
      this.getStoreTotalCount(this.status);
      this.getExportDispatchReq_Store(this.status);
    }
    if (this.userRole === 'Requester') {
      this.getExportDispatchReq_Requester(this.status);
    }
  }
  onStoresPending() {
    this.hideForms();
    this.errDispatchDetails = false;
    this.errStoreComments = false;
    this.errSAPStatus = false;
    this.errGDNote = false;
    this.errGRNNo = false;
    this.errSAPUpdate = false;
    this.status = constants.PendingwithStores;//'2. Pending with Stores';
    this.headingColor = constants.PendingwithStores_Color;//'#e9422e';
    if (this.userRole === 'Store') {
      this.getStoreTotalCount(this.status);
      this.getExportDispatchReq_Store(this.status);
    }
    if (this.userRole === 'Requester') {
      this.getExportDispatchReq_Requester(this.status);
    }
  }
  onSAPPending() {
    this.hideForms();
    this.errDispatchDetails = false;
    this.errStoreComments = false;
    this.errSAPStatus = false;
    this.errGDNote = false;
    this.errGRNNo = false;
    this.errSAPUpdate = false;
    this.status = constants.PendingwithSAPTeam;//'9. Pending with SAP Team';
    this.headingColor = constants.PendingwithSAPTeam_Color;//'#aec534';
    if (this.userRole === 'Store') {
      this.getStoreTotalCount(this.status);
      this.getExportDispatchReq_Store(this.status);
    }
    if (this.userRole === 'Requester') {
      this.getExportDispatchReq_Requester(this.status);
    }
  }
  onRequesterPending() {
    this.hideForms();
    this.status = constants.PendingwithRequester;// '8. Pending with Requester';
    this.headingColor = constants.PendingwithRequester_Color;//'#29b7d3';
    if (this.userRole === 'Store') {
      this.getStoreTotalCount(this.status);
      this.getExportDispatchReq_Store(this.status);
    }
    if (this.userRole === 'Requester') {
      this.getExportDispatchReq_Requester(this.status);
    }
  }
  onMaterialInPending() {
    this.hideForms();
    this.errDispatchDetails = false;
    this.errStoreComments = false;
    this.errSAPStatus = false;
    this.errGDNote = false;
    this.errGRNNo = false;
    this.errSAPUpdate = false;
    this.status = constants.PendingforMaterialIn;// '10. Pending for Material In';
    this.headingColor = constants.PendingforMaterialIn_Color;//'#669';
    if (this.userRole === 'Store') {
      this.getStoreTotalCount(this.status);
      this.getExportDispatchReq_Store(this.status);
    }
    if (this.userRole === 'Requester') {
      this.getExportDispatchReq_Requester(this.status);
    }
  }
  onGLReject() {
    this.hideForms();
    this.status = constants.RejectedbyGL;//'5. Rejected by GL';
    this.headingColor = constants.RejectedbyGL_Color;//'orangered';
    if (this.userRole === 'Store') {
      this.getStoreTotalCount(this.status);
      this.getExportDispatchReq_Store(this.status);
    }
    if (this.userRole === 'Requester') {
      this.getExportDispatchReq_Requester(this.status);
    }
  }
  onGMReject() {
    this.hideForms();
    this.status = constants.RejectedbyGMVP;//'6. Rejected by GM/VP';
    this.headingColor = constants.RejectedbyGMVP_Color;//'blue';
    if (this.userRole === 'Store') {
      this.getStoreTotalCount(this.status);
      this.getExportDispatchReq_Store(this.status);
    }
    if (this.userRole === 'Requester') {
      this.getExportDispatchReq_Requester(this.status);
    }
  }
  onDispatched() {
    this.hideForms();
    this.status = constants.Dispatched;// '4. Dispatched';
    this.headingColor = constants.Dispatched_Color;//'#3cbc8d';
    if (this.userRole === 'Store') {
      this.getStoreTotalCount(this.status);
      this.getExportDispatchReq_Store(this.status);
    }
    if (this.userRole === 'Requester') {
      this.getExportDispatchReq_Requester(this.status);
    }
  }
  onPartiallyDispatched() {
    this.hideForms();
    this.status = constants.DispatchedPartially;//'7. Dispatched Partially';
    this.headingColor = constants.DispatchedPartially_Color;//'#669';
    if (this.userRole === 'Store') {
      this.getStoreTotalCount(this.status);
      this.getExportDispatchReq_Store(this.status);
    }
    if (this.userRole === 'Requester') {
      this.getExportDispatchReq_Requester(this.status);
    }
  }
  onMaterialReceived() {
    this.hideForms();
    this.status = constants.MaterialReceivedRequestClosed;//'11. Material Received-Request Closed';
    this.headingColor = constants.MaterialReceivedRequestClosed_Color;//'#fac552';
    if (this.userRole === 'Store') {
      this.getStoreTotalCount(this.status);
      this.getExportDispatchReq_Store(this.status);
    }
    if (this.userRole === 'Requester') {
      this.getExportDispatchReq_Requester(this.status);
    }
  }

  //GL Couters
  onGLApproved_GL() {
    this.hideForms();
    this.status = constants.ApprovedGL;// 'Approved';
    this.headingColor = constants.ApprovedGL_Color;//'#3cbc8d';
    this.getExportDispatchReq_GL(this.status);
  }
  onGLReject_GL() {
    this.hideForms();
    this.status = constants.RejectedGL;//'Rejected';
    this.headingColor = constants.RejectedGL_Color;//'#fac552';
    this.getExportDispatchReq_GL(this.status);

  }
  onGLPending_GL() {
    this.hideForms();
    this.status = constants.PendingGL;//'Pending';
    this.headingColor = constants.PendingGL_Color;//'#e9422e';
    this.getExportDispatchReq_GL(this.status);
  }

  //GM Couters
  onGLApproved_GM() {
    this.hideForms();
    this.status = constants.ApprovedGM;// 'Approved';
    this.headingColor = constants.ApprovedGM_Color;//'#3cbc8d';
    this.getExportDispatchReq_GM(this.status);
  }
  onGLReject_GM() {
    this.hideForms();
    this.status = constants.ApprovedGM;//'Rejected';
    this.headingColor = constants.ApprovedGM_Color;//'#fac552';
    this.getExportDispatchReq_GM(this.status);

  }
  onGLPending_GM() {
    this.hideForms();
    this.status = constants.PendingGM;//'Pending';
    this.headingColor = constants.PendingGM_Color;//'#e9422e';
    this.getExportDispatchReq_GM(this.status);
  }

  getCounter_GM() {
    this._exportService.getCounter_GM()
      .subscribe(
      (results: any) => {
        this.counterData = results;
      },
      (error: any) => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getCounters_Stores() {
    this._exportService.getCounters_Stores()
      .subscribe(
      (results: any) => {
        this.counterData = results;
      },
      (error: any) => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getCounters_Requester() {
    this._exportService.getCounters_Requester()
      .subscribe(
      (results: any) => {
        this.counterData = results;
      },
      (error: any) => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getCounters_GL() {
    this._exportService.getCounters_GL()
      .subscribe(
      (results: any) => {
        this.counterData = results;
      },
      (error: any) => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }

  getExportDispatchReq_GM(status: any) {
    this.ExportData = [];
    this._exportService.getExportDispatchReq_GM(status)
      .subscribe((results: any) => {
        if (results.length > 0) {
          this.ExportData = results;
        }
      });
  }
  getExportDispatchReq_Store(status: any) {
    this.ExportData = [];
    this._exportService.getExportDispatchReq_Store(status)
      .subscribe((results: any) => {
        if (results.length > 0) {
          this.ExportData = results;
        }
      });
  }
  viewAllStoreRequest() {
    this.ExportData = [];
    this._exportService.viewAllStoreRequest(this.status)
      .subscribe(
      (results: any) => {
        if (results.length > 0) {
          this.ExportData = results;
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getStoreTotalCount(status: any) {
    this._exportService.getStoreTotalCount(status)
      .subscribe(
      (results: any) => {
        this.StoreAllCounter = results;
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getExportDispatchReq_Requester(status: any) {
    this.ExportData = [];
    this._exportService.getExportDispatchReq_Requester(status)
      .subscribe((results: any) => {
        if (results.length > 0) {
          this.ExportData = results;
        }
      });
  }
  getExportDispatchReq_GL(status: any) {
    this.ExportData = [];
    this._exportService.getExportDispatchReq_GL(status)
      .subscribe((results: any) => {
        if (results.length > 0) {
          this.ExportData = results;
        }
      });
  }

  /** General Functons */
  onAddRequest() {
    this.showExportAddForm = true;
    this.showActionForm_GM = false;
    this.showActionForm_L1 = false;
    this.showActionForm_Req = false;
    this.showActionForm_Store = false;
    this.showActionForm_Edit = false;
    this.showApproveRejectForm_GL = false;
    this.errorFlagForAdd = false;
    this.disabledSubmit = false;
    this.fileName = '';
    this.contactno = '';
    this.setAddExportForm();
    this.getBrandMaster();
    this.getTransportationMode();
    this.getCountryMaster();
    this.onCancelSearchForm();
  }

  onSearch() {
    this.showExportAddForm = false;
    this.showViewForm = false;
    // this.showRMGPSelectForm = false;
    // this.showRMGPViewForm = false;
    this.errorFlagForSearch = false;
    this.showSearchForm = true;
    //this.setSearchRMGPForm();
  }

  setSearchDispatchForm() {
    this.SearchExportForm = this.formBuilder.group({
      ExportDispatchNo: ['', [Validators.required]]
    });
  }
  onCancelSearchForm() {
    this.showSearchForm = false;
    this.setSearchDispatchForm();
  }

  onSubmitSearchDispatchRequest({ value, valid }: { value: any, valid: boolean }) {
    if (valid) {
      this._exportService.searchByExportDispatchRequestID(value.ExportDispatchNo)
        .subscribe(
        (results: any) => {
          if (results.length > 0) {
            this.ExportData = results;
            this.status = results[0].Status;
            switch (this.status) {
              case constants.PendingwithGL: this.headingColor = constants.PendingwithGL_Color;
                break;
              case constants.PendingwithGMVP: this.headingColor = constants.PendingwithGMVP_Color;
                break;
              case constants.PendingwithStores: this.headingColor = constants.PendingwithStores_Color;
                break;
              case constants.PendingwithSAPTeam: this.headingColor = constants.PendingwithSAPTeam_Color;
                break;
              case constants.PendingwithRequester: this.headingColor = constants.PendingwithRequester_Color;
                break;
              case constants.PendingforMaterialIn: this.headingColor = constants.PendingforMaterialIn_Color;
                break;
              case constants.RejectedbyGL: this.headingColor = constants.RejectedbyGL_Color;
                break;
              case constants.RejectedbyGMVP: this.headingColor = constants.RejectedbyGMVP_Color;
                break;
              case constants.ReviewRequest: this.headingColor = constants.ReviewRequest_Color;
                break;
              case constants.CancelRequest: this.headingColor = constants.CancelRequest_Color;
                break;
              case constants.Dispatched: this.headingColor = constants.Dispatched_Color;
                break;
              case constants.DispatchedPartially: this.headingColor = constants.DispatchedPartially_Color;
                break;
              case constants.MaterialReceivedRequestClosed: this.headingColor = constants.MaterialReceivedRequestClosed_Color;
                break;
              case constants.ApprovedGL: this.headingColor = constants.ApprovedGL_Color;
                break;
              case constants.RejectedGL: this.headingColor = constants.RejectedGL_Color;
                break;
              case constants.PendingGL: this.headingColor = constants.PendingGL_Color;
                break;
              case constants.ApprovedGM: this.headingColor = constants.ApprovedGM_Color;
                break;
              case constants.RejectedGM: this.headingColor = constants.RejectedGM_Color;
                break;
              case constants.PendingGM: this.headingColor = constants.PendingGM_Color;
                break;

            }
          } else {
            this.ExportData = [];
          }
        },
        error => {
          this.errorMessage = <any>error;
          this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
        });
    } else {
      this.errorFlagForSearch = true;
    }
  }

  onDispatchDestination(val: any) {
    if (val === '1. Plant') {
      this.AddExportForm.controls['VendorCode'].disable();
      this.AddExportForm.controls['VendorName'].disable();
      this.AddExportForm.controls['PR'].enable();
      this.AddExportForm.controls['Plant'].enable();
      this.AddExportForm.controls['DispatchMode'].setValue('2. Non-Returnable');
      this.AddExportForm.controls['DispatchType'].setValue('6. Stock Transfer Order');
      this.AddExportForm.controls['DispatchMode'].disable();
      this.AddExportForm.controls['DispatchType'].disable();
    }
    if (val === '2. Vendor') {
      this.AddExportForm.controls['VendorCode'].enable();
      this.AddExportForm.controls['VendorName'].enable();
      this.AddExportForm.controls['DispatchMode'].setValue('');
      this.AddExportForm.controls['DispatchType'].setValue('');
      this.AddExportForm.controls['PR'].disable();
      this.AddExportForm.controls['Plant'].disable();
      this.AddExportForm.controls['DispatchMode'].enable();
      this.AddExportForm.controls['DispatchType'].enable();
    }
  }
  onDispatchMode(val: any) {
    if (val === '1. Returnable') {
      this.dispatchType = [];
      this.dispatchType = [{ 'Title': '4. Loan Basis' }, { 'Title': '5. Job Work' }];
      this.isReturnable = true;
    }
    if (val === '2. Non-Returnable' || val === '3. Processing') {
      this.dispatchType = [];
      this.dispatchType = [{ 'Title': '1. Chargeable' }, { 'Title': '2. Not Charged' }];
      this.isReturnable = false;
    }
  }
  onStatus(val: any) {
    if (val === '14. Continue Request') {
      this.SubmitAction_Req.controls['RequesterComments'].enable();
    } else {
      this.SubmitAction_Req.controls['RequesterComments'].disable();
    }
  }
  downloadFile(RMGP: Domestic) {
    this.attachmentURL.FileName = RMGP.AttachmentFiles[0].FileName;
    this.attachmentURL.ServerRelativeUrl = RMGP.AttachmentFiles[0].ServerRelativeUrl;
    this.onDownloadFile();
  }
  onDownloadFile() {
    this._exportService.getDownloadedFile(this.attachmentURL.ServerRelativeUrl)
      .subscribe(
      results => {
        this.binaryFileToDownload = <any>results;
        if (this.binaryFileToDownload) {
          this.Download(this.binaryFileToDownload, this.attachmentURL.ServerRelativeUrl, this.attachmentURL.FileName);
        } else { this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: 'File Not Found' }); }
      },
      error => this.errorMessage = <any>error);
  }
  Download(binaryResume: string, attachmentURL: string, FileName: string) {
    let extension;
    let fileName;
    if (FileName !== null) {
      extension = FileName.split('.')[1] ? FileName.split('.')[1] : 'RMGPExt';
      fileName = FileName.split('.')[0] ? FileName.split('.')[0] : 'RMGPFile';
    }
    //var link = document.createElement('a');
    //link.download = fileName;
    var byteCharacters = atob(binaryResume);
    var byteNumbers = new Array(byteCharacters.length);
    for (var i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    var byteArray = new Uint8Array(byteNumbers);

    switch (extension.toLowerCase()) {
      case 'pdf': var blob1 = new Blob([byteArray], { type: "application/pdf;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:application/pdf;charset=utf-8;base64,' + binaryResume;
        break;
      case 'xls': var blob1 = new Blob([byteArray], { type: "application/vnd.ms-excel;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:application/vnd.ms-excel;charset=utf-8;base64,' + binaryResume;
        break;
      case 'xlsx': var blob1 = new Blob([byteArray], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8;base64,' + binaryResume;
        break;
      case 'tif': var blob1 = new Blob([byteArray], { type: "image/tiff;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:image/tiff;charset=utf-8;base64,' + binaryResume;
        break;
      case 'tiff': var blob1 = new Blob([byteArray], { type: "image/tiff;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:image/tiff;charset=utf-8;base64,' + binaryResume;
        break;
      case 'gif': var blob1 = new Blob([byteArray], { type: "image/GIF;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:image/GIF;charset=utf-8;base64,' + binaryResume;
        break;
      case 'jpeg': var blob1 = new Blob([byteArray], { type: "image/jpeg;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:image/jpeg;charset=utf-8;base64,' + binaryResume;
        break;
      case 'jpg': var blob1 = new Blob([byteArray], { type: "image/jpeg;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:image/jpeg;charset=utf-8;base64,' + binaryResume;
        break;
      case 'png': var blob1 = new Blob([byteArray], { type: "image/png,charset=utf-8" });
        new saveAs(blob1, fileName + '.' + extension);
        //link.href = 'data:image/png;charset=utf-8;base64,' + binaryResume;
        break;
      case 'ppt': var blob1 = new Blob([byteArray], { type: "application/vnd.ms-powerpoint;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:application/vnd.ms-powerpoint;charset=utf-8;base64,' + binaryResume;
        break;
      case 'pptx': var blob1 = new Blob([byteArray], { type: "application/vnd.openxmlformats-officedocument.presentationml.presentation;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:application/vnd.openxmlformats-officedocument.presentationml.presentation;charset=utf-8;base64,' + binaryResume;
        break;
      case 'doc':
        var blob1 = new Blob([byteArray], { type: "application/msword;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:application/msword;charset=utf-8;base64,' + binaryResume;
        break;
      case 'docx':
        var blob1 = new Blob([byteArray], { type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document;charset=utf-8;base64" });
        window.navigator.msSaveBlob(blob1, fileName + '.' + extension);
        // link.href = 'data:application/vnd.openxmlformats-officedocument.wordprocessingml.document;charset=utf-8;base64,' + binaryResume;
        break;
      case 'zip': var blob1 = new Blob([byteArray], { type: "application/zip;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:application/zip;charset=utf-8;base64,' + binaryResume;
        break;
      default: //link.href = 'data:application/force-download;charset=utf-8;base64,' + binaryResume;
        break;
    }
    //document.body.appendChild(link);
    //link.click();
  }
  postFile(inputValue: any, type: string): void {
    var format = /[!@#$%^&*+\=\[\]{};':'\\|,.<>\/?]+/;
    try {
      let FileList: FileList = inputValue.target.files;
      if (FileList.length > 0) {
        if (inputValue.target.files[0].size < 10000000) {
          if (inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'docx' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'doc' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'xls' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'xlsx' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'tif' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'tiff' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'gif' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'jpeg' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'jpg' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'png' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'pdf' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'ppt' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'pptx' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'zip') {
            if (!format.test(inputValue.target.files[0].name.split('.')[0])) {
              this.filesData.length = 0;
              for (let i = 0, length = FileList.length; i < length; i++) {
                this.filesData.push(FileList.item(i));
                this.fileName = FileList.item(i).name;
              }
            } else {
              this._messageService.addMessage({
                severity: 'error', summary: 'Error Message',
                detail: 'Please remove special characters from filename'
              });
            }
          } else {
            this._messageService.addMessage({
              severity: 'error', summary: 'Error Message',
              detail: 'Please upload document of type of supperted type'
            });
          }
        } else {
          this._messageService.addMessage({
            severity: 'error', summary: 'Error Message',
            detail: 'Please upload document of size less than 2 MB'
          });
        }
      } else {
        //this.AttachmentURL = false;
        this.fileName = '';
      }
    } catch (error) {
      document.write(error);
    }

  }
  validateContactNum(num: any) {
    let maxlength = 10;
    if (maxlength >= num.toString().length) {
      //
    } else {
      this.contactno = num.toString().substr(0, num.toString().length - 1);
    }

  }
  hideForms() {
    this.showActionForm_GM = false;
    this.showActionForm_L1 = false;
    this.showActionForm_Req = false;
    this.showActionForm_Store = false;
    this.showActionForm_Edit = false;
    this.showApproveRejectForm_GL = false;
    this.showExportAddForm = false;
    this.showViewForm = false;
    this.onCancelSearchForm();
  }
  /** Masters */
  getBrandMaster() {
    this._commonService.getBrandDataDispatch()
      .subscribe(
      (results: any) => {
        this.brandData = results;
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getTransportationMode() {
    this._commonService.getTransportationMode()
      .subscribe(
      (results: any) => {
        this.transportationMode = results;
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getCountryMaster() {
    this._commonService.getCountryMaster()
      .subscribe(
      (results: any) => {
        this.countryData = results;
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }

  /** Set Form Functions */
  setAddExportForm() {
    this.AddExportForm = this.formBuilder.group({
      DispatchDescription: ['', [Validators.required]],
      DispatchMode: ['', [Validators.required]],
      DispatchType: ['', [Validators.required]],
      DispatchDate: [new Date(), [Validators.required]],
      OrderNo: ['', [Validators.required]],
      ServicePONo: [''],
      TransportationMode: ['', [Validators.required]],
      Brand: ['', [Validators.required]],
      ItemCode: ['', [Validators.required], [Validators.max(254)]],
      ItemDescription: ['', [Validators.required], [Validators.max(254)]],
      Quantity: ['', [Validators.required]],
      RequestInformation: ['', [Validators.required]],
      VendorCode: [''],
      ContactPerson: [''],
      ContactDetail: [''],
      PortOfDischarge: ['', [Validators.required]],
      FinalDestination: ['', [Validators.required]],
      Returnableate: [new Date()],
      PackingInstructions: [''],
      FreightChargesBy: [''],
      CountryOfOrigin: ['', [Validators.required]],
    });
  }
  setApproveReject_GL() {
    this.ApproveReject_GL = this.formBuilder.group({
      Title: [''],
      DispatchDescription: [''],
      DispatchMode: [''],
      DispatchType: [''],
      DispatchDate: [new Date()],
      TransportationMode: [''],
      Brand: [''],
      ItemCode: [''],
      ItemDescription: [''],
      Quantity: [''],
      VendorCode: [''],
      ServicePONo: [''],
      ContactPerson: [''],
      ContactDetail: [''],
      Returnableate: [new Date()],
      PackingInstructions: [''],
      RequesterComments: [''],
      PortOfDischarge: [''],
      FinalDestination: [''],
      FreightChargesBy: [''],
      CountryOfOrigin: [''],
      GLComments: ['', [Validators.required]]
    });
  }
  setSubmitAction_Req() {
    this.SubmitAction_Req = this.formBuilder.group({
      Title: [''],
      DispatchDescription: [''],
      DispatchMode: [''],
      DispatchType: [''],
      DispatchDate: [new Date()],
      TransportationMode: [''],
      Brand: [''],
      ItemCode: [''],
      ItemDescription: [''],
      Quantity: [''],
      VendorCode: [''],
      ServicePONo: [''],
      ContactPerson: [''],
      ContactDetail: [''],
      Returnableate: [new Date()],
      PackingInstructions: [''],
      PortOfDischarge: [''],
      FinalDestination: [''],
      FreightChargesBy: [''],
      CountryOfOrigin: [''],
      NeedInfoStatus: ['', [Validators.required]],
      GMComments: [''],
      GMApproval: [''],
      L1Approval: [''],
      L1Comments: [''],
      GLApproval: [''],
      GLComments: [''],
      Status: ['', [Validators.required]],
      RequesterComments: ['']
    });
  }
  ShowEditForDispatch(request: Export) {
    let modifiedDate: any;
    modifiedDate = request.Modified ? new Date(request.Modified).setDate(new Date(request.Modified).getDate() + 12) : new Date();
    if (new Date(modifiedDate) >= new Date()) {
      return true;
    } else {
      return false;
    }
  }
  onEditRequest(request: Export) {
    this.showActionForm_GM = false;
    this.showActionForm_Req = false;
    this.showActionForm_Store = false;
    this.showApproveRejectForm_GL = false;
    this.showExportAddForm = false;
    this.showViewForm = false;
    this._exportService.getRequestByID(request.ID)
      .subscribe(
      (results: Export) => {
        if (Object.keys(results).length !== 0) {
          this.editData = results;
          this.showActionForm_Edit = true;
        }
      });
  }
  onViewRequest(request: Export) {
    this.showActionForm_GM = false;
    this.showActionForm_Req = false;
    this.showActionForm_Store = false;
    this.showApproveRejectForm_GL = false;
    this.showExportAddForm = false;
    this.onCancelSearchForm();
    this._exportService.getRequestByID(request.ID)
      .subscribe(
      (results: Export) => {
        if (Object.keys(results).length !== 0) {
          this.viewData = results;
          this.showViewForm = true;
        }
      });
  }
  onECEPUpload(request: Export) {
    this._confirmationService.confirm({
      message: 'Have you uploaded EC/EP ?',
      accept: () => {
        let payload = {
          'ID': request.ID,
          'Status': request.Status,
          'DispatchMode': request.DispatchMode,
          'CreatedBy': request.CreatedBy,
          'CreatedBy1': request.CreatedBy1,
          'ECEPUploaded': true
        };
        this._exportService.SubmitAction_Store(payload)
          .subscribe(
          (results: any) => {
            this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
            this.getCounters_Stores();
            if (this.status === '10. Pending for Material In') {
              this.onMaterialInPending();
            }
            if (this.status === '4. Dispatched') {
              this.onDispatched();
            }
            if (this.status === '7. Dispatched Partially') {
              this.onPartiallyDispatched();
            }
          },
          (error: any) => {
            this.errorMessage = <any>error;
            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
          });
      }
    });
  }
  onSelectRequest(request: Export) {
    debugger;
    this.showViewForm = false;
    this.requestID = request.ID;
    this._exportService.getRequestByID(request.ID)
      .subscribe(
      (results: Export) => {
        if (Object.keys(results).length !== 0) {
          this.CreatedBy = results.CreatedBy;
          this.attachmnet = results.Attachments;
          this.CreatedBy1 = results.CreatedBy1 ? results.CreatedBy1 : '';
          if (this.userRole === 'GL') {
            this.showApproveRejectForm_GL = true;
            this.errorFlagForApproveReject_GL = false;
            this.ApproveReject_GL.setValue({
              Title: results.Title ? results.Title : '',
              DispatchDescription: results.DispatchDescription ? results.DispatchDescription : '',
              DispatchMode: results.DispatchMode ? results.DispatchMode : '',
              DispatchType: results.DispatchType ? results.DispatchType : '',
              DispatchDate: results.DispatchDate ? new Date(results.DispatchDate) : '',
              TransportationMode: results.TransportationMode ? results.TransportationMode : '',
              Brand: results.Brand ? results.Brand : '',
              ItemCode: results.ItemCode ? results.ItemCode : '',
              ItemDescription: results.ItemDescription ? results.ItemDescription : '',
              Quantity: results.Quantity ? results.Quantity : '',
              VendorCode: results.VendorCode ? results.VendorCode : '',
              ServicePONo: results.ServicePONo ? results.ServicePONo : '',
              ContactPerson: results.ContactPerson ? results.ContactPerson : '',
              ContactDetail: results.ContactDetail ? results.ContactDetail : '',
              Returnableate: results.Returnableate ? new Date(results.Returnableate) : '',
              RequesterComments: results.RequesterComments ? results.RequesterComments : '',
              PackingInstructions: results.PackingInstructions ? results.PackingInstructions : '',
              PortOfDischarge: results.PortOfDischarge ? results.PortOfDischarge : '',
              FinalDestination: results.FinalDestination ? results.FinalDestination : '',
              FreightChargesBy: results.FreightChargesBy ? results.FreightChargesBy : '',
              CountryOfOrigin: results.CountryOfOrigin ? results.CountryOfOrigin : '',
              GLComments: ''
            });
          }
          if (this.userRole === 'Requester' && this.status === '8. Pending with Requester') {
            this.showActionForm_Req = true;
            this.errorFlagForReview_Req = false;
            this.errRequesterComments = false;
            this.SubmitAction_Req.setValue({
              Title: results.Title ? results.Title : '',
              DispatchDescription: results.DispatchDescription ? results.DispatchDescription : '',
              DispatchMode: results.DispatchMode ? results.DispatchMode : '',
              DispatchType: results.DispatchType ? results.DispatchType : '',
              DispatchDate: results.DispatchDate ? new Date(results.DispatchDate) : '',
              TransportationMode: results.TransportationMode ? results.TransportationMode : '',
              Brand: results.Brand ? results.Brand : '',
              ItemCode: results.ItemCode ? results.ItemCode : '',
              ItemDescription: results.ItemDescription ? results.ItemDescription : '',
              Quantity: results.Quantity ? results.Quantity : '',
              VendorCode: results.VendorCode ? results.VendorCode : '',
              ServicePONo: results.ServicePONo ? results.ServicePONo : '',
              ContactPerson: results.ContactPerson ? results.ContactPerson : '',
              ContactDetail: results.ContactDetail ? results.ContactDetail : '',
              Returnableate: results.Returnableate ? new Date(results.Returnableate) : '',
              PackingInstructions: results.PackingInstructions ? results.PackingInstructions : '',
              NeedInfoStatus: '',
              PortOfDischarge: results.PortOfDischarge ? results.PortOfDischarge : '',
              FinalDestination: results.FinalDestination ? results.FinalDestination : '',
              FreightChargesBy: results.FreightChargesBy ? results.FreightChargesBy : '',
              CountryOfOrigin: results.CountryOfOrigin ? results.CountryOfOrigin : '',
              GMComments: results.GMComments ? results.GMComments : '',
              GMApproval: results.GMApproval ? results.GMApproval : '',
              GLComments: results.GLComments ? results.GLComments : '',
              GLApproval: results.GLApproval ? results.GLApproval : '',
              L1Comments: results.L1Comments ? results.L1Comments : '',
              L1Approval: results.L1Approval ? results.L1Approval : '',
              Status: results.Status ? results.Status : '',
              RequesterComments: ''
            });
          }
          if (this.userRole === 'GM' || this.userRole === 'L1') {
            if (results.Status === '12. Pending with L1') {
              this.errL1Comments = false;
              this.L1ApprovalData = results;
              this.showActionForm_L1 = true;
            }
            if (results.Status === '3. Pending with GM/VP') {
              this.errGMVPComments = false;
              this.GMApprovalData = results;
              this.showActionForm_GM = true;
            }
            if (results.Status === '1. Pending with GL') {
              this.errGMVPComments = false;
              this.GMApprovalData = results;
              this.showApproveRejectForm_GL = true;
              this.ApproveReject_GL.setValue({
                Title: results.Title ? results.Title : '',
                DispatchDescription: results.DispatchDescription ? results.DispatchDescription : '',
                DispatchMode: results.DispatchMode ? results.DispatchMode : '',
                DispatchType: results.DispatchType ? results.DispatchType : '',
                DispatchDate: results.DispatchDate ? new Date(results.DispatchDate) : '',
                TransportationMode: results.TransportationMode ? results.TransportationMode : '',
                Brand: results.Brand ? results.Brand : '',
                ItemCode: results.ItemCode ? results.ItemCode : '',
                ItemDescription: results.ItemDescription ? results.ItemDescription : '',
                Quantity: results.Quantity ? results.Quantity : '',
                VendorCode: results.VendorCode ? results.VendorCode : '',
                ServicePONo: results.ServicePONo ? results.ServicePONo : '',
                ContactPerson: results.ContactPerson ? results.ContactPerson : '',
                ContactDetail: results.ContactDetail ? results.ContactDetail : '',
                Returnableate: results.Returnableate ? new Date(results.Returnableate) : '',
                RequesterComments: results.RequesterComments ? results.RequesterComments : '',
                PackingInstructions: results.PackingInstructions ? results.PackingInstructions : '',
                PortOfDischarge: results.PortOfDischarge ? results.PortOfDischarge : '',
                FinalDestination: results.FinalDestination ? results.FinalDestination : '',
                FreightChargesBy: results.FreightChargesBy ? results.FreightChargesBy : '',
                CountryOfOrigin: results.CountryOfOrigin ? results.CountryOfOrigin : '',
                GLComments: ''
              });
            }
          }
          if (this.userRole === 'Store' && this.status === '2. Pending with Stores') {
            this.StoreApprovalData = results;
            this.showActionForm_Store = true;
            this.errSAPStatus = false;
            this.errSAPUpdate = false;
            this.errGDNote = false;
            this.errGRNNo = false;
            this.errStoreComments = false;
            this.errDispatchDetails = false;
          }
          if (this.userRole === 'Store' && this.status === '10. Pending for Material In') {
            this.StoreApprovalData = results;
            this.showActionForm_Store = true;
            this.errSAPStatus = false;
            this.errSAPUpdate = false;
            this.errGDNote = false;
            this.errGRNNo = false;
            this.errStoreComments = false;
            this.errDispatchDetails = false;
          }
          if (this.userRole === 'Store' && this.status === '9. Pending with SAP Team') {
            this.StoreApprovalData = results;
            this.showActionForm_Store = true;
            this.errSAPStatus = false;
            this.errSAPUpdate = false;
            this.errGDNote = false;
            this.errGRNNo = false;
            this.errStoreComments = false;
            this.errDispatchDetails = false;
          }
        }
      });
  }

  /**Submit Actions */
  onSubmitExport({ value, valid }: { value: Export, valid: boolean }) {
    if (valid) {
      value.ItemCode = value.ItemCode ? value.ItemCode.replace(/'/g, "\\'").trim() : '';
      value.ItemDescription = value.ItemDescription ? value.ItemDescription.replace(/'/g, "\\'").trim() : '';
      value.VendorCode = value.VendorCode ? value.VendorCode.replace(/'/g, "\\'").trim() : '';
      value.ContactPerson = value.ContactPerson ? value.ContactPerson.replace(/'/g, "\\'").trim() : '';
      value.ContactDetail = value.ContactDetail ? value.ContactDetail.replace(/'/g, "\\'").trim() : '';
      value.PackingInstructions = value.PackingInstructions ? value.PackingInstructions.replace(/'/g, "\\'").trim() : '';
      value.DispatchDescription = value.DispatchDescription ? value.DispatchDescription.replace(/'/g, "\\'").trim() : '';
      value.OrderNo = value.OrderNo ? value.OrderNo.replace(/'/g, "\\'").trim() : '';
      value.ServicePONo = value.ServicePONo ? value.ServicePONo.replace(/'/g, "\\'").trim() : '';
      value.RequestInformation = value.RequestInformation ? value.RequestInformation.replace(/'/g, "\\'").trim() : '';
      value.PortOfDischarge = value.PortOfDischarge ? value.PortOfDischarge.replace(/'/g, "\\'").trim() : '';
      value.FinalDestination = value.FinalDestination ? value.FinalDestination.replace(/'/g, "\\'").trim() : '';
      value.DispatchDate = this.dispatchDate ? this.dispatchDate : new Date();
      value.Returnableate = this.returnableDate ? this.returnableDate : new Date();
      value.CreatedBy1 = this.loggedInUser;
      this.disabledSubmit = true;
      if (this.fileName === '') {
        this._exportService.SubmitExportRequest(value)
          .subscribe(
          (results: any) => {
            this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
            this.disabledSubmit = false;
            this.showExportAddForm = false;
            this.getCounters_Requester();
            this.onGLPending();
          },
          (error: any) => {
            this.errorMessage = <any>error;
            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
          });
      }
      if (this.fileName !== '') {
        this._exportService.SubmitExportRequestWithAttachment(value, this.filesData).then(
          (results: any) => {
            this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results });
            this.disabledSubmit = false;
            this.showExportAddForm = false;
            this.getCounters_Requester();
            this.onGLPending();
          },
          (error: any) => {
            this.errorMessage = <any>error;
            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
          });
      }
    } else {
      this.errorFlagForAdd = true;
    }
  }
  SubmitApprove_Edit() {
    this.editData.DispatchDescription = this.editData.DispatchDescription ?
      this.editData.DispatchDescription.replace(/'/g, "\\'").trim() : '';
    this.editData.ItemDescription = this.editData.ItemDescription ? this.editData.ItemDescription.replace(/'/g, "\\'").trim() : '';
    this.editData.ItemCode = this.editData.ItemCode ? this.editData.ItemCode.replace(/'/g, "\\'").trim() : '';
    this.editData.VendorCode = this.editData.VendorCode ? this.editData.VendorCode.replace(/'/g, "\\'").trim() : '';
    this.editData.ContactPerson = this.editData.ContactPerson ? this.editData.ContactPerson.replace(/'/g, "\\'").trim() : '';
    this.editData.ContactDetail = this.editData.ContactDetail ? this.editData.ContactDetail.replace(/'/g, "\\'").trim() : '';
    this.editData.PackingInstructions = this.editData.PackingInstructions ?
      this.editData.PackingInstructions.replace(/'/g, "\\'").trim() : '';
    this.editData.PortOfDischarge = this.editData.PortOfDischarge ? this.editData.PortOfDischarge.replace(/'/g, "\\'").trim() : '';
    this.editData.FinalDestination = this.editData.FinalDestination ? this.editData.FinalDestination.replace(/'/g, "\\'").trim() : '';
    this.editData.RequesterComments = this.editData.RequesterComments ? this.editData.RequesterComments.replace(/'/g, "\\'").trim() : '';
    this.editData.GMComments = this.editData.GMComments ? this.editData.GMComments.replace(/'/g, "\\'").trim() : '';
    this.editData.GLComments = this.editData.GLComments ? this.editData.GLComments.replace(/'/g, "\\'").trim() : '';
    this.editData.L1Comments = this.editData.L1Comments ? this.editData.L1Comments.replace(/'/g, "\\'").trim() : '';
    this.editData.GDNNo = this.editData.GDNNo ? this.editData.GDNNo.replace(/'/g, "\\'").trim() : '';
    this.editData.StoresComments = this.editData.StoresComments ? this.editData.StoresComments.replace(/'/g, "\\'").trim() : '';
    this.editData.DispatchDetails = this.editData.DispatchDetails ? this.editData.DispatchDetails.replace(/'/g, "\\'").trim() : '';
    this.editData.IdentificationMarks = this.editData.IdentificationMarks ?
      this.editData.IdentificationMarks.replace(/'/g, "\\'").trim() : '';
    this.editData.PM1 = null;
    this.editData.PM2 = null;
    this.editData.PM3 = null;
    this.editData.PM4 = null;
    this._exportService.UpdateExportRequest(this.editData)
      .subscribe(
      (results: any) => {
        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
        this.disabledSubmit = false;
        this.showExportAddForm = false;
        this.getCounters_Stores();
        if (this.status === '10. Pending for Material In') {
          this.onMaterialInPending();
        }
        if (this.status === '4. Dispatched') {
          this.onDispatched();
        }
        if (this.status === '7. Dispatched Partially') {
          this.onPartiallyDispatched();
        }
      },
      (error: any) => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  onSubmitApproveReject_GL({ value, valid }: { value: Domestic, valid: boolean }) {
    if (valid) {
      value.GLComments = value.GLComments ? value.GLComments.replace(/'/g, "\\'").trim() : '';
      let payload = {};
      if (this.ApproveButton_GL) {
        this.ApproveButton_GL = false;
        this.RejectButton_GL = false;
        payload = {
          'ID': this.requestID,
          'GLApproval': '2. Approved',
          'DispatchMode': value.DispatchMode,
          'DispatchType': value.DispatchType,
          'GLComments': value.GLComments,
          'CreatedBy': this.CreatedBy,
          'CreatedBy1': this.CreatedBy1
        };
      }
      if (this.RejectButton_GL) {
        this.ApproveButton_GL = false;
        this.RejectButton_GL = false;
        payload = {
          'ID': this.requestID,
          'GLApproval': '3. Rejected',
          'DispatchMode': value.DispatchMode,
          'DispatchType': value.DispatchType,
          'GLComments': value.GLComments,
          'CreatedBy': this.CreatedBy,
          'CreatedBy1': this.CreatedBy1
        };
      }
      this._exportService.ApproveReject_GL(payload)
        .subscribe(
        (results: any) => {
          this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
          this.showApproveRejectForm_GL = false;
          this.getCounters_GL();
          this.onGLPending_GL();
        },
        (error: any) => {
          this.errorMessage = <any>error;
          this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
        });
    } else {
      this.errorFlagForApproveReject_GL = true;
    }
  }
  onSubmitAction_Requester({ value, valid }: { value: Domestic, valid: boolean }) {
    if (valid) {
      let payload = {};
      value.RequesterComments = value.RequesterComments ? value.RequesterComments.replace(/'/g, "\\'").trim() : '';
      if (this.status === '8. Pending with Requester') {
        if (value.RequesterComments !== '' && value.RequesterComments !== null) {
          this.errRequesterComments = false;
          payload = {
            'ID': this.requestID,
            'Status': value.Status,
            'DispatchDestination': value.DispatchDestination,
            'DispatchMode': value.DispatchMode,
            'DispatchType': value.DispatchType,
            'RequesterComments': value.RequesterComments,
            'CreatedBy': this.CreatedBy,
            'NeedInfoStatus': value.NeedInfoStatus,
            'CreatedBy1': this.CreatedBy1
          }
          this._exportService.SubmitAction_Req(payload)
            .subscribe(
            (results: any) => {
              this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
              this.showActionForm_Req = false;
              this.getCounters_Requester();
              if (this.status === '8. Pending with Requester') {
                this.onRequesterPending();
              }
              if (this.status === '2. Pending with Stores') {
                this.onStoresPending();
              }
            },
            (error: any) => {
              this.errorMessage = <any>error;
              this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
        } else {
          this.errRequesterComments = true;
        }
      }

    } else {
      this.errorFlagForReview_Req = true;
    }
  }
  SubmitApprove_GM() {
    if (this.GMApprovalData.GMComments !== null) {
      if (this.GMApprovalData.GMComments !== '') {
        this.GMApprovalData.GMComments = this.GMApprovalData.GMComments ? this.GMApprovalData.GMComments.replace(/'/g, "\\'").trim() : '';
        this.errGMVPComments = false;
        let payload = {
          'ID': this.requestID,
          'GMApproval': '2. Approved',
          'DispatchMode': this.GMApprovalData.DispatchMode,
          'DispatchType': this.GMApprovalData.DispatchType,
          'GMComments': this.GMApprovalData.GMComments,
          'CreatedBy': this.CreatedBy,
          'CreatedBy1': this.CreatedBy1
        };
        this._exportService.SubmitAction_GM(payload)
          .subscribe(
          (results: any) => {
            this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
            this.showActionForm_GM = false;
            this.getCounter_GM();
            this.onGLPending_GM();
          },
          (error: any) => {
            this.errorMessage = <any>error;
            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
          });
      } else {
        this.errGMVPComments = true;
      }
    } else {
      this.errGMVPComments = true;
    }
  }
  SubmitReject_GM() {
    if (this.GMApprovalData.GMComments !== null) {
      if (this.GMApprovalData.GMComments !== '') {
        this.GMApprovalData.GMComments = this.GMApprovalData.GMComments ? this.GMApprovalData.GMComments.replace(/'/g, "\\'").trim() : '';
        this.errGMVPComments = false;
        let payload = {
          'ID': this.requestID,
          'GMApproval': '3. Rejected',
          'DispatchMode': this.GMApprovalData.DispatchMode,
          'DispatchType': this.GMApprovalData.DispatchType,
          'GMComments': this.GMApprovalData.GMComments,
          'CreatedBy': this.CreatedBy,
          'CreatedBy1': this.CreatedBy1
        };
        this._exportService.SubmitAction_GM(payload)
          .subscribe(
          (results: any) => {
            this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
            this.showActionForm_GM = false;
            this.getCounter_GM();
            this.onGLPending_GM();
          },
          (error: any) => {
            this.errorMessage = <any>error;
            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
          });
      } else {
        this.errGMVPComments = true;
      }
    } else {
      this.errGMVPComments = true;
    }
  }

  // L1 Action
  SubmitApprove_L1() {
    if (this.L1ApprovalData.L1Comments !== null) {
      if (this.L1ApprovalData.L1Comments !== '') {
        this.L1ApprovalData.L1Comments = this.L1ApprovalData.L1Comments ? this.L1ApprovalData.L1Comments.replace(/'/g, "\\'").trim() : '';
        this.errL1Comments = false;
        let payload = {
          'ID': this.requestID,
          'L1Approval': '2. Approved',
          'DispatchMode': this.L1ApprovalData.DispatchMode,
          'DispatchType': this.L1ApprovalData.DispatchType,
          'L1Comments': this.L1ApprovalData.L1Comments,
          'CreatedBy': this.CreatedBy,
          'CreatedBy1': this.CreatedBy1
        };
        this._exportService.SubmitAction_L1(payload)
          .subscribe(
          (results: any) => {
            this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
            this.showActionForm_GM = false;
            this.getCounter_GM();
            this.onGLPending_GM();
          },
          (error: any) => {
            this.errorMessage = <any>error;
            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
          });
      } else {
        this.errL1Comments = true;
      }
    } else {
      this.errL1Comments = true;
    }
  }
  SubmitReject_L1() {
    if (this.L1ApprovalData.L1Comments !== null) {
      if (this.L1ApprovalData.L1Comments !== '') {
        this.L1ApprovalData.L1Comments = this.L1ApprovalData.L1Comments ? this.L1ApprovalData.L1Comments.replace(/'/g, "\\'").trim() : '';
        this.errL1Comments = false;
        let payload = {
          'ID': this.requestID,
          'L1Approval': '3. Rejected',
          'DispatchMode': this.L1ApprovalData.DispatchMode,
          'DispatchType': this.L1ApprovalData.DispatchType,
          'L1Comments': this.L1ApprovalData.L1Comments,
          'CreatedBy': this.CreatedBy,
          'CreatedBy1': this.CreatedBy1
        };
        this._exportService.SubmitAction_L1(payload)
          .subscribe(
          (results: any) => {
            this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
            this.showActionForm_GM = false;
            this.getCounter_GM();
            this.onGLPending_GM();
          },
          (error: any) => {
            this.errorMessage = <any>error;
            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
          });
      } else {
        this.errL1Comments = true;
      }
    } else {
      this.errL1Comments = true;
    }
  }

  SubmitApprove_Store() {
    // For Pending With Stores Status
    if (this.status === '2. Pending with Stores') {
      if (this.StoreApprovalData.Status === '4. Dispatched' || this.StoreApprovalData.Status === '7. Dispatched Partially') {
        if (this.StoreApprovalData.GDNNo !== null && this.StoreApprovalData.GDNNo !== '') {
          this.errGDNote = false;
          if (this.StoreApprovalData.StoresComments !== null && this.StoreApprovalData.StoresComments !== '') {
            this.errStoreComments = false;
            if (this.StoreApprovalData.DispatchDetails !== null && this.StoreApprovalData.DispatchDetails !== '') {
              this.errDispatchDetails = false;
              this.StoreApprovalData.StoresComments = this.StoreApprovalData.StoresComments ?
                this.StoreApprovalData.StoresComments.replace(/'/g, "\\'").trim() : '';
              this.StoreApprovalData.DispatchDetails = this.StoreApprovalData.DispatchDetails ?
                this.StoreApprovalData.DispatchDetails.replace(/'/g, "\\'").trim() : '';
              this.StoreApprovalData.IdentificationMarks = this.StoreApprovalData.IdentificationMarks ?
                this.StoreApprovalData.IdentificationMarks.replace(/'/g, "\\'").trim() : '';
              let payload = {
                'ID': this.requestID,
                'Status': this.StoreApprovalData.Status,
                'DispatchMode': this.StoreApprovalData.DispatchMode,
                'DispatchType': this.StoreApprovalData.DispatchType,
                'CreatedBy': this.CreatedBy,
                'NeedInfoStatus': this.StoreApprovalData.NeedInfoStatus,
                'SAPDataUpdated': this.StoreApprovalData.SAPDataUpdated,
                'GDNNo': this.StoreApprovalData.GDNNo,
                'StoresComments': this.StoreApprovalData.StoresComments,
                'DispatchDetails': this.StoreApprovalData.DispatchDetails,
                'CreatedBy1': this.CreatedBy1,
                'IdentificationMarks': this.StoreApprovalData.IdentificationMarks,
                'CustomPurposeInvoice': this.StoreApprovalData.CustomPurposeInvoice,
                'PackingSlip': this.StoreApprovalData.PackingSlip,
                'NForm': this.StoreApprovalData.NForm
              };
              this._exportService.SubmitAction_Store(payload)
                .subscribe(
                (results: any) => {
                  this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                  this.showActionForm_Store = false;
                  this.getCounters_Stores();
                  if (this.status === '2. Pending with Stores') {
                    this.onStoresPending();
                  } else if (this.status === '10. Pending for Material In') {
                    this.onMaterialInPending();
                  }
                },
                (error: any) => {
                  this.errorMessage = <any>error;
                  this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                });
            } else {
              this.errDispatchDetails = true;
            }
          } else {
            this.errStoreComments = true;
          }
        } else {
          this.errGDNote = true;
        }
      } else {
        this.errGDNote = false;
        if (this.StoreApprovalData.StoresComments !== null && this.StoreApprovalData.StoresComments !== '') {
          this.errStoreComments = false;
          this.errDispatchDetails = false;
          this.StoreApprovalData.StoresComments = this.StoreApprovalData.StoresComments ?
            this.StoreApprovalData.StoresComments.replace(/'/g, "\\'").trim() : '';
          this.StoreApprovalData.DispatchDetails = this.StoreApprovalData.DispatchDetails ?
            this.StoreApprovalData.DispatchDetails.replace(/'/g, "\\'").trim() : '';
          this.StoreApprovalData.IdentificationMarks = this.StoreApprovalData.IdentificationMarks ?
            this.StoreApprovalData.IdentificationMarks.replace(/'/g, "\\'").trim() : '';
          let payload = {
            'ID': this.requestID,
            'Status': this.StoreApprovalData.Status,
            'DispatchMode': this.StoreApprovalData.DispatchMode,
            'DispatchType': this.StoreApprovalData.DispatchType,
            'CreatedBy': this.CreatedBy,
            'NeedInfoStatus': this.StoreApprovalData.NeedInfoStatus,
            'SAPDataUpdated': this.StoreApprovalData.SAPDataUpdated,
            'GDNNo': this.StoreApprovalData.GDNNo,
            'StoresComments': this.StoreApprovalData.StoresComments,
            'DispatchDetails': this.StoreApprovalData.DispatchDetails,
            'CreatedBy1': this.CreatedBy1,
            'IdentificationMarks': this.StoreApprovalData.IdentificationMarks,
            'CustomPurposeInvoice': this.StoreApprovalData.CustomPurposeInvoice,
            'PackingSlip': this.StoreApprovalData.PackingSlip,
            'NForm': this.StoreApprovalData.NForm
          };
          this._exportService.SubmitAction_Store(payload)
            .subscribe(
            (results: any) => {
              this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
              this.showActionForm_Store = false;
              this.getCounters_Stores();
              if (this.status === '2. Pending with Stores') {
                this.onStoresPending();
              } else if (this.status === '10. Pending for Material In') {
                this.onMaterialInPending();
              }
            },
            (error: any) => {
              this.errorMessage = <any>error;
              this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
        } else {
          this.errStoreComments = true;
        }
      }
    }

    //For Pending With MAterial IN Status
    if (this.status === '10. Pending for Material In') {
      if (this.StoreApprovalData.Status === '11. Material Received-Request Closed') {
        if (this.StoreApprovalData.GRNNo !== null && this.StoreApprovalData.GRNNo !== '') {
          this.errGRNNo = false;
          if (this.StoreApprovalData.StoresComments !== null && this.StoreApprovalData.StoresComments !== '') {
            this.errStoreComments = false;
            if (this.StoreApprovalData.DispatchDetails !== null && this.StoreApprovalData.DispatchDetails !== '') {
              this.errDispatchDetails = false;
              this.StoreApprovalData.StoresComments = this.StoreApprovalData.StoresComments ?
                this.StoreApprovalData.StoresComments.replace(/'/g, "\\'").trim() : '';
              this.StoreApprovalData.DispatchDetails = this.StoreApprovalData.DispatchDetails ?
                this.StoreApprovalData.DispatchDetails.replace(/'/g, "\\'").trim() : '';
              this.StoreApprovalData.IdentificationMarks = this.StoreApprovalData.IdentificationMarks ?
                this.StoreApprovalData.IdentificationMarks.replace(/'/g, "\\'").trim() : '';
              let payload = {
                'ID': this.requestID,
                'Status': this.StoreApprovalData.Status,
                'DispatchMode': this.StoreApprovalData.DispatchMode,
                'DispatchType': this.StoreApprovalData.DispatchType,
                'CreatedBy': this.CreatedBy,
                'NeedInfoStatus': this.StoreApprovalData.NeedInfoStatus,
                'SAPDataUpdated': this.StoreApprovalData.SAPDataUpdated,
                'GRNNo': this.StoreApprovalData.GRNNo,
                'StoresComments': this.StoreApprovalData.StoresComments,
                'DispatchDetails': this.StoreApprovalData.DispatchDetails,
                'CreatedBy1': this.CreatedBy1,
                'IdentificationMarks': this.StoreApprovalData.IdentificationMarks,
                'CustomPurposeInvoice': this.StoreApprovalData.CustomPurposeInvoice,
                'PackingSlip': this.StoreApprovalData.PackingSlip,
                'NForm': this.StoreApprovalData.NForm
              };
              this._exportService.SubmitAction_Store(payload)
                .subscribe(
                (results: any) => {
                  this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                  this.showActionForm_Store = false;
                  this.getCounters_Stores();
                  if (this.status === '2. Pending with Stores') {
                    this.onStoresPending();
                  } else if (this.status === '10. Pending for Material In') {
                    this.onMaterialInPending();
                  }
                },
                (error: any) => {
                  this.errorMessage = <any>error;
                  this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                });
            } else {
              this.errDispatchDetails = true;
            }
          } else {
            this.errStoreComments = true;
          }
        } else {
          this.errGRNNo = true;
        }
      } else {
        this.errGRNNo = false;
        if (this.StoreApprovalData.StoresComments !== null && this.StoreApprovalData.StoresComments !== '') {
          this.errStoreComments = false;
          if (this.StoreApprovalData.DispatchDetails !== null && this.StoreApprovalData.DispatchDetails !== '') {
            this.errDispatchDetails = false;
            this.StoreApprovalData.StoresComments = this.StoreApprovalData.StoresComments ?
              this.StoreApprovalData.StoresComments.replace(/'/g, "\\'").trim() : '';
            this.StoreApprovalData.DispatchDetails = this.StoreApprovalData.DispatchDetails ?
              this.StoreApprovalData.DispatchDetails.replace(/'/g, "\\'").trim() : '';
            this.StoreApprovalData.IdentificationMarks = this.StoreApprovalData.IdentificationMarks ?
              this.StoreApprovalData.IdentificationMarks.replace(/'/g, "\\'").trim() : '';
            let payload = {
              'ID': this.requestID,
              'Status': this.StoreApprovalData.Status,
              'DispatchMode': this.StoreApprovalData.DispatchMode,
              'DispatchType': this.StoreApprovalData.DispatchType,
              'CreatedBy': this.CreatedBy,
              'NeedInfoStatus': this.StoreApprovalData.NeedInfoStatus,
              'SAPDataUpdated': this.StoreApprovalData.SAPDataUpdated,
              'GRNNo': this.StoreApprovalData.GRNNo,
              'StoresComments': this.StoreApprovalData.StoresComments,
              'DispatchDetails': this.StoreApprovalData.DispatchDetails,
              'CreatedBy1': this.CreatedBy1,
              'IdentificationMarks': this.StoreApprovalData.IdentificationMarks,
              'CustomPurposeInvoice': this.StoreApprovalData.CustomPurposeInvoice,
              'PackingSlip': this.StoreApprovalData.PackingSlip,
              'NForm': this.StoreApprovalData.NForm
            };
            this._exportService.SubmitAction_Store(payload)
              .subscribe(
              (results: any) => {
                this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                this.showActionForm_Store = false;
                this.getCounters_Stores();
                if (this.status === '2. Pending with Stores') {
                  this.onStoresPending();
                } else if (this.status === '10. Pending for Material In') {
                  this.onMaterialInPending();
                }
              },
              (error: any) => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
              });
          } else {
            this.errDispatchDetails = true;
          }
        } else {
          this.errStoreComments = true;
        }
      }
    }

    // For Pending SAP Team Status
    if (this.status === '9. Pending with SAP Team') {
      if (this.StoreApprovalData.Status !== '9. Pending With SAP Team') {
        this.errSAPStatus = false;
        if (this.StoreApprovalData.SAPDataUpdated) {
          this.errSAPUpdate = false;
          this.StoreApprovalData.StoresComments = this.StoreApprovalData.StoresComments ?
            this.StoreApprovalData.StoresComments.replace(/'/g, "\\'").trim() : '';
          this.StoreApprovalData.GDNNo = this.StoreApprovalData.GDNNo ? this.StoreApprovalData.GDNNo.replace(/'/g, "\\'").trim() : '';
          this.StoreApprovalData.IdentificationMarks = this.StoreApprovalData.IdentificationMarks ?
            this.StoreApprovalData.IdentificationMarks.replace(/'/g, "\\'").trim() : '';
          let payload = {
            'ID': this.requestID,
            'Status': this.StoreApprovalData.Status,
            'DispatchMode': this.StoreApprovalData.DispatchMode,
            'DispatchType': this.StoreApprovalData.DispatchType,
            'CreatedBy': this.CreatedBy,
            'SAPDataUpdated': this.StoreApprovalData.SAPDataUpdated,
            'GDNNo': this.StoreApprovalData.GDNNo,
            'StoresComments': this.StoreApprovalData.StoresComments,
            'NeedInfoStatus': this.StoreApprovalData.NeedInfoStatus,
            'CreatedBy1': this.CreatedBy1,
            'IdentificationMarks': this.StoreApprovalData.IdentificationMarks,
            'CustomPurposeInvoice': this.StoreApprovalData.CustomPurposeInvoice,
            'PackingSlip': this.StoreApprovalData.PackingSlip,
            'NForm': this.StoreApprovalData.NForm
          };
          this._exportService.SubmitAction_Store(payload)
            .subscribe(
            (results: any) => {
              this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
              this.showActionForm_Store = false;
              this.getCounters_Stores();
              this.onSAPPending();
            },
            error => {
              this.errorMessage = <any>error;
              this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
        } else {
          this.errSAPUpdate = true;
        }
      } else {
        this.errSAPStatus = true;
      }
    }

  }
  onCancelAddForm() {
    this.showExportAddForm = false;
  }
  onCancelApproveRejectForm_GL() {
    this.showApproveRejectForm_GL = false;
  }
  onCancelActionForm_Req() {
    this.showActionForm_Req = false;
  }
  onCancelActionForm_GM() {
    this.showActionForm_GM = false;
  }
  onCancelActionForm_Store() {
    this.showActionForm_Store = false;
  }
  onCancelActionForm_L1() {
    this.showActionForm_L1 = false;
  }
  onCloseViewForm() {
    this.showViewForm = false;
  }
  onCancelActionForm_Edit() {
    this.showActionForm_Edit = false;
  }
  onDispatchDate(event: any) {
    this.dispatchDate = event;
  }
  onReturnableDate(event: any) {
    this.returnableDate = event;
  }
}
