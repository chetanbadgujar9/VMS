import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ExportComponent } from './components/export.component';
import { ExportRoutingModule } from './export-routing.module';
import { BrowserModule } from '@angular/platform-browser';
import { SharedModule } from '../shared/shared.module';
import { ExportService } from '../export/services/export.service';
@NgModule({
  imports: [CommonModule, ExportRoutingModule, SharedModule],
  declarations: [ExportComponent],
  exports: [ExportComponent],
  providers: [ExportService]
})
export class ExportModule { }
