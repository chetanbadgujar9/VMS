/**Title : Exprot despatch resuest status constants 
 * Author: Shailesh S.
 * Date  : 13 Dec 2017
*/
export class constants {

    public static readonly PendingwithGL: string = '1. Pending with GL';
    public static readonly PendingwithGL_Color: string = '#3cbc8d';

    public static readonly PendingwithGMVP: string = '3. Pending with GM/VP';
    public static readonly PendingwithGMVP_Color: string = '#fac552';

    public static readonly PendingwithStores: string = '2. Pending with Stores';
    public static readonly PendingwithStores_Color: string = '#e9422e';

    public static readonly PendingwithSAPTeam: string = '9. Pending with SAP Team';
    public static readonly PendingwithSAPTeam_Color: string = '#aec534';

    public static readonly PendingwithRequester: string = '8. Pending with Requester';
    public static readonly PendingwithRequester_Color: string = '#29b7d3';

    public static readonly PendingforMaterialIn: string = '10. Pending for Material In';
    public static readonly PendingforMaterialIn_Color: string = '#669';

    public static readonly RejectedbyGL: string = '5. Rejected by GL';
    public static readonly RejectedbyGL_Color: string = 'orangered';

    public static readonly RejectedbyGMVP: string = '6. Rejected by GM/VP';
    public static readonly RejectedbyGMVP_Color: string = 'blue';

    public static readonly ReviewRequest: string = '12. Review Request';
    public static readonly ReviewRequest_Color: string = '#3cbc8d';

    public static readonly CancelRequest: string = '13. Cancel Request';
    public static readonly CancelRequest_Color: string = '#fac552';

    public static readonly Dispatched: string = '4. Dispatched';
    public static readonly Dispatched_Color: string = '#3cbc8d';

    public static readonly DispatchedPartially: string = '7. Dispatched Partially';
    public static readonly DispatchedPartially_Color: string = '#669';

    public static readonly MaterialReceivedRequestClosed: string = '11. Material Received-Request Closed';
    public static readonly MaterialReceivedRequestClosed_Color: string = '#fac552';

    public static readonly ApprovedGL: string = 'Approved';
    public static readonly ApprovedGL_Color: string = '#3cbc8d';

    public static readonly RejectedGL: string = 'Rejected';
    public static readonly RejectedGL_Color: string = '#fac552';

    public static readonly PendingGL: string = 'Pending';
    public static readonly PendingGL_Color: string = '#e9422e';

    public static readonly ApprovedGM: string = 'Approved';
    public static readonly ApprovedGM_Color: string = '#3cbc8d';

    public static readonly RejectedGM: string = 'Rejected';
    public static readonly RejectedGM_Color: string = '#fac552';

    public static readonly PendingGM: string = 'Pending';
    public static readonly PendingGM_Color: string = '#e9422e';
}