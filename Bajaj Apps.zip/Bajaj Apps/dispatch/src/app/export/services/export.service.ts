/* angular dependencies */
import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/finally';

/** Third party dependencies */
import { AuthHttp } from '../../shared/services/authHttp.service';
import { Config } from '../../shared/config/config';
import { SpinnerService } from '../../shared/spinner/spinner.service';
import { Export } from '../models/export';

@Injectable()
export class ExportService {
    progress: any;
    progressObserver: any;
    constructor(private http: Http,
        private authHttp: AuthHttp,
        private _spinnerService: SpinnerService) {
    }

    getMyTestData() {
        let url = Config.GetURL('/Register/getHeight');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    SubmitExportRequest(payload: Export) {
        let url = Config.GetURL('/api/Dispatch/ExportDispatchRequest/Post');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    UpdateExportRequest(payload: Export) {
        let url = Config.GetURL('/api/Dispatch/ExportDispatchRequest/UpdateExportDispatchRequestByID');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    public SubmitExportRequestWithAttachment(payload: any, filedata: any) {
        let url = Config.GetURL('/api/Dispatch/ExportDispatchRequest/AddExportDispatchRequestWithAttachment');
        this._spinnerService.show();
        return new Promise((resolve, reject) => {
            let formData: FormData = new FormData(),
                xhr: XMLHttpRequest = new XMLHttpRequest();
            let data = { 'File': payload };
            formData.append(JSON.stringify(payload).replace(/'/g, "\\'").replace(/"/g, '$'), 'Data');
            formData.append('FileName', filedata[0]);

            xhr.onreadystatechange = () => {
                if (xhr.readyState === 4) {
                    if (xhr.status === 200) {
                        resolve(JSON.parse(xhr.response));
                    } else {
                        reject(xhr.response);
                    }
                }
            };
            xhr.open('POST', url, true);
            //xhr.setRequestHeader('Content-Type', undefined);
            xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem('access_token'));
            xhr.send(formData);
            this._spinnerService.hide();
        });
    }

    getRMGPRequestByID(id: any) {
        let url = Config.GetURL('/api/RMGP/RMGP/GetRMGPByID/' + id);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getExportDispatchReq_GM(status: any) {
        let url = Config.GetURL('/api/Dispatch/ExportDispatchRequest/GetGMExportDispatchRequestsByStatus?status=' + status);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getExportDispatchReq_Store(status: any) {
        let url = Config.GetURL('/api/Dispatch/ExportDispatchRequest/GetStoresExportDispatchRequestsByStatus?status=' + status);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    viewAllStoreRequest(status: any) {
        let url = Config.GetURL('/api/Dispatch/ExportDispatchRequest/GetAllStoresExportDispatchRequestsByStatus?status=' + status);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getStoreTotalCount(status: any) {
        let url = Config.GetURL('/api/Dispatch/ExportDispatchRequest/GetAllStoresExportDispatchRequestCountByStatus?status=' + status);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractDataForTotalCount)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getExportDispatchReq_Requester(status: any) {
        let url = Config.GetURL('/api/Dispatch/ExportDispatchRequest/GetMyCreatedExportDispatchRequestsByStatus?status=' + status);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getExportDispatchReq_GL(status: any) {
        let url = Config.GetURL('/api/Dispatch/ExportDispatchRequest/GetGLExportDispatchRequestsByStatus?status=' + status);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getRequestByID(ID: any) {
        let url = Config.GetURL('/api/Dispatch/ExportDispatchRequest/Get/' + ID);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    searchByExportDispatchRequestID(value: any) {
        let url = Config.GetURL('/api/Dispatch/ExportDispatchRequest/GetExportDispatchRequestListByRequestID?requestID=' + value + '&module=' + '');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    //Action
    ApproveReject_GL(payload: any) {
        let url = Config.GetURL('/api/Dispatch/ExportDispatchRequest/GLActionOnExportRequest');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    SubmitAction_Req(payload: any) {
        let url = Config.GetURL('/api/Dispatch/ExportDispatchRequest/RequesterActionOnExportRequest');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    SubmitAction_GM(payload: any) {
        let url = Config.GetURL('/api/Dispatch/ExportDispatchRequest/GMActionOnExportRequest');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    SubmitAction_L1(payload: any) {
        let url = Config.GetURL('/api/Dispatch/ExportDispatchRequest/L1ActionOnExportRequest');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    SubmitAction_Store(payload: any) {
        let url = Config.GetURL('/api/Dispatch/ExportDispatchRequest/StoresActionOnExportRequest');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    // Counter
    getCounter_GM() {
        let url = Config.GetURL('/api/Dispatch/ExportDispatchRequest/GetGMCountersExport');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getCounters_Stores() {
        let url = Config.GetURL('/api/Dispatch/ExportDispatchRequest/GetStoresCountersExport');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getCounters_Requester() {
        let url = Config.GetURL('/api/Dispatch/ExportDispatchRequest/GetRequesterCountersExport');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getCounters_GL() {
        let url = Config.GetURL('/api/Dispatch/ExportDispatchRequest/GetGLCountersExport');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }

    getDownloadedFile(attachment: string) {
        //Update an API
        let url = Config.GetURL('/api/Dispatch/ExportDispatchRequest/GetAttachmentBinaryByAttachmentUrl?url=' + attachment);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    public requesterClosureWithAttachment(payload: any, filedata: any) {
        let url = Config.GetURL('/api/RMGP/RMGP/CloseRequestByRequester');
        this._spinnerService.show();
        return new Promise((resolve, reject) => {
            let formData: FormData = new FormData(),
                xhr: XMLHttpRequest = new XMLHttpRequest();
            let data = { 'File': payload }
            formData.append(JSON.stringify(payload), 'Data');
            formData.append('FileName', filedata[0]);

            xhr.onreadystatechange = () => {
                if (xhr.readyState === 4) {
                    if (xhr.status === 200) {
                        resolve(JSON.parse(xhr.response));
                    } else {
                        reject(xhr.response);
                    }
                }
            };
            xhr.open('POST', url, true);
            //xhr.setRequestHeader('Content-Type', undefined);
            xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem('access_token'));
            xhr.send(formData);
            this._spinnerService.hide();
        });
    }
    /**Success Handler */
    private extractData(res: Response) {
        if (res.status < 200 || res.status >= 300) {
            throw new Error('Bad response status: ' + res.status);
        }
        let body = res.json();
        return body || {};
    }
    private extractDataForValidate(res: Response) {
        if (res.status < 200 || res.status >= 300) {
            throw new Error('Bad response status: ' + res.status);
        }
        let body = res.json();
        return body || false;
    }
    private extractDataForTotalCount(res: Response) {
        if (res.status < 200 || res.status >= 300) {
            throw new Error('Bad response status: ' + res.status);
        }
        let body = res.json();
        return body || 0;
    }
    /**Error Handler */
    private handleError(error: Response) {
        console.log(error);
        return Observable.throw(error.json().error || 'Server error');
    }
}