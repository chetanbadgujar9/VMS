export class Config {
    public static getLogoURL(): string {
        // let LogoURL = 'http://ak-wks-1487:31417';
        let LogoURL = 'http://ahead';
        return LogoURL;
    }
    public static GetURL(apiURL: string): string {
        // let baseURL = 'http://192.168.101.129:8001';
        /***************************************/
        //// Dev
        //  let baseURL = 'http://ak-wks-1468:8081';
        /******************************************/
        //// Production
        let baseURL = 'http://ahead-spsearch:8080';
        return baseURL + apiURL;
    }
}
