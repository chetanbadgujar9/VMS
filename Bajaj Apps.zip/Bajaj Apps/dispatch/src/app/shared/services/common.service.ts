/* angular dependencies */
import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/finally';
import { Router } from '@angular/router';

/** Third party dependencies */
import { SpinnerService } from '../spinner/spinner.service';
import { Config } from '../config/config';
import { AuthHttp } from '../services/authHttp.service';
import { AuthInfo } from '../../dashboard/models/authInfo';

@Injectable()
export class CommonService {
    http: Http;
    constructor(http: Http,
        private authHttp: AuthHttp,
        private _spinnerService: SpinnerService,
        private router: Router) {
        this.http = http;
    }
    onTitleClick() {
        this.router.navigate(['/brand']);
    }
    //Get user auth token
    getAuthToken(credentials: AuthInfo) {
        let authenticateUrl = Config.GetURL('/api/Auth/Token');
        let headers = new Headers();
        let credentialString: string = 'grant_type=password&username=' + credentials.UserName + '&password=' + credentials.Password;
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let options = new RequestOptions({ headers: headers });
        return this.http.post(authenticateUrl, credentialString, options)
            .map((res: Response) => {
                this.setToken(res); //this.emitAuthEvent(true);
            })
            .catch(this.handleError);
    }

    //Get Logged In User Data
    getLoggedInUserDetails(username: any) {
        let url = Config.GetURL('/api/testrequest/BALRMSUGP/GetUGPDetailsByUserName?userName=' + username);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    // To get brand data
    getBrandData() {
        let url = Config.GetURL('/api/rms/BPM/GetBrandNames');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getMyData(username: any) {
        let url = Config.GetURL('/api/cashpurchase/RndUsers/GetRndUsersListByName?userName=' + username);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    addBrand(value: any) {
        let url = Config.GetURL('/api/testrequest/BPM/Post');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    updateBrand(value: any) {
        let url = Config.GetURL('/api/testrequest/BPM/UpdateBrandProjectByID');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    deleteBrand(value: any) {
        //TO DO : Need to Update API
        let url = Config.GetURL('/api/testrequest/BPM/UpdateBrandProjectByID');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getTransportationMode() {
        let url = Config.GetURL('/api/Dispatch/TransportationMode/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    addTransportationMode(value: any) {
        let url = Config.GetURL('/api/Dispatch/TransportationMode/Post');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    updateTransportationMode(value: any) {
        let url = Config.GetURL('/api/Dispatch/TransportationMode/UpdateTransportationModeByID');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }

    searchByDispatchRequestID(value: any) {
        let url = Config.GetURL('/api/Dispatch/DomesticDispatchRequest/GetDomesticDispatchRequestByRequestID/' + value);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }

    deleteTransportationMode(value: any) {
        let url = Config.GetURL('/api/Dispatch/TransportationMode/DeleteTransportationModeByID/' + value.ID);
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getBrandDataDispatch() {
        let url = Config.GetURL('/api/Dispatch/PM/GetBrandNames');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getPlantMaster() {
        let url = Config.GetURL('/api/Dispatch/Plant/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    addPlant(value: any) {
        let url = Config.GetURL('/api/Dispatch/Plant/Post');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    updatePlant(value: any) {
        let url = Config.GetURL('/api/Dispatch/Plant/UpdatePlantByID');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    deletePlant(value: any) {
        let url = Config.GetURL('/api/Dispatch/Plant/DeletePlantByID/' + value.ID);
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getStoreLocationList() {
        let url = Config.GetURL('/api/Dispatch/StoreLocations/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    addStoreLocation(value: any) {
        let url = Config.GetURL('/api/Dispatch/StoreLocations/Post');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    updateStoreLocation(value: any) {
        let url = Config.GetURL('/api/Dispatch/StoreLocations/UpdateStoreLocationByID');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    deleteStoreLocation(value: any) {
        let url = Config.GetURL('/api/Dispatch/StoreLocations/DeleteStoreLocationsByID/' + value.ID);
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getCountryMaster() {
        let url = Config.GetURL('/api/Dispatch/CountryMaster/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    addCountry(value: any) {
        let url = Config.GetURL('/api/Dispatch/CountryMaster/Post');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    updateCountry(value: any) {
        let url = Config.GetURL('/api/Dispatch/CountryMaster/UpdateCountryMasterByID');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    deleteCountry(value: any) {
        let url = Config.GetURL('/api/Dispatch/CountryMaster/DeleteCountryMasterByID/' + value.ID);
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }

    getRMSMenus() {
        let url = Config.GetURL('/api/CashPurchase/NavigationMaster/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getAdminAccess(username: any) {
        let url = Config.GetURL('/api/rms/farmadminusers/FarmAdminUsersByUserLoginName?userLoginName=' + username);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getGMList() {
        let url = Config.GetURL('/api/Dispatch/GM/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    addGM(value: any) {
        let url = Config.GetURL('/api/Dispatch/GM/Post');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    updateGM(value: any) {
        let url = Config.GetURL('/api/Dispatch/GM/UpdateGMByID');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    deleteGM(value: any) {
        let url = Config.GetURL('/api/Dispatch/GM/DeleteGMByID/' + value);
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getPMList() {
        let url = Config.GetURL('/api/Dispatch/PM/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    addPM(value: any) {
        let url = Config.GetURL('/api/Dispatch/PM/Post');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    updatePM(value: any) {
        let url = Config.GetURL('/api/Dispatch/PM/UpdatePMByID');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    deletePM(value: any) {
        let url = Config.GetURL('/api/Dispatch/PM/DeletePMByID/' + value);
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getDispatchGroupList(username: any) {
        let url = Config.GetURL('/api/Dispatch/DispatchGroup/DispatchGroupUserByName?name=' + username);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getDispatchGroup() {
        let url = Config.GetURL('/api/Dispatch/DispatchGroup/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    addDispatchGroup(value: any) {
        let url = Config.GetURL('/api/Dispatch/DispatchGroup/Post');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    updateDispatchGroup(value: any) {
        let url = Config.GetURL('/api/Dispatch/DispatchGroup/UpdateDispatchGroupByID');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    deleteDispatchGroup(value: any) {
        let url = Config.GetURL('/api/Dispatch/DispatchGroup/DeleteDispatchGroupByID/' + value);
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getAssignToUsers(username: string) {
        let url = Config.GetURL('/api/ahead/UserInformationList/GetUserInformationListByName?userName=' + username);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }

    getBrands(username: string) {
        let url = Config.GetURL('/api/PM/PM/GetBrandNames');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }

    getAllPendingGLRequest_Admin(status: any) {
        let url = Config.GetURL('/api/Dispatch/DomesticDispatchRequest/GetAllDomesticDispatchRequestsByStatus?status=' + status);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getAllExportPendingGLRequest_Admin(status: any) {
        let url = Config.GetURL('/api/Dispatch/ExportDispatchRequest/GetAllExportDispatchRequestsByStatus?status=' + status);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    glApproval_Admin(payload: any) {
        let url = Config.GetURL('/api/Dispatch/DomesticDispatchRequest/GLActionOnRequestByAdmin');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    gmApproval_Admin(payload: any) {
        let url = Config.GetURL('/api/Dispatch/DomesticDispatchRequest/GMActionOnRequestByAdmin');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    glExportApproval_Admin(payload: any) {
        let url = Config.GetURL('/api/Dispatch/ExportDispatchRequest/GLActionOnExportRequestByAdmin');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    gmExportApproval_Admin(payload: any) {
        let url = Config.GetURL('/api/Dispatch/ExportDispatchRequest/GMActionOnExportRequestByAdmin');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    l1ExportApproval_Admin(payload: any) {
        let url = Config.GetURL('/api/Dispatch/ExportDispatchRequest/L1ActionOnExportRequestByAdmin');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    /**Set Token in localstorage */
    private setToken(res: Response) {
        if (res.status < 200 || res.status >= 300) {
            throw new Error('Bad response status: ' + res.status);
        }
        let body = res.json();
        sessionStorage.setItem('access_token', body.access_token);
        return body || {};
    }

    /**Success Handler */
    private extractData(res: Response) {
        if (res.status < 200 || res.status >= 300) {
            throw new Error('Bad response status: ' + res.status);
        }
        let body = res.json();
        return body || {};
    }

    /**Error Handler */
    private handleError(error: Response) {
        console.log(error);
        return Observable.throw(error.json().error || 'Server error');
    }

}
