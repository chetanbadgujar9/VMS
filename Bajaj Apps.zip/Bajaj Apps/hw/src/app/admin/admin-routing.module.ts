import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CanteenComponent } from './components/canteen/canteen.component';
import { EmailComponent } from './components/email/email.component';
import { EquipmentComponent } from './components/equipment/equipment.component';
import { PlantheadComponent } from './components/planthead/planthead.component';
import { ShiftComponent } from './components/shift/shift.component';
import { GLComponent } from './components/GLApproval/GL.component';
import { RequestCancellationComponent } from './components/RequestCancellation/requestCancel.component';

@NgModule({
  imports: [
    RouterModule.forChild([
      { path: 'canteen', component: CanteenComponent },
      { path: 'email', component: EmailComponent },
      { path: 'equipment', component: EquipmentComponent },
      { path: 'planthead', component: PlantheadComponent },
      { path: 'shift', component: ShiftComponent },
      { path: 'GL', component: GLComponent },
      { path: 'requestCancellation', component: RequestCancellationComponent }
    ])
  ],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
