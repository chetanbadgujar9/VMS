import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CanteenComponent } from './components/canteen/canteen.component';
import { EmailComponent } from './components/email/email.component';
import { EquipmentComponent } from './components/equipment/equipment.component';
import { PlantheadComponent } from './components/planthead/planthead.component';
import { ShiftComponent } from './components/shift/shift.component';
import { GLComponent } from './components/GLApproval/GL.component';
import { RequestCancellationComponent } from './components/RequestCancellation/requestCancel.component';
import { AdminRoutingModule } from './admin-routing.module';
import { BrowserModule } from '@angular/platform-browser';
import { SharedModule } from '../shared/shared.module';
import { CommonService } from '../shared/services/common.service';

@NgModule({
    imports: [CommonModule, AdminRoutingModule, SharedModule],
    declarations: [CanteenComponent, EmailComponent, EquipmentComponent, PlantheadComponent, ShiftComponent,GLComponent,RequestCancellationComponent],
    exports: [CanteenComponent, EmailComponent, EquipmentComponent, PlantheadComponent, ShiftComponent,GLComponent,RequestCancellationComponent],
    providers: [CommonService]
})
export class AdminModule { }
