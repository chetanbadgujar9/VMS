import { Component, OnInit, NgModule, trigger, transition, style, animate, state, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { MessageService } from '../../../shared/services/message.service';
import { CommonService } from '../../../shared/services/common.service';
import { ConfirmationService } from 'primeng/primeng';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SelectItem } from 'primeng/primeng';
import { DashboardService } from '../../../dashboard/services/dashboard.service';
import { Brand } from '../../model/brand';
import { Holiday } from '../../../dashboard/models/holiday';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-GL',
    templateUrl: 'GL.component.html',
    styleUrls: ['GL.component.css'],
    providers: [ConfirmationService]
})
export class GLComponent implements OnInit {
    adminData: any[];
    Id: any = '';
    errorFlag: boolean = false;
    errorMessage: string;
    @Output() dashboardFlag = new EventEmitter();
    constructor(private _messageService: MessageService,
        private _commonService: CommonService,
        private _confirmationService: ConfirmationService,
        private _dashboardservice: DashboardService,
        private formBuilder: FormBuilder) {
    }
    ngOnInit() {
        this._messageService.AddDashboardFlag(false);
        this.getAllGLPendingRequest();
    }

    getAllGLPendingRequest() {
        this._dashboardservice.getAllPendingRequest()
            .subscribe(
            (results: any) => {
                    this.adminData = results;
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onApprove(request: Holiday) {
        let value = {};
        if (request.Status === '1. Pending for GL Approval') {
            value = {
                'ID': request.ID,
                'Status': 'Approved',
                'Role': 'Group Leader'
            };
        }
        if (request.Status === 'Pending for Plant Approval') {
            value = {
                'ID': request.ID,
                'Status': 'Approved',
                'Role': 'Platform Leader'
            };
        }
        this._dashboardservice.ApproveRejectHolidayWorking(value)
            .subscribe(
            (results: any) => {
                this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                this.getAllGLPendingRequest();
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onReject(request: Holiday) {
        let value = {};
        if (request.Status === '1. Pending for GL Approval') {
            value = {
                'ID': request.ID,
                'Status': 'Rejected',
                'Role': 'Group Leader'
            };
        }
        if (request.Status === 'Pending for Plant Approval') {
            value = {
                'ID': request.ID,
                'Status': 'Rejected',
                'Role': 'Platform Leader'
            };
        }
        this._dashboardservice.ApproveRejectHolidayWorking(value)
            .subscribe(
            (results: any) => {
                this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                this.getAllGLPendingRequest();
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onCancel(request: Holiday) {
        let value = { 'ID': request.ID, 'Status': 'Cancelled' }
        this._dashboardservice.cancelByAdminHolidayWorking(value)
            .subscribe(
            (results: any) => {
                this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                this.getAllGLPendingRequest();
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    //Format date in "yyyy-mm-dd" format
    formatDate(date: any) {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();
        if (month.length < 2) month = '0' + month;
        if (day.length < 2) day = '0' + day;

        return [month, day, year].join('/');
    }
}
