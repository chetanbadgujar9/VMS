import { Component, OnInit, NgModule, trigger, transition, style, animate, state, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { MessageService } from '../../../shared/services/message.service';
import { CommonService } from '../../../shared/services/common.service';
import { ConfirmationService } from 'primeng/primeng';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SelectItem } from 'primeng/primeng';
import { Canteen } from '../../model/canteen';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-canteen',
    templateUrl: 'canteen.component.html',
    styleUrls: ['canteen.component.css'],
    providers: [ConfirmationService]
})
export class CanteenComponent implements OnInit {
    canteenData: any[];
    errorMessage: string;
    showCanteenForm: boolean = false;
    CanteenForm: FormGroup;
    Id: any = '';
    errorFlag: boolean = false;
    maxlength: any = 100;
    canteen: any;
    characterleft: any;
    @Output() dashboardFlag = new EventEmitter();
    constructor(private _messageService: MessageService,
        private _commonService: CommonService,
        private _confirmationService: ConfirmationService,
        private formBuilder: FormBuilder) {
    }
    ngOnInit() {
        this.characterleft = this.maxlength;
        this._messageService.AddDashboardFlag(false);
        this.setForm();
        this.getCanteenList();
    }
    setForm() {
        this.CanteenForm = this.formBuilder.group({
            Title: ['', [Validators.required]]
        });
    }
    onAddCanteen() {
        this.characterleft = 100;
        this.canteen = '';
        this.setForm();
        this.showCanteenForm = true;
    }
    onCancel() {
        this.errorFlag = false;
        this.characterleft = 100;
        this.CanteenForm.setValue({
            Title: ''
        })
        this.showCanteenForm = false;
    }
    getCanteenList() {
        this._commonService.getCanteenfacility()
            .subscribe(
            (results: any) => {
                this.canteenData = results;
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });

            });
    }
    countChars(canteen: any) {
        if (this.maxlength >= canteen.length) {
            this.characterleft = (this.maxlength) - (canteen.length);
        }
        else {
            this.canteen = canteen.substr(0, canteen.length - 1);
        }
    }
    onEdit(stage: Canteen) {
        this.showCanteenForm = true;
        this.Id = stage.ID;
        this.CanteenForm.setValue({
            Title: stage.Title
        })
    }
    onDelete(stage: Canteen) {
        this._confirmationService.confirm({
            message: 'Are you sure that you want to delete?',
            accept: () => {
                this._commonService.deleteCanteen(stage)
                    .subscribe(
                    (results: any) => {
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getCanteenList();
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
        });

    }
    onSubmit({ value, valid }: { value: Canteen, valid: boolean }) {
        if (valid) {
            value.Title = value.Title ? value.Title.replace(/'/g, "\\'").trim() : '';
            if (this.Id === '') {
                this._commonService.addCanteen(value)
                    .subscribe(
                    (results: any) => {
                        this.Id = '';
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getCanteenList();
                        this.showCanteenForm = false;
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
            if (this.Id !== '') {
                value.ID = this.Id;
                this._commonService.updateCanteen(value)
                    .subscribe(
                    (results: any) => {
                        this.Id = '';
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getCanteenList();
                        this.showCanteenForm = false;
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }

        } else {
            this.errorFlag = true;
        }

    }
}
