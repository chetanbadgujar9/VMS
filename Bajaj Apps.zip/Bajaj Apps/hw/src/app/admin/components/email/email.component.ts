import { Component, OnInit, NgModule, trigger, transition, style, animate, state, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { MessageService } from '../../../shared/services/message.service';
import { CommonService } from '../../../shared/services/common.service';
import { ConfirmationService } from 'primeng/primeng';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SelectItem } from 'primeng/primeng';
import { Canteen } from '../../model/canteen';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-email',
    templateUrl: 'email.component.html',
    styleUrls: ['email.component.css'],
    providers: [ConfirmationService]
})
export class EmailComponent implements OnInit {
    emailData: any[];
    errorMessage: string;
    showEmailForm: boolean = false;
    EmailForm: FormGroup;
    Id: any = '';
    errorFlag: boolean = false;
    maxlength: any = 100;
    email: any;
    ownerEmailFlag: boolean = false;
    characterleft: any;
    @Output() dashboardFlag = new EventEmitter();
    constructor(private _messageService: MessageService,
        private _commonService: CommonService,
        private _confirmationService: ConfirmationService,
        private formBuilder: FormBuilder) {
    }
    ngOnInit() {
        this.characterleft = this.maxlength;
        this._messageService.AddDashboardFlag(false);
        this.setForm();
        this.getEmailList();
    }
    setForm() {
        this.EmailForm = this.formBuilder.group({
            Title: ['', [Validators.required]]
        });
    }
    onAddEmail() {
        this.characterleft = 100;
        this.email = '';
        this.setForm();
        this.showEmailForm = true;
    }
    onCancel() {
        this.errorFlag = false;
        this.characterleft = 100;
        this.EmailForm.setValue({
            Title: ''
        })
        this.showEmailForm = false;
    }
    getEmailList() {
        this._commonService.getEmailList()
            .subscribe(
            (results: any) => {
                this.emailData = results;
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });

            });
    }
    countChars(email: any) {
         if (this.maxlength >= email.length) {
            this.characterleft = (this.maxlength) - (email.length);
        }
        else {
            this.email = email.substr(0, email.length - 1);
        }
        this.email = this.email.toLowerCase();

        var x = email;
        var atpos = x.indexOf("@");
        var dotpos = x.lastIndexOf(".");
        if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= x.length) {
            this.ownerEmailFlag = true;
        } else {
            this.ownerEmailFlag = false;
        }
    }
    onEdit(stage: Canteen) {
        this.showEmailForm = true;
        this.Id = stage.ID;
        this.EmailForm.setValue({
            Title: stage.Title
        })
    }
    onDelete(stage: Canteen) {
        this._confirmationService.confirm({
            message: 'Are you sure that you want to delete?',
            accept: () => {
                this._commonService.deleteEmail(stage)
                    .subscribe(
                    (results: any) => {
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getEmailList();
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
        });

    }
    onSubmit({ value, valid }: { value: Canteen, valid: boolean }) {
        if (valid) {
            if (this.Id === '') {
                this._commonService.addEmail(value)
                    .subscribe(
                    (results: any) => {
                        this.Id = '';
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getEmailList();
                        this.showEmailForm = false;
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
            if (this.Id !== '') {
                value.ID = this.Id;
                this._commonService.updateEmail(value)
                    .subscribe(
                    (results: any) => {
                        this.Id = '';
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getEmailList();
                        this.showEmailForm = false;
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }

        } else {
            this.errorFlag = true;
        }

    }
}
