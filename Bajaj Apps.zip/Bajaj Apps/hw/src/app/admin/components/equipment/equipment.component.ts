import { Component, OnInit, NgModule, trigger, transition, style, animate, state, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { MessageService } from '../../../shared/services/message.service';
import { CommonService } from '../../../shared/services/common.service';
import { ConfirmationService } from 'primeng/primeng';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SelectItem } from 'primeng/primeng';
import { Testtype } from '../../model/testtype';
import { DashboardService } from '../../../dashboard/services/dashboard.service';
import { Canteen } from '../../model/canteen';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-equipment',
    templateUrl: 'equipment.component.html',
    styleUrls: ['equipment.component.css'],
    providers: [ConfirmationService]
})
export class EquipmentComponent implements OnInit {
    equipmentData: any[];
    errorMessage: string;
    showEquipmentForm: boolean = false;
    EquipmentForm: FormGroup;
    Id: any = '';
    errorFlag: boolean = false;
    maxlength: any = 100;
    equipment: any;
    characterleft: any;
    @Output() dashboardFlag = new EventEmitter();
    constructor(private _messageService: MessageService,
        private _commonService: CommonService,
        private _confirmationService: ConfirmationService,
        private formBuilder: FormBuilder) {
    }
    ngOnInit() {
        this.characterleft = this.maxlength;
        this._messageService.AddDashboardFlag(false);
        this.setForm();
        this.getEquipmentList();
    }
    setForm() {
        this.EquipmentForm = this.formBuilder.group({
            Title: ['', [Validators.required]]
        });
    }
    onAddCanteen() {
        this.characterleft = 100;
        this.equipment = '';
        this.setForm();
        this.showEquipmentForm = true;
    }
    onCancel() {
        this.errorFlag = false;
        this.characterleft = 100;
        this.EquipmentForm.setValue({
            Title: ''
        })
        this.showEquipmentForm = false;
    }
    getEquipmentList() {
        this._commonService.getUtilityFacility()
            .subscribe(
            (results: any) => {
                this.equipmentData = results;
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });

            });
    }
    countChars(equipment: any) {
        if (this.maxlength >= equipment.length) {
            this.characterleft = (this.maxlength) - (equipment.length);
        }
        else {
            this.equipment = equipment.substr(0, equipment.length - 1);
        }
    }
    onEdit(stage: Canteen) {
        this.showEquipmentForm = true;
        this.Id = stage.ID;
        this.EquipmentForm.setValue({
            Title: stage.Title
        })
    }
    onDelete(stage: Canteen) {
        this._confirmationService.confirm({
            message: 'Are you sure that you want to delete?',
            accept: () => {
                this._commonService.deleteEquipment(stage)
                    .subscribe(
                    (results: any) => {
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getEquipmentList();
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
        });

    }
    onSubmit({ value, valid }: { value: Canteen, valid: boolean }) {
        if (valid) {
            value.Title = value.Title ? value.Title.replace(/'/g, "\\'").trim() : '';
            if (this.Id === '') {
                this._commonService.addEquipment(value)
                    .subscribe(
                    (results: any) => {
                        this.Id = '';
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getEquipmentList();
                        this.showEquipmentForm = false;
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
            if (this.Id !== '') {
                value.ID = this.Id;
                this._commonService.updateEquipment(value)
                    .subscribe(
                    (results: any) => {
                        this.Id = '';
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getEquipmentList();
                        this.showEquipmentForm = false;
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }

        } else {
            this.errorFlag = true;
        }

    }
}
