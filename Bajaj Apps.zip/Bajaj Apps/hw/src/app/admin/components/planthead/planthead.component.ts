import { Component, OnInit, NgModule, trigger, transition, style, animate, state, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { MessageService } from '../../../shared/services/message.service';
import { CommonService } from '../../../shared/services/common.service';
import { ConfirmationService } from 'primeng/primeng';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SelectItem } from 'primeng/primeng';
import { PlantHead } from '../../model/planthead';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-planthead',
    templateUrl: 'planthead.component.html',
    styleUrls: ['planthead.component.css'],
    providers: [ConfirmationService]
})
export class PlantheadComponent implements OnInit {
    plantheadData: any[];
    assignToUsers: any[];
    errorMessage: string;
    showPlantHeadForm: boolean = false;
    PlantHeadForm: FormGroup;
    Id: any = '';
    errorFlag: boolean = false;
    planthead: any;
    @Output() dashboardFlag = new EventEmitter();
    constructor(private _messageService: MessageService,
        private _commonService: CommonService,
        private _confirmationService: ConfirmationService,
        private formBuilder: FormBuilder) {
    }
    ngOnInit() {
        this._messageService.AddDashboardFlag(false);
        this.setForm();
        this.getPlantHeadList();
    }
    setForm() {
        this.PlantHeadForm = this.formBuilder.group({
            Head: ['', [Validators.required]]
        });
    }
    onAddPantHead() {
        this.planthead = '';
        this.setForm();
        this.showPlantHeadForm = true;
    }
    onCancel() {
        this.errorFlag = false;
        this.PlantHeadForm.setValue({
            Head: ''
        })
        this.showPlantHeadForm = false;
    }
    getAssignToUsers(event: any) {
        //Need To change API
        let query = event.query;
        this._commonService.getAssignToUsers(query)
            .subscribe(
            (results: any) => {
                this.assignToUsers = results;
                //this.assignToUsers =[ {'ID':1,'name':'Amol'},{'ID':2,'name':'Amul'}];
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    getPlantHeadList() {
        this._commonService.getPlantHeadList()
            .subscribe(
            (results: any) => {
                this.plantheadData = results;
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });

            });
    }
    onEdit(planthead: PlantHead) {
        this.showPlantHeadForm = true;
        this.Id = planthead.ID;
        this.PlantHeadForm.setValue({
            Head: planthead.Head.Name
        })
    }
    onDelete(planthead: PlantHead) {
        this._confirmationService.confirm({
            message: 'Are you sure that you want to delete?',
            accept: () => {
                this._commonService.deletePlanthead(planthead)
                    .subscribe(
                    (results: any) => {
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getPlantHeadList();
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
        });

    }
    onSubmit({ value, valid }: { value: PlantHead, valid: boolean }) {
        if (valid) {
            if (this.Id === '') {
                value.Title = 'Plant Head';
                this._commonService.addPlanthead(value)
                    .subscribe(
                    (results: any) => {
                        this.Id = '';
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getPlantHeadList();
                        this.showPlantHeadForm = false;
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
            if (this.Id !== '') {
                value.ID = this.Id;
                value.Title = 'Plant Head';
                this._commonService.updatePlanthead(value)
                    .subscribe(
                    (results: any) => {
                        this.Id = '';
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getPlantHeadList();
                        this.showPlantHeadForm = false;
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }

        } else {
            this.errorFlag = true;
        }

    }
}
