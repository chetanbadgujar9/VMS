import { Component, OnInit, NgModule, trigger, transition, style, animate, state, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { MessageService } from '../../../shared/services/message.service';
import { CommonService } from '../../../shared/services/common.service';
import { ConfirmationService } from 'primeng/primeng';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SelectItem } from 'primeng/primeng';
import { Canteen } from '../../model/canteen';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-shift',
    templateUrl: 'shift.component.html',
    styleUrls: ['shift.component.css'],
    providers: [ConfirmationService]
})
export class ShiftComponent implements OnInit {
    shiftData: any[];
    errorMessage: string;
    showShiftForm: boolean = false;
    ShiftForm: FormGroup;
    Id: any = '';
    errorFlag: boolean = false;
    maxlength: any = 100;
    shift: any;
    characterleft: any;
    @Output() dashboardFlag = new EventEmitter();
    constructor(private _messageService: MessageService,
        private _commonService: CommonService,
        private _confirmationService: ConfirmationService,
        private formBuilder: FormBuilder) {
    }
    ngOnInit() {
        this.characterleft = this.maxlength;
        this._messageService.AddDashboardFlag(false);
        this.setForm();
        this.getShift();
    }
    setForm() {
        this.ShiftForm = this.formBuilder.group({
            Title: ['', [Validators.required]]
        });
    }
    onAddShift() {
        this.characterleft = 100;
        this.shift = '';
        this.setForm();
        this.showShiftForm = true;
    }
    onCancel() {
        this.errorFlag = false;
        this.characterleft = 100;
        this.ShiftForm.setValue({
            Title: ''
        })
        this.showShiftForm = false;
    }
    getShift() {
        this._commonService.getShift()
            .subscribe(
            (results: any) => {
                this.shiftData = results;
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });

            });
    }
    countChars(shift: any) {
        if (this.maxlength >= shift.length) {
            this.characterleft = (this.maxlength) - (shift.length);
        }
        else {
            this.shift = shift.substr(0, shift.length - 1);
        }
    }
    onEdit(stage: Canteen) {
        this.showShiftForm = true;
        this.Id = stage.ID;
        this.ShiftForm.setValue({
            Title: stage.Title
        })
    }
    onDelete(stage: Canteen) {
        this._confirmationService.confirm({
            message: 'Are you sure that you want to delete?',
            accept: () => {
                this._commonService.deleteShift(stage)
                    .subscribe(
                    (results: any) => {
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getShift();
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
        });

    }
    onSubmit({ value, valid }: { value: Canteen, valid: boolean }) {
        if (valid) {
            value.Title = value.Title ? value.Title.replace(/'/g, "\\'").trim() : '';
            if (this.Id === '') {
                this._commonService.addShift(value)
                    .subscribe(
                    (results: any) => {
                        this.Id = '';
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getShift();
                        this.showShiftForm = false;
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
            if (this.Id !== '') {
                value.ID = this.Id;
                this._commonService.updateShift(value)
                    .subscribe(
                    (results: any) => {
                        this.Id = '';
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getShift();
                        this.showShiftForm = false;
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }

        } else {
            this.errorFlag = true;
        }

    }
}
