import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/index';
import { AboutComponent } from './aboutMe/components/aboutme.component';
import {
  CanteenComponent
  , EmailComponent
  , EquipmentComponent
  , GLComponent
  , PlantheadComponent
  , RequestCancellationComponent
  , ShiftComponent
} from './admin/index';
import { UnAuthorizedComponent } from './unAuthorized/components/unauthorized.component';

const routes: Routes = [
  { path: 'canteen', component: CanteenComponent },
  { path: 'email', component: EmailComponent },
  { path: 'equipment', component: EquipmentComponent },
  { path: 'planthead', component: PlantheadComponent },
  { path: 'shift', component: ShiftComponent },
  { path: 'GL', component: GLComponent },
  { path: 'requestCancellation', component: RequestCancellationComponent },
  { path: 'aboutMe', component: AboutComponent },
  { path: 'unauthorized/:id', component: UnAuthorizedComponent },
  { path: 'dashboard', component: DashboardComponent, pathMatch: 'full' },
  { path: 'dashboard', component: DashboardComponent, pathMatch: 'full' },
  { path: '**', component: DashboardComponent },
  { path: 'TestRequestApp/dist', redirectTo: 'dashboard', pathMatch: 'full' }
];

@NgModule({
  imports: [
    RouterModule.forRoot(
      routes
    )
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }

