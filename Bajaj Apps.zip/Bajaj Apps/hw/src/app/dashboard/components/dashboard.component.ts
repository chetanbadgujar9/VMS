import { Component, OnInit, NgModule, trigger, transition, style, animate, state } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ConfirmationService } from 'primeng/primeng';
import { Router } from '@angular/router';
import { Holiday } from '../models/holiday';
import { Common } from '../../shared/common/common';
import { CommonService } from '../../shared/services/common.service';
import { MessageService } from '../../shared/services/message.service';
import { DashboardService } from '../services/dashboard.service';
import { AuthInfo } from '../models/authInfo';
import { User } from '../models/loginUser';
declare var saveAs: any;
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
  moduleId: module.id,
  selector: 'sd-dashboard',
  templateUrl: 'dashboard.component.html',
  styleUrls: ['dashboard.component.css'],
  providers: [ConfirmationService]
})
export class DashboardComponent implements OnInit {
  /** List Varibales To Bind Data */
  cars: any[] = [];
  cols: any[] = [];
  employeeInfo: any = [];
  colsForEmp: any[];
  shiftData: any[];
  selectedCanteen: string[] = [];
  selectedUtility: string[] = [];
  enggTicket: any[];
  canteenData: any[];
  utilityData: any[];
  holidayWorkingData: any[];
  counterData: any[];
  attachmentURL: any = {};
  rmsMenu: any[];

  /**Model Variables */
  loggedInUserData: User = new User();

  /**Form Variables */
  holidayWorkingForm: FormGroup;

  /** Flags Variables */
  showHolidayWorkingForm: boolean = false;
  showFileUpload: boolean = true;
  showFileName: boolean = false;
  showProgessBar: boolean = false;
  showEnggTktErr: boolean = false;
  showMobileErr: boolean = false;
  enggInfoErr: boolean = false;
  chooseFileErr: boolean = false;
  disableSubmit: boolean = false;
  errCompoff: boolean = false;

  /**Genaral Variables */
  minDate: Date;
  status: string = 'Pending for GL Approval';
  ButtonName: string = 'Submit';
  loggedInUser: string; // = 'cnt_chetan';//KIRAN K. DANI
  loginName: string = '';
  errorFlagForAdd: boolean = false;
  characterleftWA: any;
  characterleftNOW: any;
  characterleftEqpNeeded: any;
  characterleftETN: any;
  workingArea: string;
  natureOfWork: string;
  equNeeded: string;
  errorMessage: string;
  EmpType: string;
  enggTkt: any = { 'name': '' };
  compOffDate: Date;
  mobile: string;
  twoDays: boolean = false;
  filesData: any;
  fileUploaded: boolean = false;
  fileName: string;
  progressValue: number = 0;
  fileResult: any[];
  toDate: Date;
  loggedInUserRole: any;
  AttachmentURL: boolean = false;
  showApproveReject: boolean = false;
  Attachments: boolean = false;
  requestID: any;
  binaryFileToDownload: string;
  headingColor: string = '#f0ad4e';
  holidayDate: Date = new Date();

  /**Approve Reject Variables */
  workArea: string;
  FromDate: string;
  ToDate: string;
  shift: string;
  finalstatus: string;
  /** Model Classes */
  common: Common = new Common();
  model: AuthInfo;

  constructor(private formBuilder: FormBuilder, private _commonService: CommonService,
    private _messageService: MessageService, private _dashboardservice: DashboardService,
    private _router: Router, private _confirmationService: ConfirmationService, ) {
    this.EmpType = 'Bajaj';
    this.filesData = new Array<File>();
    this.model = new AuthInfo('password', '', '');
    this.toDate = new Date();
    this.finalstatus = 'Approve';
    this.attachmentURL = {
      'FileName': '',
      'ServerRelativeUrl': ''
    };
  }
  ngOnInit() {
    this.minDate = new Date();
    // this.loginName = 'tcctest12';
    // this.loggedInUser = 'TCCTEST12';
    this.loginName = sessionStorage.getItem('Username') ? sessionStorage.getItem('Username').split('\\')[1] : '';
    this.loggedInUser = sessionStorage.getItem('UserTitle') ? sessionStorage.getItem('UserTitle') : '';
    this.characterleftWA = this.characterleftNOW = this.characterleftEqpNeeded = this.characterleftETN = this.common.maxlength250;
    this.setHolidayWorkingForm();
    if (sessionStorage.getItem('access_token') === null) {
      this.getAuthToken();
    } else {
      this.loggedInUserData = JSON.parse(sessionStorage.getItem('loggedInUserData'));
      this.loggedInUserRole = this.loggedInUserData ? this.loggedInUserData.Role2 : '';
      this.getAdminAccess(this.loginName);
      this.getRMSMenus();
      if (this.loggedInUserRole !== '') {
        this._messageService.AddUserRole(this.loggedInUserRole);
        this.onPendingGL();
      } else {
        this._router.navigate(['/unauthorized',
          'You are not Authorized to access this site due to UGP mapping does not exist. Please contact Ahead portal support team.']);
      }
    }
  }
  getAuthToken() {
    this.model.UserName = this.loginName;
    this.model.Password = '';
    this._commonService.getAuthToken(this.model)
      .subscribe(
      (results: any) => {
        this.getLoggedInUserDetails();
        this.getRMSMenus();
        this.getAdminAccess(this.loginName);
      },
      error => {
        this.errorMessage = <any>error;
        this._router.navigate(['/unauthorized',
          'You are not Authorized to access this site due to UGP mapping does not exist. Please contact Ahead portal support team.']);
      });
  }
  getLoggedInUserDetails() {
    this._commonService.getLoggedInUserDetails(this.loggedInUser)
      .subscribe(
      (results: any) => {
        if (Object.keys(results).length !== 0) {
          this.loggedInUserData = results;
          this.loggedInUserRole = results.Role2;
          this._messageService.AddUserRole(this.loggedInUserRole);
          sessionStorage.setItem('loggedInUserName', JSON.stringify(results.UserLookup));
          sessionStorage.setItem('loggedInUserData', JSON.stringify(results));
          sessionStorage.setItem('loggedInUserRole', this.loggedInUserRole);
          this.onPendingGL();
        } else {
          this._router.navigate(['/unauthorized',
            'You are not Authorized to access this site due to UGP mapping does not exist. Please contact Ahead portal support team.']);
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  /** Get Admin Access*/
  getAdminAccess(username: any) {
    this._commonService.getAdminAccess(username)
      .subscribe((results: any) => {
        if (Object.keys(results).length !== 0) {
          this._messageService.AddAdminAccess(true);
        }
      });
  }
  getRMSMenus() {
    this._commonService.getRMSMenus()
      .subscribe(
      (results: any) => {
        this.rmsMenu = results;
        this._messageService.AddRMSMenu(this.rmsMenu);
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  setHolidayWorkingForm() {
    this.holidayWorkingForm = this.formBuilder.group({
      FromDate: [new Date(), [Validators.required]],
      WorkingArea: ['', [Validators.required]],
      NatureOfWork: ['', [Validators.required]],
      TestEquipmentsNeeded: ['', [Validators.required]],
      WorkingShift: ['General'],
      CanteenFacilityNeeded: [''],
      UtilitiesNeeded: [''],
      EmpType: [''],
      EnggTkt: [''],
      CompOffDate: [new Date()],
      Mobile: [''],
      TwoDays: [''],
      // ToDate:[new Date()],
      // Attachments:[''],
      // EngineerInformation:[''],
      // RaisedBy:['']
    });
  }

  //Counter Clicks
  onPendingGL() {
    this.status = 'Pending for GL Approval';
    this.headingColor = '#f0ad4e';
    this.showApproveReject = false;
    this.showHolidayWorkingForm = false;
    if (this.loggedInUserRole.toLowerCase() === 'engineer' || this.loggedInUserRole.toLowerCase() === 'designer') {
      this.getGLPendingForApproval_Req();
      this.getRequesterCounters();
    }
    if (this.loggedInUserRole.toLowerCase() === 'group leader') {
      this.getGLPendingForApproval_GL();
      this.getGLCounters();
    }
    if (this.loggedInUserRole.toLowerCase() === 'platform leader') {
      this.getGLPendingForApproval_l1();
      this.getL1Counters();
    }
    if (this.loggedInUserRole.toLowerCase() === 'plant head') {
      this.getGLPendingForApproval_PH();
      this.getPHCounters();
    }
  }
  getRequesterCounters() {
    this._dashboardservice.getRequesterCounters()
      .subscribe(
      (results: any) => {
        this.counterData = results;
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getGLCounters() {
    this._dashboardservice.getGLCounters()
      .subscribe(
      (results: any) => {
        this.counterData = results;
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getL1Counters() {
    this._dashboardservice.getL1Counters()
      .subscribe(
      (results: any) => {
        this.counterData = results;
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getPHCounters() {
    this._dashboardservice.getPHCounters()
      .subscribe(
      (results: any) => {
        this.counterData = results;
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  onPendingPlantHead() {
    this.status = 'Pending for Plant Head Approval';
    this.headingColor = '#f0ad4e';
    this.showApproveReject = false;
    this.showHolidayWorkingForm = false;
    if (this.loggedInUserRole.toLowerCase() === 'engineer' || this.loggedInUserRole.toLowerCase() === 'designer') {
      this.getPlantHeadPendingApproval_Req();
    }
    if (this.loggedInUserRole.toLowerCase() === 'group leader') {
      this.getPlantHeadPendingApproval_GL();
    }
    if (this.loggedInUserRole.toLowerCase() === 'platform leader') {
      this.getPlantHeadPendingApproval_l1();
    }
    if (this.loggedInUserRole.toLowerCase() === 'plant head') {
      this.getPlantHeadPendingApproval_PH();
    }
  }
  onApprovedClick() {
    this.status = 'Approved';
    this.headingColor = '#337ab7';
    this.showApproveReject = false;
    this.showHolidayWorkingForm = false;
    if (this.loggedInUserRole.toLowerCase() === 'engineer' || this.loggedInUserRole.toLowerCase() === 'designer') {
      this.getApproved_Req();
    }
    if (this.loggedInUserRole.toLowerCase() === 'group leader') {
      this.getApproved_GL();
    }
    if (this.loggedInUserRole.toLowerCase() === 'platform leader') {
      this.getApproved_l1();
    }
    if (this.loggedInUserRole.toLowerCase() === 'plant head') {
      this.getApproved_PH();
    }
  }
  onRejectedGLClick() {
    this.status = 'Rejected By GL';
    this.headingColor = '#d9534f';
    this.showApproveReject = false;
    this.showHolidayWorkingForm = false;
    if (this.loggedInUserRole.toLowerCase() === 'engineer' || this.loggedInUserRole.toLowerCase() === 'designer') {
      this.getRejectedGLApproval_Req();
    }
    if (this.loggedInUserRole.toLowerCase() === 'group leader') {
      this.getRejectedGLApproval_GL();
    }
    if (this.loggedInUserRole.toLowerCase() === 'platform leader') {
      this.getRejectedGLApproval_l1();
    }
    if (this.loggedInUserRole.toLowerCase() === 'plant head') {
      this.getRejectedGLApproval_PH();
    }
  }
  onRejectedPlantHeadClick() {
    this.status = 'Rejected By Plant Head';
    this.headingColor = '#d9534f';
    this.showApproveReject = false;
    this.showHolidayWorkingForm = false;
    if (this.loggedInUserRole.toLowerCase() === 'engineer' || this.loggedInUserRole.toLowerCase() === 'designer') {
      this.getRejectedPlantHeadApproval_Req();
    }
    if (this.loggedInUserRole.toLowerCase() === 'group leader') {
      this.getRejectedPlantHeadApproval_GL();
    }
    if (this.loggedInUserRole.toLowerCase() === 'platform leader') {
      this.getRejectedPlantHeadApproval_l1();
    }
    if (this.loggedInUserRole.toLowerCase() === 'plant head') {
      this.getPlantHeadPendingApproval_PH();
    }
  }

  // Service Call for all counters

  // For GL
  getGLPendingForApproval_GL() {
    this.holidayWorkingData = [];
    this._dashboardservice.getGLPendingForApproval_GL('1. Pending for GL Approval')
      .subscribe(
      (results: any) => {
        if (results.length > 0) {
          this.holidayWorkingData = results;
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getPlantHeadPendingApproval_GL() {
    this.holidayWorkingData = [];
    this._dashboardservice.getGLPendingForApproval_GL('2. Pending for Plant Approval')
      .subscribe(
      (results: any) => {
        if (results.length > 0) {
          this.holidayWorkingData = results;
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getApproved_GL() {
    this.holidayWorkingData = [];
    this._dashboardservice.getGLPendingForApproval_GL('3. Approved')
      .subscribe(
      (results: any) => {
        if (results.length > 0) {
          this.holidayWorkingData = results;
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getRejectedGLApproval_GL() {
    this.holidayWorkingData = [];
    this._dashboardservice.getGLPendingForApproval_GL('4. Rejected by GL')
      .subscribe(
      (results: any) => {
        if (results.length > 0) {
          this.holidayWorkingData = results;
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getRejectedPlantHeadApproval_GL() {
    this.holidayWorkingData = [];
    this._dashboardservice.getGLPendingForApproval_GL('5. Rejected by Plant Head')
      .subscribe(
      (results: any) => {
        if (results.length > 0) {
          this.holidayWorkingData = results;
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }

  // For L1
  getGLPendingForApproval_l1() {
    this.holidayWorkingData = [];
    this._dashboardservice.getGLPendingForApproval_l1('1. Pending for GL Approval')
      .subscribe(
      (results: any) => {
        if (results.length > 0) {
          this.holidayWorkingData = results;
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getPlantHeadPendingApproval_l1() {
    this.holidayWorkingData = [];
    this._dashboardservice.getGLPendingForApproval_l1('2. Pending for Plant Approval')
      .subscribe(
      (results: any) => {
        if (results.length > 0) {
          this.holidayWorkingData = results;
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getApproved_l1() {
    this.holidayWorkingData = [];
    this._dashboardservice.getGLPendingForApproval_l1('3. Approved')
      .subscribe(
      (results: any) => {
        if (results.length > 0) {
          this.holidayWorkingData = results;
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getRejectedGLApproval_l1() {
    this.holidayWorkingData = [];
    this._dashboardservice.getGLPendingForApproval_l1('4. Rejected by GL')
      .subscribe(
      (results: any) => {
        if (results.length > 0) {
          this.holidayWorkingData = results;
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getRejectedPlantHeadApproval_l1() {
    this.holidayWorkingData = [];
    this._dashboardservice.getGLPendingForApproval_l1('5. Rejected by Plant Head')
      .subscribe(
      (results: any) => {
        if (results.length > 0) {
          this.holidayWorkingData = results;
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }

  // For PH
  getGLPendingForApproval_PH() {
    this.holidayWorkingData = [];
    this._dashboardservice.getGLPendingForApproval_PH('1. Pending for GL Approval')
      .subscribe(
      (results: any) => {
        if (results.length > 0) {
          this.holidayWorkingData = results;
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getPlantHeadPendingApproval_PH() {
    this.holidayWorkingData = [];
    this._dashboardservice.getGLPendingForApproval_PH('2. Pending for Plant Approval')
      .subscribe(
      (results: any) => {
        if (results.length > 0) {
          this.holidayWorkingData = results;
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getApproved_PH() {
    this.holidayWorkingData = [];
    this._dashboardservice.getGLPendingForApproval_PH('3. Approved')
      .subscribe(
      (results: any) => {
        if (results.length > 0) {
          this.holidayWorkingData = results;
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getRejectedGLApproval_PH() {
    this.holidayWorkingData = [];
    this._dashboardservice.getGLPendingForApproval_PH('4. Rejected by GL')
      .subscribe(
      (results: any) => {
        if (results.length > 0) {
          this.holidayWorkingData = results;
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getRejectedPlantHeadApproval_PH() {
    this.holidayWorkingData = [];
    this._dashboardservice.getGLPendingForApproval_PH('5. Rejected by Plant Head')
      .subscribe(
      (results: any) => {
        if (results.length > 0) {
          this.holidayWorkingData = results;
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }

  // For Requester
  getGLPendingForApproval_Req() {
    this.holidayWorkingData = [];
    this._dashboardservice.getGLPendingForApproval_Req('1. Pending for GL Approval')
      .subscribe(
      (results: any) => {
        if (results.length > 0) {
          this.holidayWorkingData = results;
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }



  getPlantHeadPendingApproval_Req() {
    this.holidayWorkingData = [];
    this._dashboardservice.getGLPendingForApproval_Req('2. Pending for Plant Approval')
      .subscribe(
      (results: any) => {
        if (results.length > 0) {
          this.holidayWorkingData = results;
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getApproved_Req() {
    this.holidayWorkingData = [];
    this._dashboardservice.getGLPendingForApproval_Req('3. Approved')
      .subscribe(
      (results: any) => {
        if (results.length > 0) {
          this.holidayWorkingData = results;
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getRejectedGLApproval_Req() {
    this.holidayWorkingData = [];
    this._dashboardservice.getGLPendingForApproval_Req('4. Rejected by GL')
      .subscribe(
      (results: any) => {
        if (results.length > 0) {
          this.holidayWorkingData = results;
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getRejectedPlantHeadApproval_Req() {
    this.holidayWorkingData = [];
    this._dashboardservice.getGLPendingForApproval_Req('5. Rejected by Plant Head')
      .subscribe(
      (results: any) => {
        if (results.length > 0) {
          this.holidayWorkingData = results;
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  showSelect() {
    if ((this.loggedInUserRole === 'Group Leader' || this.loggedInUserRole === 'Platform Leader' || this.loggedInUserRole === 'Plant Head')
      && (this.status === 'Pending for Plant Head Approval' || this.status === 'Pending for GL Approval')) {
      return true;
    } else {
      return false;
    }
  }
  showCanteen(canteenData: any) {
    if (canteenData !== undefined) {
      if (Object.keys(canteenData).length === 0) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }
  onHolidayWorkingAdd() {
    this.showApproveReject = false;
    this.chooseFileErr = false;
    this.showHolidayWorkingForm = true;
    this.workingArea = '';
    this.natureOfWork = '';
    this.selectedCanteen = [];
    this.selectedUtility = [];
    this.EmpType = 'Bajaj';
    this.enggTkt.name = '';
    this.mobile = '';
    this.twoDays = false;
    this.compOffDate = new Date();
    this.employeeInfo = [];
    this.equNeeded = '';
    this.errorFlagForAdd = false;
    this.characterleftWA = this.characterleftNOW = this.characterleftEqpNeeded = this.characterleftETN = 250;
    this.setForm();
    this.getShift();
    this.getCanteenfacility();
    this.getUtilityFacility();
  }
  setForm() {
    this.holidayWorkingForm.setValue({
      FromDate: new Date(),
      WorkingArea: '',
      NatureOfWork: '',
      TestEquipmentsNeeded: '',
      WorkingShift: 'General',
      CanteenFacilityNeeded: '',
      UtilitiesNeeded: '',
      EmpType: '',
      EnggTkt: '',
      CompOffDate: new Date(),
      Mobile: '',
      TwoDays: ''
    });
  }
  getCanteenfacility() {
    this._commonService.getCanteenfacility()
      .subscribe(
      (results: any) => {
        this.canteenData = results;
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getUtilityFacility() {
    this._commonService.getUtilityFacility()
      .subscribe(
      (results: any) => {
        this.utilityData = results;
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getShift() {
    this._commonService.getShift()
      .subscribe(
      (results: any) => {
        this.shiftData = results;
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getEnggTicketNo(event: any) {
    // Need To change API
    let query = event.query;
    this._commonService.getEnggTicketNo(query)
      .subscribe(
      (results: any) => {
        this.enggTicket = results;
        // this.assignToUsers =[ {'ID':1,'name':'Amol'},{'ID':2,'name':'Amul'}];
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }

  countChars(model: any, from: any) {
    if (this.common.maxlength250 >= model.length) {
      switch (from) {
        case 'WorkArea': this.characterleftWA = (this.common.maxlength250) - (model.length);
          break;
        case 'NatureWork': this.characterleftNOW = (this.common.maxlength250) - (model.length);
          break;
        case 'EquNeeded': this.characterleftEqpNeeded = (this.common.maxlength250) - (model.length);
          break;
        case 'EngTkt': this.characterleftETN = (this.common.maxlength250) - (model.length);
          break;
      }

    }
    else {
      switch (from) {
        case 'WorkArea': this.workingArea = model.substr(0, model.length - 1);
          break;
        case 'NatureWork': this.natureOfWork = model.substr(0, model.length - 1);
          break;
        case 'EquNeeded': this.equNeeded = model.substr(0, model.length - 1);
          break;
        case 'EngTkt': this.enggTkt.name = model.substr(0, model.length - 1);
          break;
      }

    }
  }
  postFile(inputValue: any): void {
    var format = /[!@#$%^&*()+\-=\[\]{};':"\\|,.<>\/?]+/;
    try {
      let FileList: FileList = inputValue.target.files;
      if (FileList.length > 0) {
        if (inputValue.target.files[0].size < 10000000) {
          if (inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'docx' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'doc' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'xls' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'xlsx' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'tif' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'tiff' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'gif' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'jpeg' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'jpg' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'png' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'pdf' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'ppt' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'pptx' ||
            inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'zip') {
            if (!format.test(inputValue.target.files[0].name.split('.')[0])) {
              this.showProgessBar = true;
              this.filesData.length = 0;
              for (let i = 0, length = FileList.length; i < length; i++) {
                this.filesData.push(FileList.item(i));
                this.fileUploaded = true;
                this.fileName = FileList.item(i).name;
                this.AttachmentURL = true;
                this.chooseFileErr = false;
              }
            } else {
              this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: 'Please remove special characters from filename' });
            }
          } else {
            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: 'Please upload document of type of supperted type' });
          }
        } else {
          this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: 'Please upload document of size less than 2 MB' });
        }
      } else {
        this.AttachmentURL = false;
      }
    } catch (error) {
      document.write(error);
    }

  }
  onEmpType(model: any) {
    if (model === 'Bajaj') {
      this.enggInfoErr = false;
      this.twoDays = false;
      this.fileName = '';
      this.filesData = [];
      this.employeeInfo = [];
      this.showEnggTktErr = false;
      this.showMobileErr = false;
      this.toDate = new Date();

    }
    if (model === 'Contract') {
      this.enggTkt.name = '';
      this.compOffDate = new Date();
      this.mobile = '';
      this.employeeInfo = [];
      this.showEnggTktErr = false;
      this.showMobileErr = false;
      this.chooseFileErr = false;
    }
  }
  onHolidayDate(event: any) {
    this.holidayDate = event;
  }
  onCompOffDate(event: any) {
    this.compOffDate = event;
  }
  onAddEmpInfo() {
    let count;
    count = this.employeeInfo.length + 1;
    let empObj = {};
    let mob_reg = /^[(]{0,1}[0-9]{3}[)\.\- ]{0,1}[0-9]{3}[\.\- ]{0,1}[0-9]{4}$/
    if (this.enggTkt.name.name !== undefined) {
      this.showEnggTktErr = false;
      if (this.compOffDate > this.holidayWorkingForm.controls['FromDate'].value) {
        this.errCompoff = false;
        if (this.mobile.length === 10 && this.mobile.match(mob_reg)) {
          this.showMobileErr = false;
          empObj = { 'id': count, 'EmployeeName': this.enggTkt.name.name, 'CompOffDate': this.compOffDate, 'Mobile': this.mobile };
          this.employeeInfo.push(empObj);
          this.enggTkt.name = '';
          this.compOffDate = new Date();
          this.mobile = '';
          this.enggInfoErr = false;
        } else {
          this.showMobileErr = true;
        }
      } else {
        this.errCompoff = true;
      }
    } else {
      this.showEnggTktErr = true;
    }
  }
  onSelectRequest(request: Holiday) {
    this.showApproveReject = true;
    this.showHolidayWorkingForm = false;
    this.requestID = request.ID;
    this._dashboardservice.getHolidayWorkingByID(request.ID)
      .subscribe(
      (results: Holiday) => {
        if (Object.keys(results).length !== 0) {
          this.attachmentURL = results.AttachmentFiles ? results.AttachmentFiles[0] : [];
          this.Attachments = results.Attachments;
          this.workArea = results.WorkingArea;
          this.FromDate = (results.FromDate).toString();
          this.ToDate = (results.ToDate).toString();
          this.natureOfWork = results.NatureOfWork;
          this.equNeeded = results.TestEquipmentsNeeded;
          this.canteenData = results.CanteenFacilityNeeded;
          this.shift = results.WorkingShift;
          this.utilityData = results.UtilitiesNeeded;
          this.employeeInfo = results.EngineerInformation;
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  onSubmitHolidayWorking({ value, valid }: { value: Holiday, valid: boolean }) {
    //value.FromDate = this.holidayDate;
    debugger;
    if (valid) {
      value.WorkingArea = value.WorkingArea ? value.WorkingArea.replace(/'/g, "\\'").trim() : '';
      value.NatureOfWork = value.NatureOfWork ? value.NatureOfWork.replace(/'/g, "\\'").trim() : '';
      value.TestEquipmentsNeeded = value.TestEquipmentsNeeded ? value.TestEquipmentsNeeded.replace(/'/g, "\\'").trim() : '';
      let loggedInDetails = JSON.parse(sessionStorage.getItem('loggedInUserName'));
      value.RaisedBy = loggedInDetails;
      // value.ToDate = this.holidayDate;
      if (value.TwoDays) {
        this.toDate = new Date(value.FromDate);
        value.ToDate = new Date(this.toDate.setDate(this.toDate.getDate() + 1));
      } else {
        value.ToDate = new Date(value.FromDate);
      }
      if (this.EmpType === 'Bajaj') {
        if (this.employeeInfo.length > 0) {
          this.enggInfoErr = false;
          value.Attachments = false;
          value.EngineerInformation = this.employeeInfo;
          this.disableSubmit = true;
          this._dashboardservice.AddHolidayWorking(value)
            .subscribe(
            (results: any) => {
              this.disableSubmit = false;
              this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
              this.showHolidayWorkingForm = false;
              this.onPendingGL();
            },
            error => {
              this.disableSubmit = false;
              this.errorMessage = <any>error;
              this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
        }
        else {
          this.disableSubmit = false;
          this.enggInfoErr = true;
        }
      }
      if (this.EmpType === 'Contract') {
        if (this.filesData.length > 0) {
          this.chooseFileErr = false;
          value.Attachments = this.AttachmentURL;
          this.disableSubmit = true;
          this._dashboardservice.uploadFile(value, this.filesData).then(
            (results: any) => {
              this.disableSubmit = false;
              this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results });
              this.showHolidayWorkingForm = false;
              this.onPendingGL();
            },
            (error: any) => {
              this.disableSubmit = false;
              this.errorMessage = <any>error;
              this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            })

          // this._dashboardservice.AddHolidayWorkingWithAttachment(value, this.filesData)
          //   .subscribe(
          //   (results: any) => {
          //     this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
          //     this.showHolidayWorkingForm = false;
          //   },
          //   error => {
          //     this.errorMessage = <any>error;
          //     this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
          //   });
        }
        else {
          this.disableSubmit = false;
          this.chooseFileErr = true;
        }

      }
    }
    else {
      this.disableSubmit = false;
      this.errorFlagForAdd = true;
    }
  }
  onCancelRequest(request: Holiday) {
    this._confirmationService.confirm({
      message: 'Are you sure that you want to close this request?',
      accept: () => {
        let holidayPayload = {
          'ID': request.ID,
          'Status': 'Cancelled',
          "Role": this.loggedInUserRole
        }
        //this.onOpenClick();
        this._dashboardservice.cancelHolidayRequest(holidayPayload)
          .subscribe(
          (results: any) => {
            this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
            this.onPendingGL();
          },
          error => {
            this.errorMessage = <any>error;
            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
          });
      }
    });
  }
  downloadFile(holiday: Holiday) {
    this.attachmentURL.FileName = holiday.AttachmentFiles[0].FileName;
    this.attachmentURL.ServerRelativeUrl = holiday.AttachmentFiles[0].ServerRelativeUrl;
    this.onDownloadFile();
  }
  onDownloadFile() {
    this._dashboardservice.getDownloadedFile(this.attachmentURL.ServerRelativeUrl)
      .subscribe(
      results => {
        this.binaryFileToDownload = <any>results;
        if (this.binaryFileToDownload) {
          this.Download(this.binaryFileToDownload, this.attachmentURL.ServerRelativeUrl, this.attachmentURL.FileName);
        } else { this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: 'File Not Found' }); }
      },
      error => this.errorMessage = <any>error);
  }
  Download(binaryResume: string, attachmentURL: string, FileName: string) {
    let extension;
    let fileName;
    if (FileName !== null) {
      extension = FileName.split('.')[1] ? FileName.split('.')[1] : 'HolidayWorkingExt';
      fileName = FileName.split('.')[0] ? FileName.split('.')[0] : 'HolidayWorkingFile';
    }
    //var link = document.createElement('a');
    //link.download = fileName;
    var byteCharacters = atob(binaryResume);
    var byteNumbers = new Array(byteCharacters.length);
    for (var i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    var byteArray = new Uint8Array(byteNumbers);

    switch (extension.toLowerCase()) {
      case 'pdf': var blob1 = new Blob([byteArray], { type: "application/pdf;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:application/pdf;charset=utf-8;base64,' + binaryResume;
        break;
      case 'xls': var blob1 = new Blob([byteArray], { type: "application/vnd.ms-excel;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:application/vnd.ms-excel;charset=utf-8;base64,' + binaryResume;
        break;
      case 'xlsx': var blob1 = new Blob([byteArray], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8;base64,' + binaryResume;
        break;
      case 'tif': var blob1 = new Blob([byteArray], { type: "image/tiff;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:image/tiff;charset=utf-8;base64,' + binaryResume;
        break;
      case 'tiff': var blob1 = new Blob([byteArray], { type: "image/tiff;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:image/tiff;charset=utf-8;base64,' + binaryResume;
        break;
      case 'gif': var blob1 = new Blob([byteArray], { type: "image/GIF;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:image/GIF;charset=utf-8;base64,' + binaryResume;
        break;
      case 'jpeg': var blob1 = new Blob([byteArray], { type: "image/jpeg;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:image/jpeg;charset=utf-8;base64,' + binaryResume;
        break;
      case 'jpg': var blob1 = new Blob([byteArray], { type: "image/jpeg;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:image/jpeg;charset=utf-8;base64,' + binaryResume;
        break;
      case 'png': var blob1 = new Blob([byteArray], { type: "image/png,charset=utf-8" });
        new saveAs(blob1, fileName + '.' + extension);
        //link.href = 'data:image/png;charset=utf-8;base64,' + binaryResume;
        break;
      case 'ppt': var blob1 = new Blob([byteArray], { type: "application/vnd.ms-powerpoint;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:application/vnd.ms-powerpoint;charset=utf-8;base64,' + binaryResume;
        break;
      case 'pptx': var blob1 = new Blob([byteArray], { type: "application/vnd.openxmlformats-officedocument.presentationml.presentation;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:application/vnd.openxmlformats-officedocument.presentationml.presentation;charset=utf-8;base64,' + binaryResume;
        break;
      case 'doc':
        var blob1 = new Blob([byteArray], { type: "application/msword;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:application/msword;charset=utf-8;base64,' + binaryResume;
        break;
      case 'docx':
        var blob1 = new Blob([byteArray], { type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document;charset=utf-8;base64" });
        window.navigator.msSaveBlob(blob1, fileName + '.' + extension);
        // link.href = 'data:application/vnd.openxmlformats-officedocument.wordprocessingml.document;charset=utf-8;base64,' + binaryResume;
        break;
      case 'zip': var blob1 = new Blob([byteArray], { type: "application/zip;charset=utf-8;base64" });
        new saveAs(blob1, fileName + '.' + extension)
        //link.href = 'data:application/zip;charset=utf-8;base64,' + binaryResume;
        break;
      default: //link.href = 'data:application/force-download;charset=utf-8;base64,' + binaryResume;
        break;
    }
    //document.body.appendChild(link);
    //link.click();
  }
  onApprove() {
    let value = {
      'ID': this.requestID,
      'Status': 'Approved',
      'Role': this.loggedInUserRole
    };
    this._dashboardservice.ApproveRejectHolidayWorking(value)
      .subscribe(
      (results: any) => {
        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
        this.showHolidayWorkingForm = false;
        this.onPendingGL();
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  onReject() {
    let value = {
      'ID': this.requestID,
      'Status': 'Rejected',
      'Role': this.loggedInUserRole
    };
    this._dashboardservice.ApproveRejectHolidayWorking(value)
      .subscribe(
      (results: any) => {
        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
        this.showHolidayWorkingForm = false;
        this.onPendingGL();
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  onCloseForm() {
    this.showHolidayWorkingForm = false;
    this.workingArea = '';
    this.natureOfWork = '';
    this.selectedCanteen = [];
    this.selectedUtility = [];
    this.EmpType = 'Bajaj';
    this.enggTkt.name = '';
    this.mobile = '';
    this.twoDays = false;
    this.errorFlagForAdd = false;
  }
  onCloseApproveRejectForm() {
    this.showApproveReject = false;
  }
  onDeleteEmpInfo(emp: any) {
    let index = this.employeeInfo.indexOf(emp);
    this.employeeInfo.splice(index, 1);
  }
  formatDate(date: any) {
    var d = new Date(date),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();
    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;

    return [month, day, year].join('/');
  }
}
