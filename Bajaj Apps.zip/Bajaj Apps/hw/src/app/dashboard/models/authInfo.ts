export class AuthInfo {
  constructor(
    public Grant_Type: string,
    public Password: string,
    public UserName: string
  ) {  }
}
