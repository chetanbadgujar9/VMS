export class Holiday {
    constructor(
        public ID: string,
        public FromDate: Date,
        public ToDate: Date,
        public WorkingArea: string,
        public TestEquipmentsNeeded: string,
        public NatureOfWork: string,
        public WorkingShift: string,
        public CanteenFacilityNeeded: any[],
        public UtilitiesNeeded: any[],
        public EngineerInformation: {
            EmployeeName: string,
            CompOffDate: Date,
            Mobile: string
        },
        public EnggTkt: string,
        public TwoDays: any,
        public Model: string,
        public RaisedBy: { "Name": string, "ID": string },
        public Attachments: boolean,
        public Status: string,
        public AttachmentFiles:any[]
    ) { }
}