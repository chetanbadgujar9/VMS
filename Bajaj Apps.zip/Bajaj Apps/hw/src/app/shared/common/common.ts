export class Common {

    maxlength250: any = 250;
    maxlength100: any = 100;
}