/* angular dependencies */
import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/finally';
import { Router } from '@angular/router';

/** Third party dependencies */
import { SpinnerService } from '../spinner/spinner.service';
import { Config } from '../config/config';
import { AuthHttp } from '../services/authHttp.service';
import { AuthInfo } from '../../dashboard/models/authInfo';

@Injectable()
export class CommonService {
    http: Http;
    constructor(http: Http,
        private authHttp: AuthHttp,
        private _spinnerService: SpinnerService,
        private router: Router) {
        this.http = http;
    }
    onTitleClick() {
        this.router.navigate(['/brand']);
    }
    //Get user auth token
    getAuthToken(credentials: AuthInfo) {
        let authenticateUrl = Config.GetURL('/api/Auth/Token');
        this._spinnerService.show();
        let headers = new Headers();
        let credentialString: string = 'grant_type=password&username=' + credentials.UserName + '&password=' + credentials.Password;
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let options = new RequestOptions({ headers: headers });
        return this.http.post(authenticateUrl, credentialString, options)
            .map((res: Response) => {
                this.setToken(res); //this.emitAuthEvent(true);
            })
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }

    //Get Logged In User Data
    getLoggedInUserDetails(username: any) {
        let url = Config.GetURL('/api/testrequest/BALRMSUGP/GetUGPDetailsByUserName?userName=' + username);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    //Get Admin Access
    getAdminAccess(username: any) {
        let url = Config.GetURL('/api/rms/farmadminusers/FarmAdminUsersByUserLoginName?userLoginName=' + username);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getShift() {
        let url = Config.GetURL('/api/holidayWorking/ShiftMaster/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    addShift(payload: any) {
        let url = Config.GetURL('/api/holidayWorking/ShiftMaster/Post');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    updateShift(payload: any) {
        let url = Config.GetURL('/api/testrequest/ShiftMaster/UpdateShiftMasterByID');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    deleteShift(value: any) {
        let url = Config.GetURL('/api/holidayWorking/ShiftMaster/DeleteEquipmentMasterByID/' + value.ID);
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getCanteenfacility() {
        let url = Config.GetURL('/api/holidayWorking/CanteenFacilityMaster/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    addCanteen(payload: any) {
        let url = Config.GetURL('/api/holidayWorking/CanteenFacilityMaster/Post');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    updateCanteen(payload: any) {
        let url = Config.GetURL('/api/holidayWorking/CanteenFacilityMaster/UpdateCanteenFacilityMasterByID');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    deleteCanteen(value: any) {
        let url = Config.GetURL('/api/holidayWorking/CanteenFacilityMaster/DeleteCanteenFacilityMasterByID/' + value.ID);
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getUtilityFacility() {
        let url = Config.GetURL('/api/holidayWorking/EquipmentMaster/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    addEquipment(payload: any) {
        let url = Config.GetURL('/api/holidayWorking/EquipmentMaster/Post');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    updateEquipment(payload: any) {
        let url = Config.GetURL('/api/holidayWorking/EquipmentMaster/UpdateEquipmentMasterByID');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    deleteEquipment(value: any) {
        let url = Config.GetURL('/api/holidayWorking/EquipmentMaster/DeleteEquipmentMasterByID/' + value.ID);
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getEmailList() {
        let url = Config.GetURL('/api/holidayWorking/EmailMaster/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    addEmail(payload: any) {
        let url = Config.GetURL('/api/holidayWorking/EmailMaster/Post');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    updateEmail(payload: any) {
        let url = Config.GetURL('/api/holidayWorking/EmailMaster/UpdateEmailMasterByID');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    deleteEmail(value: any) {
        let url = Config.GetURL('/api/holidayWorking/EmailMaster/DeleteEmailMasterByID/' + value.ID);
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getPlantHeadList() {
        let url = Config.GetURL('/api/holidayWorking/PlantHead/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    addPlanthead(payload: any) {
        let url = Config.GetURL('/api/holidayWorking/PlantHead/Post');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    updatePlanthead(payload: any) {
        let url = Config.GetURL('/api/holidayWorking/PlantHead/UpdatePlantHeadByID');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    deletePlanthead(value: any) {
        let url = Config.GetURL('/api/holidayWorking/PlantHead/DeletePlantHeadByID/' + value.ID);
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getEnggTicketNo(query: any) {
        let url = Config.GetURL('/api/holidayWorking/RndUsers/GetRndUsersByNameOrTicketNumber?name=' + query);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    //  To get Group master
    getSystemMaster() {
        let url = Config.GetURL('/api/TestRequest/GroupMaster/GetGroupNames');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getSystem() {
        let url = Config.GetURL('/api/testrequest/GroupMaster/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }

    // To get subSytems of Systems
    getSubSystem(system: any) {
        let url = Config.GetURL('/api/testrequest/GroupMaster/GetSubGroupByGroupName?groupName=' + system);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    //  To get Stage master
    getStageMaster() {
        let url = Config.GetURL('/api/testrequest/StageMaster/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }

    //  To get Test Type master
    getTestType() {
        let url = Config.GetURL('/api/testrequest/TestTypeMaster/GetTestTypes');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getTestTypeData() {
        let url = Config.GetURL('/api/testrequest/TestTypeMaster/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    //To get sub Type of types
    getSubTypeOfSubType(type: any) {
        let url = Config.GetURL('/api/testrequest/TestTypeMaster/GetTestSubTypeByTestType?testType=' + type);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    // To get Vehicle model
    getVehicleModel() {
        let url = Config.GetURL('/api/testrequest/VehicleModelMaster/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }

    // To get brand data
    getBrandData() {
        let url = Config.GetURL('/api/rms/BPM/GetBrandNames');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }

    // To get project data
    getProject(brand: any) {
        let url = Config.GetURL('/api/rms/BPM/GetProjectByBrandName?brandName=' + brand);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }

    // Users 
    getAssignToUsers(username: string) {
        let url = Config.GetURL('/api/ahead/UserInformationList/GetUserInformationListByName?userName=' + username);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }

    addBrand(value: any) {
        let url = Config.GetURL('/api/testrequest/BPM/Post');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    updateBrand(value: any) {
        let url = Config.GetURL('/api/testrequest/BPM/UpdateBrandProjectByID');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    deleteBrand(value: any) {
        //TO DO : Need to Update API
        let url = Config.GetURL('/api/testrequest/BPM/UpdateBrandProjectByID');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }

    addSystem(value: any) {
        let url = Config.GetURL('/api/testrequest/GroupMaster/Post');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    updateSystem(value: any) {
        let url = Config.GetURL('/api/testrequest/GroupMaster/UpdateGroupMasterByID');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    deleteSystem(value: any) {
        //TO DO : Need to Update API
        let url = Config.GetURL('/api/testrequest/GroupMaster/DeleteGroupMasterByID/' + value.ID);
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    addStage(value: any) {
        let url = Config.GetURL('/api/testrequest/StageMaster/Post');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    updateStage(value: any) {
        let url = Config.GetURL('/api/testrequest/StageMaster/UpdateStageMasterByID');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    deleteStage(value: any) {
        //TO DO : Need to Update API
        let url = Config.GetURL('/api/testrequest/StageMaster/DeleteStageMasterByID/' + value.ID);
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }

    addTestType(value: any) {
        let url = Config.GetURL('/api/testrequest/TestTypeMaster/Post');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    updateTestType(value: any) {
        let url = Config.GetURL('/api/testrequest/TestTypeMaster/UpdateTestTypeMasterByID');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    deleteTestType(value: any) {
        //TO DO : Need to Update API
        let url = Config.GetURL('/api/testrequest/TestTypeMaster/DeleteTestTypeMasterByID/' + value.ID);
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    addVehicle(value: any) {
        let url = Config.GetURL('/api/testrequest/VehicleModelMaster/Post');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    updateVehicle(value: any) {
        let url = Config.GetURL('/api/testrequest/VehicleModelMaster/UpdateStageMasterByID');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    deleteVehicle(value: any) {
        //TO DO : Need to Update API
        let url = Config.GetURL('/api/testrequest/VehicleModelMaster/DeleteVehicleModelMasterByID/' + value.ID);
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getMyData(username: any) {
        let url = Config.GetURL('/api/cashpurchase/RndUsers/GetRndUsersListByName?userName=' + username);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getRMSMenus() {
        let url = Config.GetURL('/api/CashPurchase/NavigationMaster/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    /**Set Token in localstorage */
    private setToken(res: Response) {
        if (res.status < 200 || res.status >= 300) {
            throw new Error('Bad response status: ' + res.status);
        }
        let body = res.json();
        sessionStorage.setItem('access_token', body.access_token);
        return body || {};
    }

    /**Success Handler */
    private extractData(res: Response) {
        if (res.status < 200 || res.status >= 300) {
            throw new Error('Bad response status: ' + res.status);
        }
        let body = res.json();
        return body || {};
    }

    /**Error Handler */
    private handleError(error: Response) {
        console.log(error);
        return Observable.throw(error.json().error || 'Server error');
    }

}
