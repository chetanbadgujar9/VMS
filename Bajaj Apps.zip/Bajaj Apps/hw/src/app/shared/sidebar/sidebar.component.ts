import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Config } from '../../shared/config/config';
import { MessageService } from '../services/message.service';
/**
 * This class represents the toolbar component.
 */
@Component({
  moduleId: module.id,
  selector: 'sd-sidebar',
  templateUrl: 'sidebar.component.html',
  styleUrls: ['sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  show: boolean = false;
  currentURL: string;
  loggedInUserName: string;
  hasAdminAccess: boolean = false;
  showRMS: boolean = true;
  rmsMenu: any = [];
  constructor(private router: Router, private _messageService: MessageService) { }
  ngOnInit() {
    this._messageService.getAdminAccess()
      .subscribe((value: any) => {
        this.hasAdminAccess = value;
      })
    this._messageService.getRMSMenu()
      .subscribe((value: any) => {
          this.rmsMenu = value;
          this.showRMS = false;
      });
    this.currentURL = sessionStorage.getItem('currentURL');
    this.loggedInUserName = sessionStorage.getItem('UserTitle');
  }
  check() {
    if (this.show) {
      this.show = false;
    } else {
      this.show = true;
    }
  }
  checkRMSMenu() {
    if (this.showRMS) {
      this.showRMS = false;
    } else {
      this.showRMS = true;
    }
  }
  onLogoClick() {
    window.location.href = Config.getLogoURL();
  }
  onTitleClick() {
    this.router.navigate(['/']);
  }
  onRoute(route: any) {
    this.show = false;
    this.router.navigate([route]);
  }
  onSignInDiffUser() {
    localStorage.clear();
    sessionStorage.clear();
    window.location.href = this.currentURL + '/_layouts/15/closeConnection.aspx?loginasanotheruser=true';
  }
  onSignOut() {
    localStorage.clear();
    sessionStorage.clear();
    window.location.href = this.currentURL + '/_layouts/15/signout.aspx';
  }
  onAboutMe() {
    this.router.navigate(['/aboutMe']);
  }
}

