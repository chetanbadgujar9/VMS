import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FromComponent } from './components/from/from.component';
import { BinIdComponent } from './components/binid/binid.component';
import { BrandComponent } from './components/brand/brand.component';
import { ProjectComponent } from './components/project/project.component';
import { GLComponent } from './components/GLApproval/GL.component';
import { RequestCancellationComponent } from './components/RequestCancellation/requestCancel.component';
import { RMSComponent } from './components/RMS/rms.component';
import { UGPComponent } from './components/UGP/ugp.component';
import { ItemComponent } from './components/item/item.component';
import { PlantComponent } from './components/Plant/plant.component';

@NgModule({
  imports: [
    RouterModule.forChild([
      { path: 'from', component: FromComponent },
      { path: 'binList', component: BinIdComponent },
      { path: 'project', component: ProjectComponent },
      { path: 'brand', component: BrandComponent },
      { path: 'GL', component: GLComponent },
      { path: 'requestCancellation', component: RequestCancellationComponent },
      { path: 'rms', component: RMSComponent },
      { path: 'ugp', component: UGPComponent },
      { path: 'item', component: ItemComponent },
      { path: 'plant', component: PlantComponent },
    ])
  ],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
