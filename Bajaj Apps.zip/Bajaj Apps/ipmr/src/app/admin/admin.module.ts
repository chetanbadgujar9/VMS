import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProjectComponent } from './components/project/project.component';
import { FromComponent } from './components/from/from.component';
import { BinIdComponent } from './components/binid/binid.component';
import { BrandComponent } from './components/brand/brand.component';
import { GLComponent } from './components/GLApproval/GL.component';
import { RequestCancellationComponent } from './components/RequestCancellation/requestCancel.component';
import { RMSComponent } from './components/RMS/rms.component';
import { UGPComponent } from './components/UGP/ugp.component';
import { ItemComponent } from './components/item/item.component';
import { PlantComponent } from './components/Plant/plant.component';
import { AdminRoutingModule } from './admin-routing.module';
import { BrowserModule } from '@angular/platform-browser';
import { SharedModule } from '../shared/shared.module';
import { CommonService } from '../shared/services/common.service';

@NgModule({
    imports: [CommonModule, AdminRoutingModule, SharedModule],
    declarations: [ProjectComponent, FromComponent, BinIdComponent, BrandComponent, GLComponent, RequestCancellationComponent, RMSComponent, UGPComponent, ItemComponent, PlantComponent],
    exports: [ProjectComponent, FromComponent, BinIdComponent, BrandComponent, GLComponent, RequestCancellationComponent, RMSComponent, UGPComponent, ItemComponent, PlantComponent],
    providers: [CommonService]
})
export class AdminModule { }
