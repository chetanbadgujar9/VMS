import { Component, OnInit, NgModule, trigger, transition, style, animate, state, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { MessageService } from '../../../shared/services/message.service';
import { CommonService } from '../../../shared/services/common.service';
import { ConfirmationService } from 'primeng/primeng';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SelectItem } from 'primeng/primeng';
import { DashboardService } from '../../../dashboard/services/dashboard.service';
import { IPMR } from '../../../dashboard/models/IPMRModel';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-gl',
    templateUrl: 'GL.component.html',
    styleUrls: ['GL.component.css'],
    providers: [ConfirmationService]
})
export class GLComponent implements OnInit {
    IPMRData: any[];
    errorMessage: string;
    showVehicleForm: boolean = false;
    VehicleForm: FormGroup;
    Id: any = '';
    errorFlag: boolean = false;
    display: boolean = false;
    requestID: any;
    @Output() dashboardFlag = new EventEmitter();
    constructor(private _messageService: MessageService,
        private _commonService: CommonService,
        private _confirmationService: ConfirmationService,
        private formBuilder: FormBuilder,
        private _dashboardService: DashboardService) {
    }
    ngOnInit() {
        this._messageService.AddDashboardFlag(false);
        this.getGLPendingRequests_Admin();
    }
    getGLPendingRequests_Admin() {
        this.IPMRData = [];
        this._dashboardService.getGLPendingRequests_Admin()
            .subscribe(
            (results: any) => {
                if (results.length > 0) {
                    this.IPMRData = results;
                }
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onApproveRequest(request: IPMR) {
        //let payload = { 'ID': request.ID, 'RequestID': request.RequestID, 'Title': request.Title, 'RequestBy': request.RequestBy, 'GLApproval': 'Approved', 'GLComments': 'Approved By Admin' };
        request.GLApproval = 'Approved';
        request.Comments = '';
        request.Group = '';
        request.Project = '';
        request.Purpose = '';
        request.RequiredByDate = '';
        request.Status = '';
        request.Title = '';
        this._dashboardService.approveRejectRequest_Admin(request)
        this._dashboardService.approveRejectRequest_Admin(request)
            .subscribe(
            (results: any) => {
                this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                this.getGLPendingRequests_Admin();
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onRejectRequest(request: IPMR) {
        //let payload = { 'ID': request.ID, 'RequestID': request.RequestID, 'Title': request.Title, 'RequestBy': request.RequestBy, 'GLApproval': 'Rejected', 'GLComments': 'Approved By Admin' };
        request.GLApproval = 'Rejected';
        this._dashboardService.approveRejectRequest_Admin(request)
            .subscribe(
            (results: any) => {
                this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                this.getGLPendingRequests_Admin();
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
}
