import { Component, OnInit, NgModule, trigger, transition, style, animate, state, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { MessageService } from '../../../shared/services/message.service';
import { CommonService } from '../../../shared/services/common.service';
import { ConfirmationService } from 'primeng/primeng';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DashboardService } from '../../../dashboard/services/dashboard.service';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-system',
    templateUrl: 'requestCancel.component.html',
    styleUrls: ['requestCancel.component.css'],
    providers: [ConfirmationService]
})
export class RequestCancellationComponent implements OnInit {
    cashpurchaseData: any[];
    errorMessage: string;
    showVehicleForm: boolean = false;
    VehicleForm: FormGroup;
    Id: any = '';
    errorFlag: boolean = false;
    display: boolean = false;
    requestID: any;
    @Output() dashboardFlag = new EventEmitter();
    constructor(private _messageService: MessageService,
        private _commonService: CommonService,
        private _confirmationService: ConfirmationService,
        private formBuilder: FormBuilder,
        private _dashboardService: DashboardService) {
    }
    ngOnInit() {
        this._messageService.AddDashboardFlag(false);
        //this.getAllCancellationRequests();
    }
    //getAllCancellationRequests() {
    //    this.cashpurchaseData = [];
    //    this._dashboardService.getAllCancellationRequests()
    //        .subscribe(
    //        (results: any) => {
    //            if (results.length > 0) {
    //                this.cashpurchaseData = results;
    //            }
    //        },
    //        error => {
    //            this.errorMessage = <any>error;
    //            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
    //        });
    //}
    //onCancelCashPurchaseRequest(request: Cashmodel) {
    //    this.display = true;
    //    this.requestID = request.ID;
    //}
    //CancelRequest() {
    //    this._dashboardService.cancelCashPurchaseRequest(this.requestID)
    //        .subscribe(
    //        (results: any) => {
    //            this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
    //            this.getAllCancellationRequests();
    //            this.display = false;
    //        },
    //        error => {
    //            this.errorMessage = <any>error;
    //            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
    //        });
    //}
}
