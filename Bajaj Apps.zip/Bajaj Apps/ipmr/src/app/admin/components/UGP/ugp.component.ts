import { Component, OnInit, NgModule, trigger, transition, style, animate, state, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { MessageService } from '../../../shared/services/message.service';
import { CommonService } from '../../../shared/services/common.service';
import { ConfirmationService } from 'primeng/primeng';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SelectItem } from 'primeng/primeng';
import { Canteen } from '../../model/canteen';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-ugp',
    templateUrl: 'ugp.component.html',
    styleUrls: ['ugp.component.css'],
    providers: [ConfirmationService]
})
export class UGPComponent implements OnInit {
    UGPUserData: any[];
    BrandData: any[];
    UGPTitleData: any[];
    UGPEmailData: any[];
    UGPDomainData: any[];
    errorMessage: string;
    showAddCategoryFrom: boolean = false;
    AddUGPForm: FormGroup;
    Id: any = '';
    errorFlagForAddForm: boolean = false;
    maxlength: any = 100;
    title: any;
    characterleft: any;
    display: boolean = false;
    ID: any;
    pasteData: any = {};
    @Output() dashboardFlag = new EventEmitter();
    constructor(private _messageService: MessageService,
        private _commonService: CommonService,
        private _confirmationService: ConfirmationService,
        private formBuilder: FormBuilder) {
    }
    ngOnInit() {
        this.characterleft = this.maxlength;
        this._messageService.AddDashboardFlag(false);
        this.setForm();
        this.getBrands();
        this.getUGPUserList();
    }
    setForm() {
        this.AddUGPForm = this.formBuilder.group({
            UserLookup: [, [Validators.required]],
            Designation: ['', [Validators.required]],
            emailid: [, [Validators.required]],
            Brand: [, [Validators.required]],
            Function: ['', [Validators.required]],
            GL: ['', [Validators.required]],
            GLdomainid: [, [Validators.required]],
            GLMail: ['', [Validators.required]],
            Grade: ['', [Validators.required]],
            Group: ['', [Validators.required]],
            L1: ['', [Validators.required]],
            Level: ['', [Validators.required]],
            Role: ['', [Validators.required]],
            Role2: ['', [Validators.required]],
            TCUGP: ['', [Validators.required]],
            TicketNo: ['', [Validators.required]],
            domainid: [, [Validators.required]]
        });
    }
    onAddUser() {
        this.Id = '';
        this.characterleft = 100;
        this.title = '';
        this.setForm();

        this.showAddCategoryFrom = true;
        this.errorFlagForAddForm = false;
    }
    getBrands() {
        this.BrandData = [];
        this._commonService.getBrandsByNames()
            .subscribe(
            (results: any[]) => {
                results.forEach(element => {
                    let brands = { 'label': element.Title, 'value': element.Title };
                    this.BrandData.push(brands);
                });
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });

            });
    }
    onCancelForm() {
        this.errorFlagForAddForm = false;
        this.characterleft = 100;
        this.showAddCategoryFrom = false;
    }
    getUGPUserList() {
        this._commonService.getUGPUserList()
            .subscribe(
            (results: any) => {
                this.UGPUserData = results;
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });

            });
    }
    countChars(Title: any) {
        if (this.maxlength >= Title.length) {
            this.characterleft = (this.maxlength) - (Title.length);
        } else {
            this.title = Title.substr(0, Title.length - 1);
        }
    }
    searchUser(event: any) {
        let query = event.query;
        this._commonService.getUsermasterById(query)
            .subscribe(
            (results: any) => {
                this.UGPTitleData = results;
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });

            });
    }
    searchEmail(event: any) {
        let query = event.query;
        this._commonService.getEmailmasterById(query)
            .subscribe(
            (results: any) => {
                this.UGPEmailData = results;
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });

            });
    }
    searchDomain(event: any) {
        let query = event.query;
        this._commonService.getDomainmasterById(query)
            .subscribe(
            (results: any) => {
                this.UGPDomainData = results;
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });

            });
    }
    onEdit(request: any) {
        this.showAddCategoryFrom = true;
        this.Id = request.ID;
        this.title = request.Title;
        let brand = request.Brand ? request.Brand.split(', ') : [];
        this.AddUGPForm.setValue({
            UserLookup: request.UserLookup,
            Designation: request.Designation,
            emailid: request.emailid,
            Brand: brand,
            Function: request.Function,
            GL: request.GL,
            GLdomainid: request.GLdomainid,
            GLMail: request.GLMail,
            Grade: request.Grade,
            Group: request.Group,
            L1: request.L1.Name,
            Level: request.Level,
            Role: request.Role,
            Role2: request.Role2,
            TCUGP: request.tcugp,
            TicketNo: request.TicketNo,
            domainid: request.domainid
        });
    }
    onCopy(request: any) {
        this.pasteData = request;
    }
    onPaste() {

        if (Object.keys(this.pasteData).length !== 0) {
            let brand = this.pasteData.Brand ? this.pasteData.Brand.split(', ') : [];
            this.AddUGPForm.setValue({
                UserLookup: [],
                Designation: this.pasteData.Designation ? this.pasteData.Designation : '',
                emailid: [],
                Brand: brand,
                Function: this.pasteData.Function ? this.pasteData.Function : '',
                GL: this.pasteData.GL ? this.pasteData.GL : '',
                GLdomainid: this.pasteData.GLdomainid,
                GLMail: this.pasteData.GLMail ? this.pasteData.GLMail : '',
                Grade: this.pasteData.Grade ? this.pasteData.Grade : '',
                Group: this.pasteData.Group ? this.pasteData.Group : '',
                L1: this.pasteData.L1,
                Level: this.pasteData.Level ? this.pasteData.Level : '',
                Role: this.pasteData.Role ? this.pasteData.Role : '',
                Role2: this.pasteData.Role2 ? this.pasteData.Role2 : '',
                TCUGP: this.pasteData.tcugp ? this.pasteData.tcugp : '',
                TicketNo: '',
                domainid: this.pasteData.domainid
            });
        }
    }
    onSubmit({ value, valid }: { value: any, valid: boolean }) {
        if (valid) {
            // console.log(value);
            value.Title = value.UserLookup ? value.UserLookup.Name : '';
            value.EditUgp = null;
            let brand = '';
            value.Brand.forEach(element => {
                brand = brand + ', ' + element;
            });
            value.Brand = brand.substr(1);
            if (this.Id === '') {
                this._commonService.addUserDetails(value)
                    .subscribe(
                    (results: any) => {
                        this.Id = '';
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getUGPUserList();
                        this.showAddCategoryFrom = false;
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
            if (this.Id !== '') {
                value.ID = this.Id;
                this._commonService.updateUserDetails(value)
                    .subscribe(
                    (results: any) => {
                        this.Id = '';
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getUGPUserList();
                        this.showAddCategoryFrom = false;
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }

        } else {
            this.errorFlagForAddForm = true;
        }

    }
    onDelete(category: any) {
        this.ID = category.ID;
        this.display = true;
    }
    // CancelRequest() {
    //     this._commonService.deleteCategory(this.ID)
    //         .subscribe(
    //         (results: any) => {
    //             this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
    //             this.display = false;
    //             this.getUGPUserList();
    //         },
    //         error => {
    //             this.errorMessage = <any>error;
    //             this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
    //         });
    // }
}
