import { Component, OnInit, NgModule, trigger, transition, style, animate, state, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { MessageService } from '../../../shared/services/message.service';
import { CommonService } from '../../../shared/services/common.service';
import { ConfirmationService } from 'primeng/primeng';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SelectItem } from 'primeng/primeng';
import { Canteen } from '../../model/canteen';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-binid',
    templateUrl: 'binid.component.html',
    styleUrls: ['binid.component.css'],
    providers: [ConfirmationService]
})
export class BinIdComponent implements OnInit {
    BINData: any[];
    errorMessage: string;
    showBinForm: boolean = false;
    AddBinListForm: FormGroup;
    Id: any = '';
    errorFlagForAddForm: boolean = false;
    maxlength: any = 100;
    binid: any;
    binno: any;
    characterleft: any;
    characterleft1: any;
    display: boolean = false;
    ID: any;
    @Output() dashboardFlag = new EventEmitter();
    constructor(private _messageService: MessageService,
        private _commonService: CommonService,
        private _confirmationService: ConfirmationService,
        private formBuilder: FormBuilder) {
    }
    ngOnInit() {
        this.characterleft = this.characterleft1 = this.maxlength;
        this._messageService.AddDashboardFlag(false);
        this.setForm();
        this.getBinList();
    }
    setForm() {
        this.AddBinListForm = this.formBuilder.group({
            Title: ['', [Validators.required]],
            BINNO: ['', [Validators.required]]
        });
    }
    onAddBINList() {
        this.Id = '';
        this.characterleft = 100;
        this.characterleft1 = 100;
        this.binid = '';
        this.binno = '';
        this.setForm();
        this.showBinForm = true;
        this.errorFlagForAddForm = false;
    }
    onCancelForm() {
        this.errorFlagForAddForm = false;
        this.showBinForm = false;
    }
    getBinList() {
        this._commonService.getBinList()
            .subscribe(
            (results: any) => {
                this.BINData = results;
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });

            });
    }
    countChars(Title: any) {
        if (this.maxlength >= Title.length) {
            this.characterleft = (this.maxlength) - (Title.length);
        } else {
            this.binid = Title.substr(0, Title.length - 1);
        }
    }
    countChars1(Title: any) {
        if (this.maxlength >= Title.length) {
            this.characterleft1 = (this.maxlength) - (Title.length);
        } else {
            this.binno = Title.substr(0, Title.length - 1);
        }
    }
    onEdit(category: any) {
        this.showBinForm = true;
        this.Id = category.ID;
        this.binno = category.BINNO;
        this.binid = category.Title;
        this.AddBinListForm.setValue({
            Title: category.Title,
            BINNO: category.BINNO
        });
    }
    onSubmit({ value, valid }: { value: any, valid: boolean }) {
        if (valid) {
            value.Title = value.Title ? value.Title.replace(/'/g, "\\'").trim() : '';
            value.BINNO = value.BINNO ? value.BINNO.replace(/'/g, "\\'").trim() : '';
            value.Category = value.Title;
            if (this.Id === '') {
                this._commonService.addBINList(value)
                    .subscribe(
                    (results: any) => {
                        this.Id = '';
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getBinList();
                        this.showBinForm = false;
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
            if (this.Id !== '') {
                value.ID = this.Id;
                this._commonService.updateBINList(value)
                    .subscribe(
                    (results: any) => {
                        this.Id = '';
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getBinList();
                        this.showBinForm = false;
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }

        } else {
            this.errorFlagForAddForm = true;
        }

    }
    onDelete(category: any) {
        this.ID = category.ID;
        this.display = true;
    }
    CancelRequest() {
        this._commonService.deleteBINLISt(this.ID)
            .subscribe(
            (results: any) => {
                this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                this.display = false;
                this.getBinList();
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
}
