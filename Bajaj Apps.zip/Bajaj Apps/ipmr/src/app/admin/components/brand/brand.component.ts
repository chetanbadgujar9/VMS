import { Component, OnInit, NgModule, trigger, transition, style, animate, state } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { MessageService } from '../../../shared/services/message.service';
import { CommonService } from '../../../shared/services/common.service';
import { ConfirmationService } from 'primeng/primeng';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SelectItem } from 'primeng/primeng';
import { Brand } from '../../model/brand';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-brand',
    templateUrl: 'brand.component.html',
    styleUrls: ['brand.component.css'],
    providers: [ConfirmationService]
})
export class BrandComponent implements OnInit {
    brandData: any[];
    errorMessage: string;
    display: boolean = false;
    showBrandForm: boolean = false;
    BrandForm: FormGroup;
    Id: any = '';
    errorFlag: boolean = false;
    maxlength: any = 100;
    project: any;
    brand: any;
    characterleft: any;
    characterleftProj: any;
    req: any;
    maxlengthProj: any = 100;
    constructor(private _messageService: MessageService,
        private _commonService: CommonService,
        private _confirmationService: ConfirmationService,
        private formBuilder: FormBuilder) {
    }
    ngOnInit() {
        this.characterleft = this.maxlength;
        this.characterleftProj = this.maxlengthProj;
        this._messageService.AddDashboardFlag(false);
        this.setForm();
        this.getBrandList();
    }
    setForm() {
        this.BrandForm = this.formBuilder.group({
            Title: ['', [Validators.required]],
            Project: ['', [Validators.required]]
        });
    }
    countChars(brand: any) {
        if (this.maxlength >= brand.length) {
            this.characterleft = (this.maxlength) - (brand.length);
        }
        else {
            this.brand = brand.substr(0, brand.length - 1);
        }
    }
    countCharsForProj(project: any) {
        if (this.maxlengthProj >= project.length) {
            this.characterleftProj = (this.maxlengthProj) - (project.length);
        }
        else {
            this.project = project.substr(0, project.length - 1);
        }
    }
    onAddBrand() {
        this.brand = '';
        this.project = '';
        this.setForm();
        this.showBrandForm = true;
    }
    onCancel() {
        this.BrandForm.setValue({
            Project: '',
            Title: ''
        })
        this.showBrandForm = false;
    }
    getBrandList() {
        this._commonService.getBrandNames()
            .subscribe(
            (results: any) => {
                this.brandData = results;
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onEdit(brand: Brand) {
        this.showBrandForm = true;
        this.Id = brand.ID;
        this.BrandForm.setValue({
            Project: brand.Project,
            Title: brand.Title
        })
    }
    onDeleteBrand(request: Brand) {
        this.display = true;
        this.req = request.ID;
    }
    onDelete() {
        this._commonService.deleteBrand(this.req)
        .subscribe(
        (results: any) => {
            this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
            this.getBrandList();
        },
        error => {
            this.errorMessage = <any>error;
            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
        });
    }
    onSubmit({ value, valid }: { value: Brand, valid: boolean }) {
        if (valid) {
            value.Title = value.Title ? value.Title.replace(/'/g, "\\'").trim() : '';
            value.Project = value.Project ? value.Project.replace(/'/g, "\\'").trim() : '';
            if (this.Id === '') {
                this._commonService.addBrand(value)
                    .subscribe(
                    (results: any) => {
                        this.Id = '';
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getBrandList();
                        this.showBrandForm = false;
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
            if (this.Id !== '') {
                value.ID = this.Id;
                this._commonService.updateBrand(value)
                    .subscribe(
                    (results: any) => {
                        this.Id = '';
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getBrandList();
                        this.showBrandForm = false;
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }

        } else {
            this.errorFlag = true;
        }

    }
}
