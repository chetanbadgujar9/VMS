import { Component, OnInit, NgModule, trigger, transition, style, animate, state, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { MessageService } from '../../../shared/services/message.service';
import { CommonService } from '../../../shared/services/common.service';
import { ConfirmationService } from 'primeng/primeng';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SelectItem } from 'primeng/primeng';
import { Canteen } from '../../model/canteen';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-from',
    templateUrl: 'from.component.html',
    styleUrls: ['from.component.css'],
    providers: [ConfirmationService]
})
export class FromComponent implements OnInit {
    FromData: any[];
    errorMessage: string;
    showAddFromForm: boolean = false;
    AddFromForm: FormGroup;
    Id: any = '';
    errorFlagForAddForm: boolean = false;
    maxlength: any = 100;
    title: any;
    characterleft: any;
    display: boolean = false;
    ID: any;
    @Output() dashboardFlag = new EventEmitter();
    constructor(private _messageService: MessageService,
        private _commonService: CommonService,
        private _confirmationService: ConfirmationService,
        private formBuilder: FormBuilder) {
    }
    ngOnInit() {
        this.characterleft = this.maxlength;
        this._messageService.AddDashboardFlag(false);
        this.setForm();
        this.getFromList();
    }
    setForm() {
        this.AddFromForm = this.formBuilder.group({
            Title: ['', [Validators.required]]
        });
    }
    onAddFrom() {
        this.Id = '';
        this.characterleft = 100;
        this.title = '';
        this.setForm();
        this.showAddFromForm = true;
        this.errorFlagForAddForm = false;
    }
    onCancelForm() {
        this.errorFlagForAddForm = false;
        this.characterleft = 100;
        this.showAddFromForm = false;
    }
    getFromList() {
        this._commonService.getFromList()
            .subscribe(
            (results: any) => {
                this.FromData = results;
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });

            });
    }
    countChars(Title: any) {
        if (this.maxlength >= Title.length) {
            this.characterleft = (this.maxlength) - (Title.length);
        } else {
            this.title = Title.substr(0, Title.length - 1);
        }
    }
    onEdit(category: any) {
        this.showAddFromForm = true;
        this.Id = category.ID;
        this.title = category.Title;
        this.AddFromForm.setValue({
            Title: category.Title,
        });
    }
    onSubmit({ value, valid }: { value: any, valid: boolean }) {
        if (valid) {
            value.Title = value.Title ? value.Title.replace(/'/g, "\\'").trim() : '';
            value.Category = value.Title;
            if (this.Id === '') {
                this._commonService.addFrom(value)
                    .subscribe(
                    (results: any) => {
                        this.Id = '';
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getFromList();
                        this.showAddFromForm = false;
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
            if (this.Id !== '') {
                value.ID = this.Id;
                this._commonService.updateFrom(value)
                    .subscribe(
                    (results: any) => {
                        this.Id = '';
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getFromList();
                        this.showAddFromForm = false;
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }

        } else {
            this.errorFlagForAddForm = true;
        }

    }
    onDelete(category: any) {
        this.ID = category.ID;
        this.display = true;
    }
    CancelRequest() {
        this._commonService.deleteFrom(this.ID)
            .subscribe(
            (results: any) => {
                this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                this.display = false;
                this.getFromList();
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
}
