import { Component, OnInit, NgModule, trigger, transition, style, animate, state, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { MessageService } from '../../../shared/services/message.service';
import { CommonService } from '../../../shared/services/common.service';
import { ConfirmationService } from 'primeng/primeng';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SelectItem } from 'primeng/primeng';
import { Canteen } from '../../model/canteen';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-item',
    templateUrl: 'item.component.html',
    styleUrls: ['item.component.css'],
    providers: [ConfirmationService]
})
export class ItemComponent implements OnInit {
    itemData: any[];
    errorMessage: string;
    showAddItemFrom: boolean = false;
    AddItemForm: FormGroup;
    Id: any = '';
    errorFlagForAddForm: boolean = false;
    maxlength: any = 100;
    title: any = '';
    characterleft: any;
    display: boolean = false;
    showExist: boolean = false;
    showNotExist: boolean = false;
    ID: any;
    @Output() dashboardFlag = new EventEmitter();
    constructor(private _messageService: MessageService,
        private _commonService: CommonService,
        private _confirmationService: ConfirmationService,
        private formBuilder: FormBuilder) {
    }
    ngOnInit() {
        this.characterleft = this.maxlength;
        this._messageService.AddDashboardFlag(false);
        this.setForm();
        // this.getItemList();
    }
    setForm() {
        this.AddItemForm = this.formBuilder.group({
            Title: ['', [Validators.required]],
            Description: ['', [Validators.required]],
        });
    }
    onSearch(value: any) {
        if (this.title !== '') {
            this.title = this.title ? this.title.replace(/'/g, "\\'").trim() : '';
            this._commonService.validateItem(this.title)
                .subscribe(
                (results: any) => {
                    if (Object.keys(results).length > 0) {
                        this.showExist = true;
                        this.showNotExist = false;
                    } else {
                        this.showExist = false;
                        this.showNotExist = true;
                        if (value !== undefined) {
                            this._commonService.addItem(value)
                                .subscribe(
                                (results: any) => {
                                    this.Id = '';
                                    this._messageService.addMessage({
                                        severity: 'success',
                                        summary: 'Success Message', detail: results.Message
                                    });
                                    this.getItemList();
                                    this.title = '';
                                    this.showAddItemFrom = false;
                                    this.showExist = false;
                                    this.showNotExist = false;
                                    this.errorFlagForAddForm = false;
                                    this.characterleft = 100;
                                    this.AddItemForm.setValue({
                                        Title: '',
                                        Description: ''
                                    });
                                },
                                error => {
                                    this.errorMessage = <any>error;
                                    this._messageService.addMessage({
                                        severity: 'error',
                                        summary: 'Error Message', detail: this.errorMessage
                                    });
                                });
                        }
                    }
                },
                error => {
                    this.errorMessage = <any>error;
                    this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });

                });
        }
    }
    onAddCategory() {
        this.Id = '';
        this.characterleft = 100;
        this.title = '';
        this.setForm();
        this.showAddItemFrom = true;
        this.errorFlagForAddForm = false;
    }
    onCancelForm() {
        this.errorFlagForAddForm = false;
        this.characterleft = 100;
        this.showAddItemFrom = false;
    }
    getItemList() {
        this._commonService.getItemList()
            .subscribe(
            (results: any) => {
                this.itemData = results;
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });

            });
    }
    countChars(Title: any) {
        if (this.maxlength >= Title.length) {
            this.characterleft = (this.maxlength) - (Title.length);
        } else {
            this.title = Title.substr(0, Title.length - 1);
        }
    }
    onEdit(category: any) {
        this.showAddItemFrom = true;
        this.Id = category.ID;
        this.title = category.Title;
        this.AddItemForm.setValue({
            Title: category.Title,
        });
    }
    onSubmit({ value, valid }: { value: any, valid: boolean }) {
        if (valid) {
            this.onSearch(value);
        } else {
            this.errorFlagForAddForm = true;
        }

    }
}
