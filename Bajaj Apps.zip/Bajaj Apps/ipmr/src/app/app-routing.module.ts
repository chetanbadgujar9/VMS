import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/index';
import { AboutComponent } from './aboutMe/components/aboutme.component';
import {
  BinIdComponent
  , BrandComponent
  , FromComponent
  , GLComponent
  , ItemComponent
  , PlantComponent
  , ProjectComponent
  , RequestCancellationComponent
  , RMSComponent
  , UGPComponent
} from './admin/index';
import { UnAuthorizedComponent } from './unAuthorized/components/unauthorized.component';
import { DatewiseReportComponent } from './datewiseReport/components/datewiseReport.component';
import { GLDashboardComponent } from './glDashboard/components/glDahboard.component';
import { MaterialComponent } from './materialReceived/components/material.component';
import { SearchRMSComponent } from './searchRMS/components/searchRMS.component';
import { UpdateRMSComponent } from './updateRMSPart/components/updateRMS.componen';

const routes: Routes = [
  { path: 'project', component: ProjectComponent },
  { path: 'from', component: FromComponent },
  { path: 'binList', component: BinIdComponent },
  { path: 'plant', component: PlantComponent },
  { path: 'brand', component: BrandComponent },
  { path: 'rms', component: RMSComponent },
  { path: 'ugp', component: UGPComponent },
  { path: 'item', component: ItemComponent },
  { path: 'GL', component: GLComponent },
  { path: 'searchRMSItem', component: SearchRMSComponent },
  { path: 'datewiseReport', component: DatewiseReportComponent },
  { path: 'updateRMSPart', component: UpdateRMSComponent },
  { path: 'aboutMe', component: AboutComponent },
  { path: 'unauthorized/:id', component: UnAuthorizedComponent },
  { path: 'GLDashboard', component: GLDashboardComponent },
  { path: 'materialReceived', component: MaterialComponent },
  { path: 'dashboard', component: DashboardComponent, pathMatch: 'full' },
  { path: 'dashboard', component: DashboardComponent, pathMatch: 'full' },
  { path: '**', component: DashboardComponent },
  { path: 'IPMR/dist', redirectTo: 'dashboard', pathMatch: 'full' }
];

@NgModule({
  imports: [
    RouterModule.forRoot(
      routes
    )
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }

