import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { SharedModule } from './shared/shared.module';
import { APP_BASE_HREF, CommonModule, LocationStrategy, HashLocationStrategy } from '@angular/common';
import { AppRoutingModule } from './app-routing.module';
import { DashboardComponent, DashboardService } from './dashboard/index';
// import { DashboardComponent } from './dashboard/components/dashboard.component';
import { DashboardModule } from './dashboard/dashboard.module';
import { UnauthorizedModule } from './unAuthorized/unauthorized.module';
import { DatewiseReportModule } from './datewiseReport/datewiseReport.module';
import { GLDashboardModule } from './glDashboard/glDashboard.module';
import { MaterialModule } from './materialReceived/material.module';
import { SearchRMSModule } from './searchRMS/searchRMS.module';
import { AboutMeModule } from './aboutMe/aboutme.module';
import { UpdateRMSModule } from './updateRMSPart/updateRMS.module';
import { AdminModule } from './admin/admin.module';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';

import {
  CalendarModule
  , DataTableModule
  , GrowlModule
  , TooltipModule
  , MultiSelectModule
  , ConfirmDialogModule
  , AutoCompleteModule
} from 'primeng/primeng';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
  declarations: [
    AppComponent
    // , DashboardComponent
  ],
  imports: [
    BrowserAnimationsModule,
    HttpClientModule
    , DashboardModule
    , HttpModule
    , AppRoutingModule
    , BrowserModule, CalendarModule, DataTableModule
    , GrowlModule
    , TooltipModule
    , ConfirmDialogModule
    , MultiSelectModule
    , AutoCompleteModule
    , CommonModule
    , AdminModule
    , UnauthorizedModule
    , AboutMeModule
    , DatewiseReportModule
    , GLDashboardModule
    , MaterialModule
    , SearchRMSModule
    , UpdateRMSModule
    , SharedModule.forRoot()
  ],
  exports: [HttpClientModule, DashboardModule],
  providers: [{
    provide: APP_BASE_HREF,
    useValue: ''
  }, DashboardService],
  bootstrap: [AppComponent]
})
export class AppModule { }
