import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MessageService } from '../../shared/services/message.service';
import { CommonService } from '../../shared/services/common.service';
import { DashboardService } from '../services/dashboard.service';
import { ConfirmationService } from 'primeng/primeng';
import { AuthInfo } from '../models/authInfo';
import { IPMR } from '../models/IPMRModel';
import { User } from '../models/loginUser';
import { Searchmodel } from '../models/searchmodel';
import { StoreModel } from '../models/storeModel';
import { Jsonp } from '@angular/http/src/http';
import { validateConfig } from '@angular/router/src/config';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
  moduleId: module.id,
  selector: 'sd-dashboard',
  templateUrl: 'dashboard.component.html',
  styleUrls: ['dashboard.component.css'],
  providers: [ConfirmationService]
})
export class DashboardComponent implements OnInit {
  cars: any[] = [];
  IPMRData: any = [];
  StoreItemData: any = [];
  itemInfo: any = [];
  projectData: any = [];
  rmsMenu: any[];
  plant: any[];
  rmsStatus: any[];
  BINID: any[];
  BINNO: any[];
  counterData: any = {};
  viewData: any[];

  prDate = new Date();
  /** Model Data */
  StoreData: StoreModel; // StoreModel = new StoreModel();

  /** Form Variables */
  searchForm: FormGroup;
  AddRequestForm: FormGroup;
  ApproveRejectForm: FormGroup;
  StoreForm: FormGroup;

  /** Flags Variables */
  display: boolean = false;
  showIPMRForm: boolean = false;
  showSearchRequestForm: boolean = false;
  errorFlagForAddForm: boolean = false;
  showQuantityNeededErr: boolean = false;
  showItemNameErr: boolean = false;
  showItemIdErr: boolean = false;
  showApproveRejectForm: boolean = false;
  showStoreForm: boolean = false;
  itemInfoErr: boolean = false;
  errorFlagForSearchForm: boolean = false;
  onSearchClickToShowAction: boolean = false;
  errorFlagForApproveRejectForm: boolean = false;
  ApproveButton: boolean = false;
  RejectButton: boolean = false;
  errorFlagForStoreForm: boolean = false;
  showCreateButton: boolean = false;
  showSelectButton: boolean = false;
  showViewForm: boolean = false;
  characterleft: any;
  maxlength: any = 250;

  /** Model Variables */
  model: AuthInfo;
  loggedInUserData: User = new User();

  /**General Variables */
  loggedInUser: string;
  loginName: string = '';
  loggedInUserRole: any = {};
  loggedInUserGroup: string;
  itemid: string = '';
  itemname: string = '';
  quantityrequired: string = '';
  requesttitle: any;
  errorMessage: any;
  minDate: Date;
  status: any;
  headingColor: any;
  requestID: any;
  ID: any;
  requiredByDate: any;
  StoreAllCounter: any;

  constructor(private formBuilder: FormBuilder, private _messageService: MessageService, private _dashboardService: DashboardService,
    private _commonService: CommonService, private _router: Router, private _confirmationService: ConfirmationService) {
    // this.StoreData = StoreModel;
    this.model = new AuthInfo('password', '', '');
  }
  ngOnInit() {
    this.plant = [];
    this.characterleft = this.maxlength;
    /**For local site */
    // this.loginName = 'cnt_Shaileshs';
    // this.loggedInUser = 'Shailesh sangekap';

    // this.loginName = 'TCCTEST6';
    // this.loggedInUser = 'TCCTEST6';

    /** For Production */
    this.loginName = sessionStorage.getItem('Username') ? sessionStorage.getItem('Username').split('\\')[1] : '';
    this.loggedInUser = sessionStorage.getItem('UserTitle') ? sessionStorage.getItem('UserTitle') : '';
    const someDate = new Date();
    const numberOfDaysToAdd = 3;
    const threeDaysLater = someDate.setDate(someDate.getDate() + numberOfDaysToAdd);
    this.requiredByDate = new Date(threeDaysLater);
    this.setSearchForm();
    this.setApproveRejectForm();
    this.setStoreForm();
    if (sessionStorage.getItem('access_token') === null) {
      this.getAuthToken();
    } else {
      this.loggedInUserData = JSON.parse(sessionStorage.getItem('loggedInUserData'));
      this.loggedInUserGroup = this.loggedInUserData ? this.loggedInUserData.Group : '';
      this.getRMSMenus();
      this.getAdminAccess(this.loginName);
      if (this.loggedInUserData !== null) {
        this.getCurrentUserGroup();
      } else {
        this._router.navigate(['/unauthorized', 'You are not Authorized to access this site due to UGP mapping does not exist. '
          + 'Please contact Ahead portal support team.']);
      }

    }
    // this.setAddForm();
    this.rmsStatus = [{ 'label': 'Open', 'value': 'Open' },
    { 'label': 'PR Raised', 'value': 'PR Raised' },
    { 'label': 'Request Dropped', 'value': 'Request Dropped' },
    { 'label': 'Material Unavailable', 'value': 'Material Unavailable' },
    { 'label': 'Material Available in R&D', 'value': 'Material Available in R&D' }];
  }

  /** Get Auth Token */
  getAuthToken() {
    this.model.UserName = this.loginName;
    this.model.Password = '';
    this._commonService.getAuthToken(this.model)
      .subscribe(
      (results: any) => {
        this.getRMSMenus();
        this.getLoggedInUserDetails();
        // this.getCurrentUserGroup();
        this.getAdminAccess(this.loginName);
      },
      error => {
        this.errorMessage = <any>error;
        this._router.navigate(['/unauthorized',
          'You are not Authorized to access this site due to UGP mapping does not exist. Please contact Ahead portal support team.']);
      });
  }
  getLoggedInUserDetails() {
    this._commonService.getLoggedInUserDetails(this.loggedInUser)
      .subscribe(
      (results: any) => {
        if (Object.keys(results).length !== 0) {
          this.loggedInUserData = results;
          // this.loggedInUserRole = results.Role2;
          this.loggedInUserGroup = this.loggedInUserData.Group;
          // this._messageService.AddUserRole(this.loggedInUserRole);
          // sessionStorage.setItem('loggedInUserName', JSON.stringify(results.UserLookup));
          sessionStorage.setItem('loggedInUserData', JSON.stringify(results));
          this.getCurrentUserGroup();
          // this.onPending();
        } else {
          this._router.navigate(['/unauthorized',
            'You are not Authorized to access this site due to UGP mapping does not exist. Please contact Ahead portal support team.']);
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getCurrentUserGroup() {
    const userID = this.loggedInUserData.UserLookup ? this.loggedInUserData.UserLookup.ID : '';
    this._commonService.getCurrentUserGroup(userID)
      .subscribe(
      (results: any) => {
        if (Object.keys(results).length !== 0) {
          this.loggedInUserRole = results.GroupNames ? results.GroupNames : '';
          this._messageService.AddUserRole(JSON.stringify(this.loggedInUserRole));
          this._messageService.AddUserGroup(JSON.stringify(this.loggedInUserData.Group));
          sessionStorage.setItem('loggedInUserName', JSON.stringify(results.CurrentUser));
          if (this.loggedInUserRole.indexOf('GL') >= 0) {
            this._router.navigate(['/GLDashboard']);
          } else if (this.loggedInUserRole.indexOf('SM') >= 0 && this.loggedInUserRole.indexOf('Stores') >= 0) {
            this.showSelectButton = true;
            this.onOpenClick();
            this.getStoreCounters();
          } else if (this.loggedInUserRole.indexOf('SM') >= 0) {
            this._router.navigate(['/materialReceived']);
          } else if (this.loggedInUserRole.indexOf('Stores') >= 0) {
            this.showSelectButton = true;
            this.onOpenClick();
            this.getStoreCounters();
          } else if (this.loggedInUserRole.indexOf('Viewers') >= 0) {
            this.showCreateButton = true;
            this.getCounters();
            this.onOpenClick();
          }
        } else {
          this._router.navigate(['/unauthorized',
            'You are not Authorized to access this site due to UGP mapping does not exist. Please contact Ahead portal support team.']);
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  /** Get Admin Access*/
  getAdminAccess(username: any) {
    this._commonService.getAdminAccess(username)
      .subscribe((results: any) => {
        if (Object.keys(results).length !== 0) {
          this._messageService.AddAdminAccess(true);
        }
      });
  }
  getRMSMenus() {
    this._commonService.getRMSMenus()
      .subscribe(
      (results: any) => {
        this.rmsMenu = results;
        this._messageService.AddRMSMenu(this.rmsMenu);
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }

  /** Get Status wise requests */
  getCounters() {
    this._dashboardService.getCounters()
      .subscribe(
      (results: any) => {
        this.counterData = results;
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getStoreCounters() {
    this._dashboardService.getStoreCounters()
      .subscribe(
      (results: any) => {
        this.counterData = results;
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getStoreTotalCount(status: any) {
    this._dashboardService.getStoreTotalCount(status)
      .subscribe(
      (results: any) => {
        this.StoreAllCounter = results;
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  onOpenClick() {
    this.showApproveRejectForm = false;
    this.showIPMRForm = false;
    this.showSearchRequestForm = false;
    this.showStoreForm = false;
    this.showViewForm = false;
    this.status = 'Open';
    this.headingColor = '#e53935';
    if (this.loggedInUserRole.indexOf('Stores') >= 0) {
      this.getStoresRequests(this.status);
      this.getStoreTotalCount(this.status);
    } else if (this.loggedInUserRole.indexOf('Viewers') >= 0) {
      this.getRequestersRequests(this.status);
    }
  }
  onPRraisedClick() {
    this.showApproveRejectForm = false;
    this.showIPMRForm = false;
    this.showSearchRequestForm = false;
    this.showStoreForm = false;
    this.showViewForm = false;
    this.status = 'PR Raised';
    this.headingColor = '#43a047';
    if (this.loggedInUserRole.indexOf('Stores') >= 0) {
      this.getStoresRequests(this.status);
      this.getStoreTotalCount(this.status);
    } else if (this.loggedInUserRole.indexOf('Viewers') >= 0) {
      this.getRequestersRequests(this.status);
    }
  }
  onMaterialReceivedClick() {
    this.showApproveRejectForm = false;
    this.showIPMRForm = false;
    this.showSearchRequestForm = false;
    this.showStoreForm = false;
    this.showViewForm = false;
    this.status = 'Material Received';
    this.headingColor = '#00acc1';
    if (this.loggedInUserRole.indexOf('Stores') >= 0) {
      this.getStoresRequests(this.status);
      this.getStoreTotalCount(this.status);
    } else if (this.loggedInUserRole.indexOf('Viewers') >= 0) {
      this.getRequestersRequests(this.status);
    }
  }
  onMaterialPartiallyReceivedClick() {
    this.showApproveRejectForm = false;
    this.showIPMRForm = false;
    this.showSearchRequestForm = false;
    this.showStoreForm = false;
    this.showViewForm = false;
    this.status = 'Material Partially Received';
    this.headingColor = '#fb8c00';
    if (this.loggedInUserRole.indexOf('Stores') >= 0) {
      this.getStoresRequests(this.status);
      this.getStoreTotalCount(this.status);
    } else if (this.loggedInUserRole.indexOf('Viewers') >= 0) {
      this.getRequestersRequests(this.status);
    }
  }
  onMaterialUnavailableClick() {
    this.showApproveRejectForm = false;
    this.showIPMRForm = false;
    this.showSearchRequestForm = false;
    this.showStoreForm = false;
    this.showViewForm = false;
    this.status = 'Material Unavailable';
    this.headingColor = '#d81b60';
    if (this.loggedInUserRole.indexOf('Stores') >= 0) {
      this.getStoresRequests(this.status);
      this.getStoreTotalCount(this.status);
    } else if (this.loggedInUserRole.indexOf('Viewers') >= 0) {
      this.getRequestersRequests(this.status);
    }
  }
  onRequestDroppedClick() {
    this.showApproveRejectForm = false;
    this.showIPMRForm = false;
    this.showSearchRequestForm = false;
    this.showStoreForm = false;
    this.showViewForm = false;
    this.status = 'Request Dropped';
    this.headingColor = '#8e24aa';
    if (this.loggedInUserRole.indexOf('Stores') >= 0) {
      this.getStoresRequests(this.status);
      this.getStoreTotalCount(this.status);
    } else if (this.loggedInUserRole.indexOf('Viewers') >= 0) {
      this.getRequestersRequests(this.status);
    }
  }
  onRequestRejected() {
    this.showApproveRejectForm = false;
    this.showIPMRForm = false;
    this.showSearchRequestForm = false;
    this.showStoreForm = false;
    this.showViewForm = false;
    this.status = 'Request Rejected';
    this.headingColor = '#999999';
    if (this.loggedInUserRole.indexOf('Stores') >= 0) {
      this.getStoresRequests(this.status);
      this.getStoreTotalCount(this.status);
    } else if (this.loggedInUserRole.indexOf('Viewers') >= 0) {
      this.getRequestersRequests(this.status);
    }
  }

  // this function is for requester to get data
  getRequestersRequests(status: any) {
    this.IPMRData = [];
    this._dashboardService.getRequestersRequests(status)
      .subscribe(
      (results: any) => {
        if (results.length > 0) {
          this.IPMRData = results;
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }

  // this function is for stores to get data
  getStoresRequests(status: any) {
    this.IPMRData = [];
    this._dashboardService.getStoresRequests(status)
      .subscribe(
      (results: any) => {
        if (results.length > 0) {
          this.IPMRData = results;
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  viewAllStoreRequest() {
    this.IPMRData = [];
    this._dashboardService.viewAllStoreRequest(this.status)
      .subscribe(
      (results: any) => {
        if (results.length > 0) {
          this.IPMRData = results;
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }

  /**General Functions */
  addItem() {
    let count;
    count = this.itemInfo.length + 1;
    let itemObj = {};
    if (this.itemid !== '') {
      this.showItemIdErr = false;
      if (this.itemname !== '') {
        this.showItemNameErr = false;
        if (this.quantityrequired !== '') {
          this.showQuantityNeededErr = false;
          let checkDuplicate;
          this.itemInfo.forEach(element => {
            if (element.Item_ID === this.itemid) {
              checkDuplicate = true;
              document.getElementById('duplicate').innerHTML = 'Item already exist in the list';
              document.getElementById('duplicate').className = 'required';
              document.getElementById('duplicate').style.display = 'block';
            }
          });
          if (!checkDuplicate) {
            document.getElementById('duplicate').style.display = 'none';
            itemObj = { 'id': count, 'Item_ID': this.itemid, 'Item_Name': this.itemname, 'QTY_Required': this.quantityrequired };
            this.itemInfo.push(itemObj);
            this.itemid = '';
            this.itemname = '';
            this.quantityrequired = '';
            this.itemInfoErr = false;
          }
        } else {
          this.showQuantityNeededErr = true;
        }
      } else {
        this.showItemNameErr = true;
      }
    } else {
      this.showItemIdErr = true;
    }
  }
  countChars(model: any) {
    if (this.maxlength >= model.length) {
      this.characterleft = (this.maxlength) - (model.length);
    } else {
      this.requesttitle = model.substr(0, model.length - 1);
    }
  }
  onDeleteItemInfo(item: any) {
    const index = this.itemInfo.indexOf(item);
    this.itemInfo.splice(index, 1);
  }
  validateItemID(itemId: any) {
    if (itemId !== '') {
      this._dashboardService.validateItemId(itemId)
        .subscribe((results: any) => {
          if (Object.keys(results).length !== 0) {
            this.itemname = results;
            document.getElementById('duplicate').style.display = 'none';
          } else {
            this._dashboardService.validateItemIdInRMS(itemId)
              .subscribe((results: any) => {
                if (Object.keys(results).length !== 0) {
                  this.itemname = results.Description;
                  document.getElementById('duplicate').style.display = 'none';
                } else {
                  this.itemname = '';
                  document.getElementById('duplicate').innerHTML = 'Invalid Item Id';
                  document.getElementById('duplicate').className = 'required';
                  document.getElementById('duplicate').style.display = 'block';
                }
              });
          }
        });
    }
  }
  validateItemIDLength(num: any) {
    const maxlength = 10;
    if (maxlength >= num.toString().length) {

    } else {
      this.itemid = num.toString().substr(0, num.toString().length - 1);
    }
    this.itemid = this.itemid.toUpperCase();

  }
  getBINID() {
    this._commonService.getBINID()
      .subscribe(
      (results: any) => {
        if (results.length > 0) {
          this.BINID = results;
          // let add = { 'label': '--Select--', 'value': 'Select' };
          // this.BINID.unshift(add);
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  onBINIDClick(binid: any) {
    this._commonService.getBINNO(binid)
      .subscribe(
      (results: any) => {
        if (results.length > 0) {
          this.BINNO = results;
        }
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  getPlantList() {
    this.plant = [];
    this._commonService.getPlantList()
      .subscribe(
      (results: any[]) => {
        results.forEach(element => {
          const plant = { 'label': element.Title, 'value': element.Title };
          this.plant.push(plant);
        });
        // this.plant = results;
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });

      });
  }
  disabledPR(items: any) {
    if (items.Item_Status === 'Material Unavailable' || items.Item_Status === 'Request Dropped') {
      return true;
    } else {
      return false;
    }
  }
  disabledPRDate(items: any) {
    if (items.Item_Status.toUpperCase() === 'Material Unavailable'.toUpperCase()
      || items.Item_Status.toUpperCase() === 'Request Dropped'.toUpperCase()
      || items.Item_Status.toUpperCase() === 'Material Available in R&D'.toUpperCase()) {
      items.PRDate = '';
      return true;
    } else {
      return false;
    }
  }
  onRMSstatus(status: any, id: any) {
    if (status === 'Request Dropped') {
      for (let i = 0; i < this.StoreData.Items.length; i++) {
        if ((this.StoreData.Items[i].Item_Status === 'Open') || (this.StoreData.Items[i].Item_Status === 'PR Raised')
          || (this.StoreData.Items[i].Item_Status === 'Material Unavailable') || (this.StoreData.Items[i].Item_Status === 'Request Dropped')
          || (this.StoreData.Items[i].Item_Status === 'Material Available in R&D')) {
          this.StoreData.Items[i].Item_Status = 'Request Dropped';
          document.getElementById('pr' + i).setAttribute('disabled', 'true');
          this.StoreData.Items[i].PR_Number = '';
        }
      }
    } else if (status === 'Material Unavailable') {
      document.getElementById('pr' + id).setAttribute('disabled', 'true');
      this.StoreData.Items[id].PR_Number = '';
    } else {
      document.getElementById('pr' + id).setAttribute('disabled', 'false');
    }
    // else{
    //   this.StoreData.Items.forEach(element => {
    //     element.Item_Status = '--select--';
    //   });
    // }
  }
  checkPR(prno: any) {
    if (prno.Item_Status === 'Material Unavailable') {
      return true;
    } else {
      return false;
    }
  }
  onPRNumber(prno: any, id: any) {
    if (prno !== '' && prno !== null) {
      if (prno.length === 8) {
        this.StoreData.Items[id].Item_Status = 'PR Raised';
      } else {
        this.StoreData.Items[id].Item_Status = 'Material Available in R&D';
      }
    } else {
      this.StoreData.Items[id].Item_Status = 'Open';
    }
  }
  /** Set Forms */
  setAddForm() {
    const someDate = new Date();
    const numberOfDaysToAdd = 3;
    const threeDaysLater = someDate.setDate(someDate.getDate() + numberOfDaysToAdd);
    this.minDate = new Date(threeDaysLater);
    this.AddRequestForm = this.formBuilder.group({
      Title: ['', [Validators.required]],
      Group: [this.loggedInUserGroup],
      Project: ['', [Validators.required]],
      RequestBy: [this.loggedInUser],
      RequiredByDate: [new Date(threeDaysLater)],
      Purpose: ['', [Validators.required]],
      Comments: ['', [Validators.required]],
      ItemID: [''],
      ItemName: [''],
      QuantityRequired: [''],

    });
  }
  onCreateRequest() {
    this.setAddForm();
    this.showIPMRForm = true;
    this.showSearchRequestForm = false;
    this.onSearchClickToShowAction = false;
    this.showViewForm = false;
    this.itemInfo = [];
    this.characterleft = 250;
    this.requesttitle = '';
    this.itemid = this.itemname = this.quantityrequired = '';
    this.getProjectMaster();
  }
  onSearch() {
    this.showSearchRequestForm = true;
    this.showStoreForm = false;
    this.showViewForm = false;
    this.onSearchClickToShowAction = false;
    this.showIPMRForm = false;
    this.setSearchForm();
  }
  setSearchForm() {
    this.searchForm = this.formBuilder.group({
      // fieldName: ['Item ID', [Validators.required]],
      RequestID: ['', [Validators.required]]
    });
  }
  setApproveRejectForm() {
    this.ApproveRejectForm = this.formBuilder.group({
      Title: [''],
      Group: [''],
      Project: [''],
      RequestBy: [''],
      RequiredByDate: [''],
      Purpose: [''],
      Comments: [''],
      GLComments: ['', [Validators.required]]
    });
  }
  setStoreForm() {
    this.StoreForm = this.formBuilder.group({
      Title: [''],
      Group: [''],
      Project: [''],
      RequestBy: [''],
      RequiredByDate: [''],
      Purpose: [''],
      Comments: [''],
      RequestStatus: ['Open', [Validators.required]]
    });
  }
  /** Get master data */
  getProjectMaster() {
    this._commonService.getProjectMaster()
      .subscribe(
      (results: any) => {
        this.projectData = results;
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  onViewRequest(request: IPMR) {
    this.showApproveRejectForm = false;
    this.showIPMRForm = false;
    this.showSearchRequestForm = false;
    this.showStoreForm = false;
    this.showViewForm = false;
    this._dashboardService.getStoreRequestByID(request.ID)
      .subscribe(
      (results: any) => {
        this.showViewForm = true;
        this.viewData = results;
        // console.log('view', this.viewData);
      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  onSelectRequest(request: IPMR) {
    this.getBINID();
    this.getPlantList();
    this.errorFlagForApproveRejectForm = false;
    this.showIPMRForm = false;
    this.showSearchRequestForm = false;
    this.onSearchClickToShowAction = false;
    this.showViewForm = false;
    this.requestID = request.RequestID;
    this.ID = request.ID;
    this._dashboardService.getStoreRequestByID(request.ID)
      .subscribe(
      (results: StoreModel) => {
        this.showStoreForm = true;
        if (Object.keys(results).length !== 0) {
          this.StoreData = results;
          this.StoreData.Items.forEach(element => {
            element.PRDate = element.PRDate === null ? new Date() : new Date(element.PRDate);
          });
        }

      },
      error => {
        this.errorMessage = <any>error;
        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
      });
  }
  /**Submit Actions */
  onSubmitRequest({ value, valid }: { value: IPMR, valid: boolean }) {
    if (valid) {
      if (this.itemInfo.length > 0) {
        this.itemInfo.forEach(element => {
          element.Item_ID = element.Item_ID.replace(/'/g, '\\\'').trim();
          element.Item_Name = element.Item_Name.replace(/'/g, '\\\'').trim();
        });
        this.itemInfoErr = false;
        const month = new Date(this.requiredByDate).getMonth() + 1;
        value.Items = this.itemInfo;
        value.RequiredByDate = new Date(this.requiredByDate).getDate() + '/' + month + '/' + new Date(this.requiredByDate).getFullYear();
        value.Title = value.Title ? value.Title.replace(/'/g, '\\\'').trim() : '';
        value.Comments = value.Comments ? value.Comments.replace(/'/g, '\\\'').trim() : '';
        value.Purpose = value.Purpose ? value.Purpose.replace(/'/g, '\\\'').trim() : '';
        this._dashboardService.AddIPMRRequest(value)
          .subscribe(
          (results: any) => {
            this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
            this.showIPMRForm = false;
            this.getCounters();
            this.onOpenClick();
          },
          error => {
            this.errorMessage = <any>error;
            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
          });
      } else {
        this.itemInfoErr = true;
      }
    } else {
      this.errorFlagForAddForm = true;
    }
  }
  onSubmitSearch({ value, valid }: { value: any, valid: boolean }) {
    if (valid) {
      this.IPMRData = [];
      this.errorFlagForSearchForm = false;
      this.onSearchClickToShowAction = true;
      value.RequestID = value.RequestID ? value.RequestID.trim() : '';
      this._dashboardService.getSearchResult(value)
        .subscribe(
        (results: any) => {
          this.IPMRData = [results];
          this.status = results.Status;
          switch (this.status) {
            case 'Open': this.headingColor = '#e53935';
              break;
            case 'PR Raised': this.headingColor = '#43a047';
              break;
            case 'Material Received': this.headingColor = '#00acc1';
              break;
            case 'Material Partially Received': this.headingColor = '#fb8c00';
              break;
            case 'Material Unavailable': this.headingColor = '#d81b60';
              break;
            case 'Request Dropped': this.headingColor = '#8e24aa';
              break;
            case 'Request Rejected': this.headingColor = '#999999';
              break;
          }
          if ((this.loggedInUserRole.indexOf('SM') >= 0 && this.loggedInUserRole.indexOf('Stores') >= 0)
            || (this.loggedInUserRole.indexOf('Stores') >= 0)) {
            if (this.IPMRData[0].GLApproval === 'Approved') {
              this.showSelectButton = true;
            } else {
              this.showSelectButton = false;
            }
          }
        },
        error => {
          this.errorMessage = <any>error;
          this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
        });

    } else {
      this.errorFlagForSearchForm = true;
    }
  }
  onApproveRejectRequest({ value, valid }: { value: IPMR, valid: boolean }) {
    if (valid) {

    } else {
      this.errorFlagForApproveRejectForm = true;
    }
  }
  onStoreRequest() {
    if (this.StoreData.Status !== '') {
      let itemCheck = false;
      for (let index = 0; index < this.StoreData.Items.length; index++) {
        // if (this.StoreData.Items[index].Item_Status === 'Material Received' && this.StoreData.Items[index].QTY_Received
        // !== this.StoreData.Items[index].QTY_Required) {
        //   itemCheck = true;
        //   var divElement = document.getElementById('checkItem');
        //   divElement.innerHTML = 'Received Quantity should be equal to Required Quantity at row ' + (index + 1);
        //   divElement.className = "required";
        //   divElement.style.display = 'block';
        //   divElement.style.marginTop = "10px";
        //   break;
        // }
        // if (this.StoreData.Items[index].Item_Status === 'Material Partially Received'
        // && this.StoreData.Items[index].QTY_Received <= this.StoreData.Items[index].QTY_Required) {
        //   itemCheck = true;
        //   var divElement = document.getElementById('checkItem');
        //   divElement.innerHTML = 'Received Quantity should be less than Required Quantity at row ' + (index + 1);
        //   divElement.className = "required";
        //   divElement.style.display = 'block';
        //   divElement.style.marginTop = "10px";
        //   break;
        // }
        // if ((this.StoreData.Items[index].Item_Status === 'Open' || this.StoreData.Items[index].Item_Status === 'PR Raised'
        // || this.StoreData.Items[index].Item_Status === 'Request Dropped'
        // || this.StoreData.Items[index].Item_Status === 'Request Rejected'
        // || this.StoreData.Items[index].Item_Status === 'Material Unavailable'
        // || this.StoreData.Items[index].Item_Status === 'Material Available in R&D')
        //   && (this.StoreData.Items[index].QTY_Received !== null)) {
        //   if (this.StoreData.Items[index].QTY_Received !== "") {
        //     itemCheck = true;
        //     var divElement = document.getElementById('checkItem');
        //     divElement.innerHTML = 'Do not enter value for Received Quantity at row ' + (index + 1);
        //     divElement.className = "required";
        //     divElement.style.display = 'block';
        //     divElement.style.marginTop = "10px";
        //     break;
        //   }
        // }
        if ((this.StoreData.Items[index].Item_Status === 'PR Raised' && this.StoreData.Items[index].PR_Number === null)
          || (this.StoreData.Items[index].Item_Status === 'PR Raised' && this.StoreData.Items[index].PR_Number === '')
          || (this.StoreData.Items[index].Item_Status === 'PR Raised' && this.StoreData.Items[index].PRDate === null)) {
          itemCheck = true;
          const divElement = document.getElementById('checkItem');
          divElement.innerHTML = 'Please Enter PR Number and PR Date at row ' + (index + 1);
          divElement.className = 'required';
          divElement.style.display = 'block';
          divElement.style.marginTop = '10px';
          break;
        }
        // if ((this.StoreData.Items[index].Item_Status === 'Material Partially Received' && this.StoreData.Items[index].Bin_Id === null)
        // || (this.StoreData.Items[index].Item_Status === 'Material Partially Received' && this.StoreData.Items[index].Bin_No === null)
        //   || (this.StoreData.Items[index].Item_Status === 'Material Partially Received' && this.StoreData.Items[index].Bin_Id === "")
        // || (this.StoreData.Items[index].Item_Status === 'Material Partially Received' && this.StoreData.Items[index].Bin_No === "")) {
        //   itemCheck = true;
        //   var divElement = document.getElementById('checkItem');
        //   divElement.innerHTML = 'Please Select BIN ID and BIN NO at row ' + (index + 1);
        //   divElement.className = "required";
        //   divElement.style.display = 'block';
        //   divElement.style.marginTop = "10px";
        //   break;
        // }
        // if ((this.StoreData.Items[index].Item_Status === 'Material Received' && this.StoreData.Items[index].Bin_Id === null)
        // || (this.StoreData.Items[index].Item_Status === 'Material Received' && this.StoreData.Items[index].Bin_No === null)
        //   || (this.StoreData.Items[index].Item_Status === 'Material Received' && this.StoreData.Items[index].Bin_Id === "")
        // || (this.StoreData.Items[index].Item_Status === 'Material Received' && this.StoreData.Items[index].Bin_No === "")) {
        //   itemCheck = true;
        //   var divElement = document.getElementById('checkItem');
        //   divElement.innerHTML = 'Please Select BIN ID and BIN NO at row ' + (index + 1);
        //   divElement.className = "required";
        //   divElement.style.display = 'block';
        //   divElement.style.marginTop = "10px";
        //   break;
        // }
        // tslint:disable-next-line:max-line-length
        // if ((this.StoreData.Items[index].Item_Status === 'Open' || this.StoreData.Items[index].Item_Status === 'PR Raised' || this.StoreData.Items[index].Item_Status === 'Request Dropped' || this.StoreData.Items[index].Item_Status === 'Request Rejected'
        // tslint:disable-next-line:max-line-length
        //   || this.StoreData.Items[index].Item_Status === 'Material Unavailable' || this.StoreData.Items[index].Item_Status === 'Material Available in R&D') && (this.StoreData.Items[index].Bin_Id !== null)) {
        //   itemCheck = true;
        //   var divElement = document.getElementById('checkItem');
        //   divElement.innerHTML = 'Please dont Select BIN ID and BIN NO for this RMS status at row ' + (index + 1);
        //   divElement.className = "required";
        //   divElement.style.display = 'block';
        //   divElement.style.marginTop = "10px";
        //   break;
        // }
        // tslint:disable-next-line:max-line-length
        // if ((this.StoreData.Items[index].Item_Status === 'Open' || this.StoreData.Items[index].Item_Status === 'PR Raised' || this.StoreData.Items[index].Item_Status === 'Request Dropped' || this.StoreData.Items[index].Item_Status === 'Request Rejected'
        //   || this.StoreData.Items[index].Item_Status === 'Material Unavailable' || this.StoreData.Items[index].Item_Status === 'Material Available in R&D') && (this.StoreData.Items[index].Bin_No !== null)) {
        //   itemCheck = true;
        //   var divElement = document.getElementById('checkItem');
        //   divElement.innerHTML = 'Please dont Select BIN ID and BIN NO for this RMS status at row ' + (index + 1);
        //   divElement.className = "required";
        //   divElement.style.display = 'block';
        //   divElement.style.marginTop = "10px";
        //   break;
        // }
        if (this.StoreData.Items[index].Item_Status === 'Open') {
          itemCheck = true;
          const divElement = document.getElementById('checkItem');
          divElement.innerHTML = 'RMS status should not be Open at row ' + (index + 1);
          divElement.className = 'required';
          divElement.style.display = 'block';
          divElement.style.marginTop = '10px';
          break;
        }
        if (this.StoreData.Items[index].Item_Status === 'Material Unavailable' && this.StoreData.Items[index].PR_Number !== '') {
          if (this.StoreData.Items[index].Item_Status === 'Material Unavailable' && this.StoreData.Items[index].PR_Number !== null
            || this.StoreData.Items[index].PRDate !== null) {
            itemCheck = true;
            const divElement = document.getElementById('checkItem');
            divElement.innerHTML = 'Please Do Not Select PR Number and PR Date at row ' + (index + 1);
            divElement.className = 'required';
            divElement.style.display = 'block';
            divElement.style.marginTop = '10px';
            break;
          }
        }
        if ((this.StoreData.Items[index].Item_Status === 'Material Available in R&D' && this.StoreData.Items[index].PR_Number === '')
          || (this.StoreData.Items[index].Item_Status === 'Material Available in R&D' && this.StoreData.Items[index].PR_Number === null)
          // || (this.StoreData.Items[index].Item_Status === 'Material Available in R&D' && this.StoreData.Items[index].PRDate === '')
        ) {
          itemCheck = true;
          const divElement = document.getElementById('checkItem');
          divElement.innerHTML = 'Please enter location in PR Number field at row ' + (index + 1);
          divElement.className = 'required';
          divElement.style.display = 'block';
          divElement.style.marginTop = '10px';
          break;
        }
      }
      if (!itemCheck) {
        const divElement = document.getElementById('checkItem');
        divElement.style.display = 'none';
        this.StoreData.ID = this.ID;

        this.StoreData.Title = this.StoreData.Title ? this.StoreData.Title.replace(/'/g, '\\\'').trim() : '';
        this.StoreData.Comments = this.StoreData.Comments ? this.StoreData.Comments.replace(/'/g, '\\\'').trim() : '';
        this.StoreData.Purpose = this.StoreData.Purpose ? this.StoreData.Purpose.replace(/'/g, '\\\'').trim() : '';
        this._dashboardService.UpdateStoreData(this.StoreData)
          .subscribe(
          (results: any) => {
            this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
            this.showStoreForm = false;
            switch (this.status) {
              case 'Open': this.onOpenClick();
                break;
              case 'PR Raised': this.onPRraisedClick();
                break;
              case 'Material Received': this.onMaterialReceivedClick();
                break;
              case 'Material Partially Received': this.onMaterialPartiallyReceivedClick();
                break;
              case 'Request Dropped': this.onRequestDroppedClick();
                break;
              case 'Request Rejected': this.onRequestRejected();
                break;
            }
            this.getStoreCounters();
          },
          error => {
            this.errorMessage = <any>error;
            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
          });
      }
    } else {
      this.errorFlagForStoreForm = true;
    }
  }
  onCancelForm() {
    this.showIPMRForm = false;
  }
  onCloseSearchForm() {
    this.showSearchRequestForm = false;
    this.errorFlagForSearchForm = false;
  }
  onCancelApproveRejectForm() {
    this.showApproveRejectForm = false;
  }
  onCancelStoreForm() {
    this.showStoreForm = false;
  }
  onCloseView() {
    this.showViewForm = false;
  }
  onRequiredByDate(event: any) {
    this.requiredByDate = event;
  }
}
