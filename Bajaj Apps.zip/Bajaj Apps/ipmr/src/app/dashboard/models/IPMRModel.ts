export class IPMR {
    constructor(
        public ID: any,
        public RequestID:any,
        public Title: string,
        public Group: string,
        public Project: string,
        public RequestBy: string,
        public ItemID: string,
        public ItemName: any,
        public Purpose: string,
        public Comments: string,
        public QuantityRequired: string,
        public RequiredByDate: string,
        public GLComments: string,
        public RequestStatus: string,
        public Status: string,
        public GLApproval: string,
        public Items: [
            {
                Item_ID: string,
                Item_Name: string,
                QTY_Required: string
            }
        ]
    ) { }
}
