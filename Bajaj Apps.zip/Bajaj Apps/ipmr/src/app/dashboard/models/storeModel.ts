export class StoreModel {
    constructor(
        public ID: any,
        public RequestID: any,
        public Title: string,
        public Group: string,
        public Project: string,
        public RequestBy: string,
        public ItemID: string,
        public ItemName: any,
        public Purpose: string,
        public Comments: string,
        public QuantityRequired: string,
        public RequiredByDate: Date,
        public GLComments: string,
        public RequestStatus: string,
        public Status: string,
        public Items: [
            {
                ID: string,
                Bin_Id: string,
                Bin_No: string,
                GR_Number: string,
                Item_ID: string,
                Item_Name: string,
                Item_Status: string,
                PR_Number: string,
                PRDate: Date,
                Plant: string,
                QTY_Received: string,
                QTY_Required: string,
                Request_ID: string,
                Status: string,
            }
        ]
    ) { }
}
