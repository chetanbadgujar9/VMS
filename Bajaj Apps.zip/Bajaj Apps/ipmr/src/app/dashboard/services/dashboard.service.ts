/* angular dependencies */
import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/finally';
/** Third party dependencies */
import { AuthHttp } from '../../shared/services/authHttp.service';
import { Config } from '../../shared/config/config';
import { IPMR } from '../models/IPMRModel';
import { SpinnerService } from '../../shared/spinner/spinner.service';

@Injectable()
export class DashboardService {
    progress: any;
    progressObserver: any;
    constructor(private http: Http,
        private authHttp: AuthHttp,
        private _spinnerService: SpinnerService) {
    }

    getMyTestData() {
        let url = Config.GetURL('/Register/getHeight');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    validateItemId(id: any) {
        let url = Config.GetURL('/api/IMPR/TeamCenter/GetPartDescriptionByPartNumber?partNumber=' + id);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    validateItemIdInRMS(id: any) {
        let url = Config.GetURL('/api/IPMR/BALRMSItemInfo/GetItemInfoByPartNumber?partNumber=' + id);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getRequestersRequests(status: any) {
        let url = Config.GetURL('/api/IPMR/BALRMSCorelist/GetMyCreatedRequestsByStatus?status=' + status);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getStoresRequests(status: any) {
        let url = Config.GetURL('/api/IPMR/BALRMSCorelist/GetStoresRequestsByStatus?status=' + status);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    viewAllStoreRequest(status:any) {
        let url = Config.GetURL('/api/IPMR/BALRMSCorelist/GetAllStoresRequestsByStatus?status=' + status);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getAllOpenRequests() {
        let url = Config.GetURL('/api/IPMR/BALRMSCorelist/GetPendingGLApprovalRequests');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getGLPendingRequests_Admin() {
        let url = Config.GetURL('/api/IPMR/BALRMSCorelist/GetAllPendingGLApprovalRequests');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    AddIPMRRequest(payload: IPMR) {
        let url = Config.GetURL('/api/IPMR/BALRMSCorelist/AddIPMR');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getGLRequestByID(id: any) {
        let url = Config.GetURL('/api/IPMR/BALRMSCorelist/GetIPMRByID/' + id);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getStoreRequestByID(id: any) {
        let url = Config.GetURL('/api/IPMR/BALRMSCorelist/GetIPMRByIDToStores/' + id);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    approveRejectRequest(payload: any) {
        let url = Config.GetURL('/api/IPMR/BALRMSCorelist/GLActionOnRequest');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    approveRejectRequest_Admin(payload: any) {
        let url = Config.GetURL('/api/IPMR/BALRMSCorelist/AdminGLActionOnRequest');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    UpdateStoreData(payload: any) {
        let url = Config.GetURL('/api/IPMR/BALRMSCorelist/UpdateIPMR');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getCounters() {
        let url = Config.GetURL('/api/IPMR/BALRMSCorelist/GetRequesterCounters');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getStoreCounters() {
        let url = Config.GetURL('/api/IPMR/BALRMSCorelist/GetStoresCounters');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getStoreTotalCount(status: any) {
        let url = Config.GetURL('/api/IPMR/BALRMSCorelist/GetAllStoresRequestCountByStatus?status=' + status);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getSearchResult(value: any) {
        let url = Config.GetURL('/api/IPMR/BALRMSCorelist/GetIPMRByRequestID?requestID=' + value.RequestID);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getSearchResultByItemID(value: any) {
        let url = Config.GetURL('/api/IPMR/BALRMSItemslist/GetPartDetailsByPartNumbers?partNumbers=' + value);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    UpdatePartNumber(payload: any) {
        let url = Config.GetURL('/api/IPMR/BALRMSCorelist/UpdateItemID');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getReportsWithinDateRange(value: any) {
        let url = Config.GetURL('/api/IPMR/BALRMSCorelist/GetRequestsWithinDateRange?dateFrom='
            + value.FromDate + '&dateTo=' + value.ToDate + '&status=' + value.Status);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    searchMultipleItemsByRMSID(value: any) {
        let url = Config.GetURL('/api/IPMR/BALRMSItemslist/GetRMSItemsByRMSNumbers?rmsID=' + value.RMSID);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    /**Success Handler */
    private extractData(res: Response) {
        if (res.status < 200 || res.status >= 300) {
            throw new Error('Bad response status: ' + res.status);
        }
        let body = res.json();
        return body || {};
    }
    private extractDataForValidate(res: Response) {
        if (res.status < 200 || res.status >= 300) {
            throw new Error('Bad response status: ' + res.status);
        }
        let body = res.json();
        return body || false;
    }
    /**Error Handler */
    private handleError(error: Response) {
        console.log(error);
        return Observable.throw(error.json().error || 'Server error');
    }
}
