import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MessageService } from '../../shared/services/message.service';
import { CommonService } from '../../shared/services/common.service';
import { DashboardService } from '../../dashboard/services/dashboard.service';
import { StoreModel } from '../../dashboard/models/storeModel';
@Component({
    moduleId: module.id,
    selector: 'sd-datewisereport',
    templateUrl: 'datewiseReport.component.html',
    styleUrls: ['datewiseReport.component.css']
})

export class DatewiseReportComponent implements OnInit {
    ReportForm: FormGroup;
    showErr: boolean = false;
    IPMRData: any = [];
    errorMessage: any;
    rmsno: any = '';
    partno: any = '';
    todate: any;
    fromdate: any;
    constructor(private formBuilder: FormBuilder, private _router: Router,
        private _messageService: MessageService,
        private _commonService: CommonService,
        private _dashboardService: DashboardService) {
    }
    ngOnInit() {
        this.setReportForm();
        this.todate = new Date();
        this.fromdate = new Date();
    }
    setReportForm() {
        this.ReportForm = this.formBuilder.group({
            FromDate: [new Date()],
            ToDate: [new Date()],
            Status: ['All']
        });
    }
    onSubmit({ value, valid }: { value: any, valid: boolean }) {
        this.IPMRData = [];
        let fromMonth = this.fromdate.getMonth() + 1;
        let toMonth = this.todate.getMonth() + 1;
        value.FromDate = this.fromdate.getFullYear() + '-' + toMonth + '-' + this.fromdate.getDate();
        value.ToDate = this.todate.getFullYear() + '-' + fromMonth + '-' + this.todate.getDate();
        this._dashboardService.getReportsWithinDateRange(value)
            .subscribe(
            (results: any) => {
                if (results.length > 0) {
                    this.IPMRData = results;
                }
            },
            (error: any) => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onFromDate(event: any) {
        this.fromdate = event;
    }
    onToDate(event: any) {
        this.todate = event;
    }
}
