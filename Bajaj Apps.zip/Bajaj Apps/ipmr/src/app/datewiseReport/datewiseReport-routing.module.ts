import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { DatewiseReportComponent } from './components/datewiseReport.component';

@NgModule({
  imports: [
    RouterModule.forChild([
      { path: 'datewiseReport', component: DatewiseReportComponent }
    ])
  ],
  exports: [RouterModule]
})
export class DatewiseReportRoutingModule { }
