import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DatewiseReportComponent } from './components/datewiseReport.component';
import { DatewiseReportRoutingModule } from './datewiseReport-routing.module';
import { BrowserModule } from '@angular/platform-browser';
import { SharedModule } from '../shared/shared.module';
@NgModule({
    imports: [CommonModule, DatewiseReportRoutingModule, SharedModule],
    declarations: [DatewiseReportComponent],
    exports: [DatewiseReportComponent],
    providers: []
})
export class DatewiseReportModule { }
