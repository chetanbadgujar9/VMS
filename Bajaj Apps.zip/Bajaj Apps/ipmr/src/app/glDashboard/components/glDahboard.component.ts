import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MessageService } from '../../shared/services/message.service';
import { CommonService } from '../../shared/services/common.service';
import { DashboardService } from '../../dashboard/services/dashboard.service';
import { ConfirmationService } from 'primeng/primeng';
import { AuthInfo } from '../../dashboard/models/authInfo';
import { IPMR } from '../../dashboard/models/IPMRModel';
import { User } from '../../dashboard/models/loginUser';
import { Searchmodel } from '../../dashboard/models/searchmodel';
import { StoreModel } from '../../dashboard/models/storeModel';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-gldashboard',
    templateUrl: 'glDashboard.component.html',
    styleUrls: ['glDashboard.component.css'],
    providers: [ConfirmationService]
})
export class GLDashboardComponent implements OnInit {
    cars: any[] = [];
    IPMRData: any = [];
    IPMRallRequestData: any = [];
    StoreItemData: any = [];
    itemInfo: any = [];
    projectData: any = [];
    rmsMenu: any[];
    plant: any[];
    rmsStatus: any[];
    BIN: any[];
    BINNO: any[];
    counterData:any = {};
    viewData: any[];

    /** Model Data */
    StoreData: StoreModel// = new StoreModel();

    /** Form Variables */
    searchForm: FormGroup;
    AddRequestForm: FormGroup;
    ApproveRejectForm: FormGroup;
    StoreForm: FormGroup;

    /** Flags Variables */
    display: boolean = false;
    showCreate: boolean = false;
    showIPMRForm: boolean = false;
    showSearchRequestForm: boolean = false;
    errorFlagForAddForm: boolean = false;
    showQuantityNeededErr: boolean = false;
    showItemNameErr: boolean = false;
    showItemIdErr: boolean = false;
    showApproveRejectForm: boolean = false;
    showStoreForm: boolean = false;
    itemInfoErr: boolean = false;
    errorFlagForSearchForm: boolean = false;
    onSearchClickToShowAction: boolean = false;
    errorFlagForApproveRejectForm: boolean = false;
    ApproveButton: boolean = false;
    RejectButton: boolean = false;
    errorFlagForStoreForm: boolean = false;
    showViewForm: boolean = false;
    characterleft: any;
    maxlength: any = 250;

    /** Model Variables */
    model: AuthInfo;
    loggedInUserData: User = new User();

    /**General Variables */
    loggedInUser: string = 'tcctest5';
    loggedInUserGroup: string;
    itemid: string = '';
    itemname: string = '';
    quantityrequired: string = '';
    requesttitle: any;
    errorMessage: any;
    minDate: Date;
    status: any;
    headingColor: any;
    requestID: any;
    ID: any;
    requiredByDate: any;

    constructor(private formBuilder: FormBuilder, private _messageService: MessageService, private _dashboardService: DashboardService,
        private _commonService: CommonService, private _router: Router, private _confirmationService: ConfirmationService) {
        this.model = new AuthInfo('password', '', '');
    }
    ngOnInit() {
        this.characterleft = this.maxlength;
        //this.loggedInUser = sessionStorage.getItem('Username') ? sessionStorage.getItem('Username').split('\\')[1] : '';
        var someDate = new Date();
        var numberOfDaysToAdd = 3;
        var threeDaysLater = someDate.setDate(someDate.getDate() + numberOfDaysToAdd);
        this.requiredByDate = new Date(threeDaysLater);
        this.setSearchForm();
        this.setApproveRejectForm();
        this.setStoreForm();
        this.loggedInUserData = JSON.parse(sessionStorage.getItem('loggedInUserData'));
        this.loggedInUserGroup = this.loggedInUserData ? this.loggedInUserData.Group : '';
        this.getAllOpenRequests();
        this.setAddForm();
        this.StoreItemData = [
            { "RMSID": "VW", "ItemID": 2012, "ItemDesc": "Orange", "ReqQty": "dsad231ff", "Plant": "", "PRno": "", "RecQty": "", "GRNo": "", "RMSStatus": "", "BINID": "", "BINNo": "" },
            { "RMSID": "VW", "ItemID": 2012, "ItemDesc": "Orange", "ReqQty": "dsad231ff", "Plant": "", "PRno": "", "RecQty": "", "GRNo": "", "RMSStatus": "", "BINID": "", "BINNo": "" },
            { "RMSID": "VW", "ItemID": 2012, "ItemDesc": "Orange", "ReqQty": "dsad231ff", "Plant": "", "PRno": "", "RecQty": "", "GRNo": "", "RMSStatus": "", "BINID": "", "BINNo": "" },
            { "RMSID": "VW", "ItemID": 2012, "ItemDesc": "Orange", "ReqQty": "dsad231ff", "Plant": "", "PRno": "", "RecQty": "", "GRNo": "", "RMSStatus": "", "BINID": "", "BINNo": "" },
            { "RMSID": "VW", "ItemID": 2012, "ItemDesc": "Orange", "ReqQty": "dsad231ff", "Plant": "", "PRno": "", "RecQty": "", "GRNo": "", "RMSStatus": "", "BINID": "", "BINNo": "" },
            { "RMSID": "VW", "ItemID": 2012, "ItemDesc": "Orange", "ReqQty": "dsad231ff", "Plant": "", "PRno": "", "RecQty": "", "GRNo": "", "RMSStatus": "", "BINID": "", "BINNo": "" },
            { "RMSID": "VW", "ItemID": 2012, "ItemDesc": "Orange", "ReqQty": "dsad231ff", "Plant": "", "PRno": "", "RecQty": "", "GRNo": "", "RMSStatus": "", "BINID": "", "BINNo": "" },
            { "RMSID": "VW", "ItemID": 2012, "ItemDesc": "Orange", "ReqQty": "dsad231ff", "Plant": "", "PRno": "", "RecQty": "", "GRNo": "", "RMSStatus": "", "BINID": "", "BINNo": "" },
            { "RMSID": "VW", "ItemID": 2012, "ItemDesc": "Orange", "ReqQty": "dsad231ff", "Plant": "", "PRno": "", "RecQty": "", "GRNo": "", "RMSStatus": "", "BINID": "", "BINNo": "" },
            { "RMSID": "VW", "ItemID": 2012, "ItemDesc": "Orange", "ReqQty": "dsad231ff", "Plant": "", "PRno": "", "RecQty": "", "GRNo": "", "RMSStatus": "", "BINID": "", "BINNo": "" },
            { "RMSID": "VW", "ItemID": 2012, "ItemDesc": "Orange", "ReqQty": "dsad231ff", "Plant": "", "PRno": "", "RecQty": "", "GRNo": "", "RMSStatus": "", "BINID": "", "BINNo": "" },
            { "RMSID": "VW", "ItemID": 2012, "ItemDesc": "Orange", "ReqQty": "dsad231ff", "Plant": "", "PRno": "", "RecQty": "", "GRNo": "", "RMSStatus": "", "BINID": "", "BINNo": "" }
        ]
        this.plant = [{ "label": "Chakan(CH01)", "value": "Chakan(CH01)" }, { "label": "Waluj MCD(WA01)", "value": "Waluj MCD(WA01)" }, { "label": "Waluj 3-WH(WA10)", "value": "Waluj 3-WH(WA10)" }, { "label": "Waluj Spare Parts(WA01)", "value": "Waluj Spare Parts(WA01)" }, { "label": "Waluj 4 WH(WA31)", "value": "Waluj 4 WH(WA31)" }, { "label": "Pant Nagar(PA)", "value": "Pant Nagar(PA)" }];
        this.rmsStatus = [{ "label": "Open", "value": "Open" },
        { "label": "PR Raised", "value": "PR Raised" },
        { "label": "Material Partially Received", "value": "Material Partially Received" },
        { "label": "Material Received", "value": "Material Received" },
        { "label": "Request Dropped", "value": "Request Dropped" },
        { "label": "Request Rejected", "value": "Request Rejected" },
        { "label": "Material Unavailable", "value": "Material Unavailable" },
        { "label": "Material Available in R&D", "value": "Material Available in R&D" }];
        this.BIN = [{ 'label': 'Floor Area', 'value': 'Floor Area' }, { 'label': 'Issued', 'value': 'Issued' }];
        this.BINNO = [{ 'label': 'Floor Area', 'value': 'Floor Area' }, { 'label': 'Issued', 'value': 'Issued' }];
    }
    /** Get Status wise requests */
    getAllOpenRequests() {
        this.status = 'All Open';
        this.headingColor = '#e53935';
        this.IPMRallRequestData = [];
        this._dashboardService.getAllOpenRequests()
            .subscribe(
            (results: any) => {
                if (results.length > 0) {
                    this.IPMRallRequestData = results;
                }
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onAllRequest() {
        this.showCreate = false;
        this.showViewForm = false;
        this.showApproveRejectForm = false;
        this.showIPMRForm = false;
        this.showSearchRequestForm = false;
    }
    onMyRequest() {
        this.showCreate = true;
        this.showViewForm = false;
        this.showApproveRejectForm = false;
        this.showIPMRForm = false;
        this.showSearchRequestForm = false;
        this.getCounters();
        this.onOpenClick();
    }
    getCounters() {
        this._dashboardService.getCounters()
            .subscribe(
            (results: any) => {
                this.counterData = results;
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onOpenClick() {
        this.showApproveRejectForm = false;
        this.showIPMRForm = false;
        this.showSearchRequestForm = false;
        this.showViewForm = false;
        this.status = 'Open';
        this.headingColor = '#e53935';
        this.getRequestersRequests(this.status);
    }
    onPRraisedClick() {
        this.showApproveRejectForm = false;
        this.showIPMRForm = false;
        this.showSearchRequestForm = false;
        this.showViewForm = false;
        this.status = 'PR Raised';
        this.headingColor = '#43a047';
        this.getRequestersRequests(this.status);
    }
    onMaterialReceivedClick() {
        this.showApproveRejectForm = false;
        this.showIPMRForm = false;
        this.showSearchRequestForm = false;
        this.showViewForm = false;
        this.status = 'Material Received';
        this.headingColor = '#00acc1';
        this.getRequestersRequests(this.status);
    }
    onMaterialPartiallyReceivedClick() {
        this.showApproveRejectForm = false;
        this.showIPMRForm = false;
        this.showSearchRequestForm = false;
        this.showViewForm = false;
        this.status = 'Material Partially Received';
        this.headingColor = '#fb8c00';
        this.getRequestersRequests(this.status);
    }
    onMaterialUnavailableClick() {
        this.showApproveRejectForm = false;
        this.showIPMRForm = false;
        this.showSearchRequestForm = false;
        this.showViewForm = false;
        this.status = 'Material Unavailable';
        this.headingColor = '#d81b60';
        this.getRequestersRequests(this.status);
    }
    onRequestDroppedClick() {
        this.showApproveRejectForm = false;
        this.showIPMRForm = false;
        this.showSearchRequestForm = false;
        this.showViewForm = false;
        this.status = 'Request Dropped';
        this.headingColor = '#8e24aa';
        this.getRequestersRequests(this.status);
    }
    onRequestRejected() {
        this.showApproveRejectForm = false;
        this.showIPMRForm = false;
        this.showSearchRequestForm = false;
        this.showViewForm = false;
        this.status = 'Request Rejected';
        this.headingColor = '#999999';
        this.getRequestersRequests(this.status);
    }

    // this function is for requester to get data
    getRequestersRequests(status: any) {
        this.IPMRData = [];
        this._dashboardService.getRequestersRequests(status)
            .subscribe(
            (results: any) => {
                if (results.length > 0) {
                    this.IPMRData = results;
                }
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }

    /**General Functions */
    addItem() {
        let count;
        count = this.itemInfo.length + 1;
        let itemObj = {};
        if (this.itemid !== '') {
            this.showItemIdErr = false;
            if (this.itemname !== '') {
                this.showItemNameErr = false;
                if (this.quantityrequired !== '') {
                    this.showQuantityNeededErr = false;
                    let checkDuplicate;
                    this.itemInfo.forEach(element => {
                        if (element.Item_ID === this.itemid) {
                            checkDuplicate = true;
                            document.getElementById('duplicate').innerHTML = 'Item already exist in the list';
                            document.getElementById('duplicate').className = "required";
                            document.getElementById('duplicate').style.display = 'block';
                        }
                    });
                    if (!checkDuplicate) {
                        document.getElementById('duplicate').style.display = 'none';
                        itemObj = { 'id': count, 'Item_ID': this.itemid, 'Item_Name': this.itemname, 'QTY_Required': this.quantityrequired };
                        this.itemInfo.push(itemObj);
                        this.itemid = '';
                        this.itemname = '';
                        this.quantityrequired = '';
                        this.itemInfoErr = false;
                    }
                }
                else {
                    this.showQuantityNeededErr = true;
                }
            }
            else {
                this.showItemNameErr = true;
            }
        }
        else {
            this.showItemIdErr = true;
        }
    }
    countChars(model: any) {
        if (this.maxlength >= model.length) {
            this.characterleft = (this.maxlength) - (model.length);
        } else {
            this.requesttitle = model.substr(0, model.length - 1);
        }
    }
    onDeleteItemInfo(item: any) {
        let index = this.itemInfo.indexOf(item);
        this.itemInfo.splice(index, 1);
    }
    validateItemID(itemId: any) {
        if (itemId !== '') {
            this._dashboardService.validateItemId(itemId)
                .subscribe((results: any) => {
                    if (Object.keys(results).length !== 0) {
                        this.itemname = results;
                        document.getElementById('duplicate').style.display = 'none';
                    }
                    else {
                        this._dashboardService.validateItemIdInRMS(itemId)
                            .subscribe((results: any) => {
                                if (Object.keys(results).length !== 0) {
                                    this.itemname = results.Description;
                                    document.getElementById('duplicate').style.display = 'none';
                                }
                                else {
                                    this.itemname = '';
                                    document.getElementById('duplicate').innerHTML = 'Invalid Item Id';
                                    document.getElementById('duplicate').className = "required";
                                    document.getElementById('duplicate').style.display = 'block';
                                }
                            });
                    }
                });
        }
    }
    validateItemIDLength(num: any) {
        let maxlength = 10;
        if (maxlength >= num.toString().length) {

        }
        else {
            this.itemid = num.toString().substr(0, num.toString().length - 1);
        }
        this.itemid = this.itemid.toUpperCase();
    }
    /** Set Forms */
    setAddForm() {
        var someDate = new Date();
        var numberOfDaysToAdd = 3;
        var threeDaysLater = someDate.setDate(someDate.getDate() + numberOfDaysToAdd);
        this.minDate = new Date(threeDaysLater);
        this.AddRequestForm = this.formBuilder.group({
            Title: ['', [Validators.required]],
            Group: [this.loggedInUserGroup],
            Project: ['', [Validators.required]],
            RequestBy: [this.loggedInUser],
            RequiredByDate: [new Date(threeDaysLater)],
            Purpose: ['', [Validators.required]],
            Comments: ['', [Validators.required]],
            ItemID: [''],
            ItemName: [''],
            QuantityRequired: [''],

        });
    }
    onCreateRequest() {
        this.setAddForm();
        this.showIPMRForm = true;
        this.showSearchRequestForm = false;
        this.onSearchClickToShowAction = false;
        this.showViewForm = false;
        this.showViewForm = false;
        this.itemInfo = [];
        this.characterleft = 250;
        this.requesttitle = '';
        this.itemid = this.itemname = this.quantityrequired = '';
        this.getProjectMaster();
    }
    onSearch() {
        this.showSearchRequestForm = true;
        this.onSearchClickToShowAction = false;
        this.showIPMRForm = false;
        this.showViewForm = false;
        this.setSearchForm();
    }
    setSearchForm() {
        this.searchForm = this.formBuilder.group({
            // fieldName: ['Item ID', [Validators.required]],
            RequestID: ['', [Validators.required]]
        });
    }
    setApproveRejectForm() {
        this.ApproveRejectForm = this.formBuilder.group({
            Title: [''],
            Group: [''],
            Project: [''],
            RequestBy: [''],
            RequiredByDate: [''],
            Purpose: [''],
            Comments: [''],
            GLComments: ['', [Validators.required]]
        });
    }
    setStoreForm() {
        this.StoreForm = this.formBuilder.group({
            Title: [''],
            Group: [''],
            Project: [''],
            RequestBy: [''],
            RequiredByDate: [''],
            Purpose: [''],
            Comments: [''],
            RequestStatus: ['Open', [Validators.required]]
        });
    }
    /** Get master data */
    getProjectMaster() {
        this._commonService.getProjectMaster()
            .subscribe(
            (results: any) => {
                this.projectData = results;
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onViewRequest(request: IPMR) {
        this.showApproveRejectForm = false;
        this.showIPMRForm = false;
        this.showSearchRequestForm = false;
        this.showStoreForm = false;
        this.showViewForm = false;
        this._dashboardService.getStoreRequestByID(request.ID)
            .subscribe(
            (results: any) => {
                this.viewData = results;
                this.showViewForm = true;
               // console.log('view', this.viewData);
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onSelectRequest(request: IPMR) {
        this.showApproveRejectForm = true;
        this.errorFlagForApproveRejectForm = false;
        this.showIPMRForm = false;
        this.showSearchRequestForm = false;
        this.onSearchClickToShowAction = false;
        this.showViewForm = false;
        this.requestID = request.RequestID;
        this.ID = request.ID;
        this.itemInfo = [];
        this._dashboardService.getGLRequestByID(request.ID)
            .subscribe(
            (results: IPMR) => {
                this.itemInfo = results.Items;
                this.ApproveRejectForm.setValue({
                    Title: results.Title,
                    Group: results.Group,
                    Project: results.Project,
                    RequestBy: results.RequestBy,
                    RequiredByDate: results.RequiredByDate,
                    Purpose: results.Purpose,
                    Comments: results.Comments,
                    GLComments: ''
                });
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    /**Submit Actions */
    onSubmitRequest({ value, valid }: { value: IPMR, valid: boolean }) {
        if (valid) {
            if (this.itemInfo.length > 0) {
                this.itemInfoErr = false;
                let month = new Date(this.requiredByDate).getMonth() + 1;
                value.Items = this.itemInfo;
                value.RequiredByDate = new Date(this.requiredByDate).getDate() + "/" + month + "/" + new Date(this.requiredByDate).getFullYear();
                value.Title = value.Title ? value.Title.replace(/'/g, "\\'").trim() : '';
                value.Comments = value.Comments ? value.Comments.replace(/'/g, "\\'").trim() : '';
                value.Purpose = value.Purpose ? value.Purpose.replace(/'/g, "\\'").trim() : '';
                this._dashboardService.AddIPMRRequest(value)
                    .subscribe(
                    (results: any) => {
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.showIPMRForm = false;
                        this.getCounters();
                        this.onOpenClick();
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            } else {
                this.itemInfoErr = true;
            }
        } else {
            this.errorFlagForAddForm = true;
        }
    }
    onSubmitSearch({ value, valid }: { value: any, valid: boolean }) {
        if (valid) {
            this.IPMRData = [];
            this.errorFlagForSearchForm = false;
            this.onSearchClickToShowAction = true;
            value.RequestID = value.RequestID ? value.RequestID.trim() : '';
            this._dashboardService.getSearchResult(value)
                .subscribe(
                (results: any) => {
                    this.IPMRData = [results];
                    this.status = results.Status;
                    switch (this.status) {
                        case 'Open': this.headingColor = '#e53935';
                            break;
                        case 'PR Raised': this.headingColor = '#43a047';
                            break;
                        case 'Material Received': this.headingColor = '#00acc1';
                            break;
                        case 'Material Partially Received': this.headingColor = '#fb8c00';
                            break;
                        case 'Material Unavailable': this.headingColor = '#d81b60';
                            break;
                        case 'Request Dropped': this.headingColor = '#8e24aa';
                            break;
                        case 'Request Rejected': this.headingColor = '#999999';
                            break;
                    }
                },
                error => {
                    this.errorMessage = <any>error;
                    this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                });

        } else {
            this.errorFlagForSearchForm = true;
        }
    }
    onApproveRejectRequest({ value, valid }: { value: IPMR, valid: boolean }) {
        let payload = {};
        if (valid) {
            if (this.ApproveButton === true) {
                this.ApproveButton = false;
                this.RejectButton = false;
                payload = { 'ID': this.ID, 'RequestID': this.requestID, 'Title': value.Title, 'RequestBy': value.RequestBy, 'GLApproval': 'Approved', 'GLComments': value.GLComments ? value.GLComments.replace(/'/g, "\\'").trim() : '' };
            }
            if (this.RejectButton === true) {
                this.ApproveButton = false;
                this.RejectButton = false;
                payload = { 'ID': this.ID, 'RequestID': this.requestID, 'Title': value.Title, 'RequestBy': value.RequestBy, 'GLApproval': 'Rejected', 'GLComments': value.GLComments ? value.GLComments.replace(/'/g, "\\'").trim() : '' };
            }
            this._dashboardService.approveRejectRequest(payload)
                .subscribe(
                (results: any) => {
                    this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                    this.showApproveRejectForm = false;
                    this.errorFlagForApproveRejectForm = false;
                    this.getAllOpenRequests();
                },
                error => {
                    this.errorMessage = <any>error;
                    this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                });
        } else {
            this.errorFlagForApproveRejectForm = true;
        }
    }
    onStoreRequest() {
        if (this.StoreData.RequestStatus !== '') {
           // console.log('store', this.StoreData);
        } else {
            this.errorFlagForStoreForm = true;
        }
    }
    onCancelForm() {
        this.showIPMRForm = false;
    }
    onCloseSearchForm() {
        this.showSearchRequestForm = false;
        this.errorFlagForSearchForm = false;
    }
    onCancelApproveRejectForm() {
        this.showApproveRejectForm = false;
    }
    onCancelStoreForm() {

    }
    onCloseView() {
        this.showViewForm = false;
    }
    onRequiredByDate(event: any) {
        this.requiredByDate = event;
    }
}
