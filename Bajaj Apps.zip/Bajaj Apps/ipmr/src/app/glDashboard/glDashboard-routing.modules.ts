import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { GLDashboardComponent } from './components/glDahboard.component';

@NgModule({
  imports: [
    RouterModule.forChild([
      { path: 'GLDashboard', component: GLDashboardComponent }
    ])
  ],
  exports: [RouterModule]
})
export class GLDashboardRoutingModule { }
