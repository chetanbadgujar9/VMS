import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GLDashboardComponent } from './components/glDahboard.component';
import { GLDashboardRoutingModule } from './glDashboard-routing.modules';
import { BrowserModule } from '@angular/platform-browser';
import { SharedModule } from '../shared/shared.module';
import { DashboardService } from '../dashboard/services/dashboard.service';
@NgModule({
    imports: [CommonModule, GLDashboardRoutingModule, SharedModule],
    declarations: [GLDashboardComponent],
    exports: [GLDashboardComponent],
    providers: [DashboardService]
})
export class GLDashboardModule { }
