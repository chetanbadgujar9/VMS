import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MessageService } from '../../shared/services/message.service';
import { MaterialService } from '../services/material.service';
import { CommonService } from '../../shared/services/common.service';
//import  {XLSX}  from 'xlsx';
declare var XLSX: any;
@Component({
    moduleId: module.id,
    selector: 'sd-material',
    templateUrl: 'material.component.html',
    styleUrls: ['material.component.css']
})

export class MaterialComponent implements OnInit {
    IPMRData: any = [];
    filesData: any = [];
    EditData: any=[];
    fileName: any;
    showAddForm: boolean = false;
    showItemCodeErr: boolean = false;
    showQuantityErr: boolean = false;
    showRMSNOErr: boolean = false;
    materialInfoErr: boolean = false;
    showEditForm: boolean = false;
    showSearchItemCode: boolean = false;
    errFlag: boolean = false;
    StoreForm: FormGroup;
    searchItemCodeForm: FormGroup;
    excelData: any[];
    materialData: any[];
    materialInfo: any = [];
    BINID: any = [];
    BINNO: any = [];
    FromData: any = [];
    errorMessage: any;
    itemcode: any = '';
    quantity: any = '';
    rmsno: any = '';
    from: any = 'GR';
    grno: any = '';
    vendor: any = '';
    packing: any = '';
    binid: any = 'RMS/Plant';
    binno: any = '';
    desc: any = '';
    date: any = '';
    constructor(private formBuilder: FormBuilder, private _router: Router,
        private _messageService: MessageService, private _materialService: MaterialService,
        private _commonService: CommonService) {
        this.materialData = [];
    }
    ngOnInit() {
        this.setStoreForm();
        this.setSearchItemForm();
        this.getItemList();
    }
    //ngOnDestoy() {
    //    localStorage.clear();
    //}
    setStoreForm() {
        this.StoreForm = this.formBuilder.group({
            ItemId: ['', [Validators.required]],
            // Group: [this.loggedInUserGroup, [Validators.required]],
            // RequestType: ['Claim'],
            // Project: ['', [Validators.required]],
            // Category: ['', [Validators.required]],
            // MaterialDescription: ['', [Validators.required]],
            // Quantity: ['', [Validators.required]],
            // Amount: ['', [Validators.required]],
            // Purpose: ['', [Validators.required]],
            // Comments: ['', [Validators.required]]
        });
    }
    setSearchItemForm() {
        this.searchItemCodeForm = this.formBuilder.group({
            ItemCode: ['', [Validators.required]]
        });
    }
    getItemList() {
        this._materialService.getItemList()
            .subscribe(
            (results: any) => {
                this.IPMRData = results;
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });

            });
    }
    getFrom() {
        this._commonService.getFromList()
            .subscribe(
            (results: any) => {
                if (results.length > 0) {
                    this.FromData = results;
                    // let add = { 'label': '--Select--', 'value': 'Select' };
                    // this.BINID.unshift(add);
                }
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    getBINID() {
        this._commonService.getBINID()
            .subscribe(
            (results: any) => {
                if (results.length > 0) {
                    this.BINID = results;
                    this.onBINIDClick(this.BINID[0].value);
                    this.binno = 'Floor Area';
                    // let add = { 'label': '--Select--', 'value': 'Select' };
                    // this.BINID.unshift(add);
                }
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    getBINID1() {
        this._commonService.getBINID()
            .subscribe(
            (results: any) => {
                if (results.length > 0) {
                    this.BINID = results;
                }
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onBINIDClick(binid: any) {
        this._commonService.getBINNO(binid)
            .subscribe(
            (results: any) => {
                if (results.length > 0) {
                    this.BINNO = results;
                    this.binno = results[0].value;
                }
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onBINIDClick1(binid: any) {
        this._commonService.getBINNO(binid)
            .subscribe(
            (results: any) => {
                if (results.length > 0) {
                    this.BINNO = results;
                    //this.binno = results[0].value;
                }
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onEditRequest(request: any) {
        this.showSearchItemCode = false;
        this.getBINID1();
        this.onBINIDClick1(request.BINID);
        this.getFrom();
        this.EditData = request;
        this.showEditForm = true;
        this.materialInfo = [];
        this.fileName = '';
        var addform = document.getElementById('addform');
        addform.style.display = 'block';
        var form1 = document.getElementById('form1');
        form1.style.display = 'none';
        var form2 = document.getElementById('form2');
        form2.style.display = 'none';
    }
    onCopyRequest(request: any) {
        this.showSearchItemCode = false;
        this.getBINID1();
        this.onBINIDClick1(request.BINID);
        this.getFrom();
        let month = new Date().getMonth() + 1;
        this.date = request.Date ? request.Date : new Date().getFullYear() + '-' + month + '-' + new Date().getDate() //"2017-10-25";
        this.fileName = '';
        this.showEditForm = false;
        var addform = document.getElementById('addform');
        addform.style.display = 'block';
        var form1 = document.getElementById('form1');
        form1.style.display = 'none';
        var form2 = document.getElementById('form2');
        form2.style.display = 'block';
        this.itemcode = request.ItemCode ? request.ItemCode : '';
        this.quantity = request.Qty ? request.Qty : '';
        this.from = request.From ? request.From : '';
        this.grno = request.GRNumber ? request.GRNumber : '';
        this.vendor = request.Vendor ? request.Vendor : '';
        this.packing = request.Packing ? request.Packing : '';
        this.rmsno = request.RMSNO ? request.RMSNO : '';
        this.binid = request.BINID ? request.BINID : '';
        this.binno = request.BINNO ? request.BINNO : '';
        this.desc = request.Description ? request.Description : '';
        this.materialInfoErr = false;
        this.showItemCodeErr = false;
        this.showQuantityErr = false;
        this.showRMSNOErr = false;
    }
    onAddItem() {
        //this.showAddForm = true;
        this.showSearchItemCode = false;
        this.getBINID();
        this.getFrom();
        let month = new Date().getMonth() + 1;
        this.date = new Date().getFullYear() + '-' + month + '-' + new Date().getDate() //"2017-10-25";
        this.fileName = '';
        this.showEditForm = false;
        var addform = document.getElementById('addform');
        addform.style.display = 'block';
        var form1 = document.getElementById('form1');
        form1.style.display = 'none';
        var form2 = document.getElementById('form2');
        form2.style.display = 'block';
        this.materialInfo = [];
        this.itemcode = '';
        this.quantity = '';
        this.rmsno = '';
        this.binid = 'Floor Area';
        this.binno = '';
        this.from = 'GR';
        this.grno = '';
        this.vendor = '';
        this.packing = '';
        this.desc = '';
        this.materialInfoErr = false;
        this.showItemCodeErr = false;
        this.showQuantityErr = false;
        this.showRMSNOErr = false;

    }
    SearchItemCode() {
        this.showSearchItemCode = true;
        this.errFlag = false;
        this.setSearchItemForm();
        var addform = document.getElementById('addform');
        addform.style.display = 'none';
        this.showEditForm = false;
        var form1 = document.getElementById('form1');
        form1.style.display = 'none';
        var form2 = document.getElementById('form2');
        form2.style.display = 'none';
    }
    postFile(inputValue: any): void {
        var format = /[!@#$%^&*()+\-=\[\]{};':'\\|,.<>\/?]+/;
        try {
            let FileList: FileList = inputValue.target.files;
            if (FileList.length > 0) {
                if (inputValue.target.files[0].size < 2000000) {
                    if (inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'xls' ||
                        inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'xlsx') {
                        if (!format.test(inputValue.target.files[0].name.split('.')[0])) {
                            this.filesData.length = 0;
                            for (let i = 0, length = FileList.length; i < length; i++) {
                                this.filesData.push(FileList.item(i));
                                this.fileName = FileList.item(i).name;
                            }
                            var f = this.filesData[0];
                            var reader = new FileReader();
                            reader.onload = function (e:any) {
                                var data = e.target.result;
                                data = new Uint8Array(data);
                                var workbook = XLSX.read(data, { type: "array" });
                                var first_sheet_name = workbook.SheetNames[0];
                                var worksheet = workbook.Sheets[first_sheet_name];
                                var JSONData = [];
                                JSONData = (XLSX.utils.sheet_to_json(worksheet, { raw: true }));
                                localStorage.setItem('excel', JSON.stringify(JSONData));
                                if (JSONData.length > 0) {
                                    var rowToDelete = document.getElementById('form1').getElementsByClassName('row');
                                    if (rowToDelete.length > 0) {
                                        for (let i = rowToDelete.length - 1; i >= 0; i--) {
                                            rowToDelete.item(i).remove();
                                        }
                                    };
                                    document.getElementById('form1').style.display = 'block';
                                    document.getElementById('form2').style.display = 'none';
                                    for (let i = 0; i < JSONData.length; i++) {
                                        var rowElement = document.createElement('div');
                                        rowElement.className = "row";
                                        // For Item Code
                                        var colElement = document.createElement('div');
                                        colElement.className = "col-lg-1 col-md-1 col-xlg-1";

                                        var colLableElement = document.createElement('div');
                                        colLableElement.className = "form-group label-black label-floating is-focused";

                                        var labelElement = document.createElement('label');
                                        labelElement.className = "control-label";
                                        var node = document.createTextNode("Item Code");

                                        var inputElement = document.createElement('input');
                                        inputElement.type = 'text';
                                        inputElement.className = 'form-control';
                                        inputElement.value = JSONData[i]['Material'] ? JSONData[i]['Material'] : '';
                                        inputElement.id = 'itemid' + i;
                                        inputElement.required = true;
                                        inputElement.maxLength = 8;

                                        rowElement.appendChild(colElement);
                                        colElement.appendChild(colLableElement);
                                        colLableElement.appendChild(labelElement);
                                        labelElement.appendChild(node);
                                        colLableElement.appendChild(inputElement);

                                        // For Quantity
                                        var colElement1 = document.createElement('div');
                                        colElement1.className = "col-lg-1 col-md-1 col-xlg-1";

                                        var colLableElement1 = document.createElement('div');
                                        colLableElement1.className = "form-group label-black label-floating is-focused";

                                        var labelElement1 = document.createElement('label');
                                        labelElement1.className = "control-label";
                                        var node1 = document.createTextNode("Qty");

                                        var inputElement1 = document.createElement('input');
                                        inputElement1.type = 'number';
                                        inputElement1.className = 'form-control';
                                        inputElement1.id = 'quantity' + i;
                                        inputElement1.value = JSONData[i]['Qty in Un. of Entry'] ? JSONData[i]['Qty in Un. of Entry'] : '';
                                        inputElement1.required = true;
                                        inputElement1.maxLength = 6;
                                        //inputElement.setAttribute('ng-model', this.excelData[i].Item);

                                        rowElement.appendChild(colElement1);
                                        colElement1.appendChild(colLableElement1);
                                        colLableElement1.appendChild(labelElement1);
                                        labelElement1.appendChild(node1);
                                        colLableElement1.appendChild(inputElement1);

                                        // For From
                                        var colElement2 = document.createElement('div');
                                        colElement2.className = "col-lg-1 col-md-1 col-xlg-1";

                                        var colLableElement2 = document.createElement('div');
                                        colLableElement2.className = "form-group label-black label-floating is-focused";

                                        var labelElement2 = document.createElement('label');
                                        labelElement2.className = "control-label";
                                        var node2 = document.createTextNode("From");

                                        var inputElement2 = document.createElement('input');
                                        inputElement2.type = 'text';
                                        inputElement2.className = 'form-control';
                                        inputElement2.id = 'from' + i;
                                        inputElement2.value = JSONData[i]['Category'] ? JSONData[i]['Category'] : '';
                                        // var array2 = ["RMS/Plant", "FOC/CD/SIR", "PROTO", "FBR/PO", "GR", "Other"];
                                        // var inputElement2 = document.createElement('select');
                                        // inputElement2.className = 'form-control';
                                        // inputElement2.id = 'from' + i;
                                        // for (var index = 0; index < array2.length; index++) {
                                        //     var option = document.createElement("option");
                                        //     option.setAttribute("value", array2[index]);
                                        //     option.text = array2[index];
                                        //     inputElement2.appendChild(option);
                                        // }

                                        rowElement.appendChild(colElement2);
                                        colElement2.appendChild(colLableElement2);
                                        colLableElement2.appendChild(labelElement2);
                                        labelElement2.appendChild(node2);
                                        colLableElement2.appendChild(inputElement2);

                                        // For GR No
                                        var colElement3 = document.createElement('div');
                                        colElement3.className = "col-lg-1 col-md-1 col-xlg-1";

                                        var colLableElement3 = document.createElement('div');
                                        colLableElement3.className = "form-group label-black label-floating is-focused";

                                        var labelElement3 = document.createElement('label');
                                        labelElement3.className = "control-label";
                                        var node3 = document.createTextNode("GR No");

                                        var inputElement3 = document.createElement('input');
                                        inputElement3.type = 'text';
                                        inputElement3.className = 'form-control';
                                        inputElement3.value = JSONData[i]['Material Document'] ? JSONData[i]['Material Document'] : '';
                                        inputElement3.id = 'grno' + i;

                                        rowElement.appendChild(colElement3);
                                        colElement3.appendChild(colLableElement3);
                                        colLableElement3.appendChild(labelElement3);
                                        labelElement3.appendChild(node3);
                                        colLableElement3.appendChild(inputElement3);

                                        // For Vender
                                        var colElement4 = document.createElement('div');
                                        colElement4.className = "col-lg-1 col-md-1 col-xlg-1";

                                        var colLableElement4 = document.createElement('div');
                                        colLableElement4.className = "form-group label-black label-floating is-focused";

                                        var labelElement4 = document.createElement('label');
                                        labelElement4.className = "control-label";
                                        var node4 = document.createTextNode("Vendor");

                                        var inputElement4 = document.createElement('input');
                                        inputElement4.type = 'text';
                                        inputElement4.className = 'form-control';
                                        inputElement4.id = 'vendor' + i;
                                        inputElement4.value = JSONData[i]['Vendor Name'] ? JSONData[i]['Vendor Name'] : '';

                                        rowElement.appendChild(colElement4);
                                        colElement4.appendChild(colLableElement4);
                                        colLableElement4.appendChild(labelElement4);
                                        labelElement4.appendChild(node4);
                                        colLableElement4.appendChild(inputElement4);

                                        // For Packaging
                                        var colElement5 = document.createElement('div');
                                        colElement5.className = "col-lg-1 col-md-1 col-xlg-1";

                                        var colLableElement5 = document.createElement('div');
                                        colLableElement5.className = "form-group label-black label-floating is-focused";

                                        var labelElement5 = document.createElement('label');
                                        labelElement5.className = "control-label";
                                        var node5 = document.createTextNode("Packing");

                                        var inputElement5 = document.createElement('input');
                                        inputElement5.type = 'text';
                                        inputElement5.className = 'form-control';
                                        inputElement5.value = JSONData[i]['Packing'] ? JSONData[i]['Packing'] : '';
                                        inputElement5.id = 'packing' + i;

                                        rowElement.appendChild(colElement5);
                                        colElement5.appendChild(colLableElement5);
                                        colLableElement5.appendChild(labelElement5);
                                        labelElement5.appendChild(node5);
                                        colLableElement5.appendChild(inputElement5);

                                        // For BIN ID
                                        var colElement6 = document.createElement('div');
                                        colElement6.className = "col-lg-1 col-md-1 col-xlg-1";

                                        var colLableElement6 = document.createElement('div');
                                        colLableElement6.className = "form-group label-black label-floating is-focused";

                                        var labelElement6 = document.createElement('label');
                                        labelElement6.className = "control-label";
                                        var node6 = document.createTextNode("BIN ID");

                                        var inputElement6 = document.createElement('input');
                                        inputElement6.type = 'text';
                                        inputElement6.className = 'form-control';
                                        inputElement6.value = JSONData[i]['Bin ID'] ? JSONData[i]['Bin ID'] : '';
                                        inputElement6.id = 'binid' + i;

                                        // var array6 = JSON.parse(localStorage.getItem('BINID'));
                                        // var inputElement6 = document.createElement('select');
                                        // inputElement6.className = 'form-control';
                                        // inputElement6.id = 'binid' + i;
                                        // inputElement6.addEventListener('change',function(e){

                                        // })
                                        // var option: HTMLOptionElement;
                                        // for (var index = 0; index < array6.length; index++) {
                                        //     option = document.createElement("option");
                                        //     option.setAttribute("value", array6[index].value);
                                        //     option.text = array6[index].label;
                                        //     inputElement6.appendChild(option);
                                        // }
                                        // option.setAttribute("value", JSONData[i]['Bin ID'] ? JSONData[i]['Bin ID'] : '');
                                        // option.text =  JSONData[i]['Bin ID'] ? JSONData[i]['Bin ID'] : '';

                                        rowElement.appendChild(colElement6);
                                        colElement6.appendChild(colLableElement6);
                                        colLableElement6.appendChild(labelElement6);
                                        labelElement6.appendChild(node6);
                                        colLableElement6.appendChild(inputElement6);

                                        // For BIN No
                                        var colElement7 = document.createElement('div');
                                        colElement7.className = "col-lg-1 col-md-1 col-xlg-1";

                                        var colLableElement7 = document.createElement('div');
                                        colLableElement7.className = "form-group label-black label-floating is-focused";

                                        var labelElement7 = document.createElement('label');
                                        labelElement7.className = "control-label";
                                        var node7 = document.createTextNode("BIN No");

                                        var inputElement7 = document.createElement('input');
                                        inputElement7.type = 'text';
                                        inputElement7.className = 'form-control';
                                        inputElement7.value = JSONData[i]['Bin no'] ? JSONData[i]['Bin no'] : '';
                                        inputElement7.id = 'binno' + i;
                                        // var array7 = ["1", "2", "11", "FBR/PO", "GR", "Other"];
                                        // var inputElement7 = document.createElement('select');
                                        // inputElement7.className = 'form-control';
                                        // inputElement7.id = 'binno' + i;
                                        // for (var index = 0; index < array7.length; index++) {
                                        //     var option = document.createElement("option");
                                        //     option.setAttribute("value", array7[index]);
                                        //     option.text = array7[index];
                                        //     inputElement7.appendChild(option);
                                        // }
                                        // inputElement6.value = JSONData[i]['Bin no'] ? JSONData[i]['Bin no'] : '';

                                        rowElement.appendChild(colElement7);
                                        colElement7.appendChild(colLableElement7);
                                        colLableElement7.appendChild(labelElement7);
                                        labelElement7.appendChild(node7);
                                        colLableElement7.appendChild(inputElement7);

                                        // For Desc
                                        var colElement10 = document.createElement('div');
                                        colElement10.className = "col-lg-2 col-md-2 col-xlg-2";

                                        var colLableElement10 = document.createElement('div');
                                        colLableElement10.className = "form-group label-black label-floating is-focused";

                                        var labelElement10 = document.createElement('label');
                                        labelElement10.className = "control-label";
                                        var node10 = document.createTextNode("Desc");

                                        var inputElement10 = document.createElement('input');
                                        inputElement10.type = 'text';
                                        inputElement10.className = 'form-control';
                                        inputElement10.value = JSONData[i]['Short Text'] ? JSONData[i]['Short Text'] : '';
                                        inputElement10.id = 'desc' + i;

                                        rowElement.appendChild(colElement10);
                                        colElement10.appendChild(colLableElement10);
                                        colLableElement10.appendChild(labelElement10);
                                        labelElement10.appendChild(node10);
                                        colLableElement10.appendChild(inputElement10);

                                        // For Date
                                        var colElement8 = document.createElement('div');
                                        colElement8.className = "col-lg-1 col-md-1 col-xlg-1";

                                        var colLableElement8 = document.createElement('div');
                                        colLableElement8.className = "form-group label-black label-floating is-focused";

                                        var labelElement8 = document.createElement('label');
                                        labelElement8.className = "control-label";
                                        var node8 = document.createTextNode("Date");

                                        var inputElement8 = document.createElement('input');
                                        inputElement8.type = 'date';
                                        inputElement8.className = 'form-control';
                                        inputElement8.id = 'date' + i;
                                        inputElement8.value = new Date().toISOString();

                                        rowElement.appendChild(colElement8);
                                        colElement8.appendChild(colLableElement8);
                                        colLableElement8.appendChild(labelElement8);
                                        labelElement8.appendChild(node8);
                                        colLableElement8.appendChild(inputElement8);

                                        // For RMS NO
                                        var colElement9 = document.createElement('div');
                                        colElement9.className = "col-lg-1 col-md-1 col-xlg-1";

                                        var colLableElement9 = document.createElement('div');
                                        colLableElement9.className = "form-group label-black label-floating is-focused";

                                        var labelElement9 = document.createElement('label');
                                        labelElement9.className = "control-label";
                                        var node9 = document.createTextNode("RMS No");

                                        var inputElement9 = document.createElement('input');
                                        inputElement9.type = 'text';
                                        inputElement9.className = 'form-control';
                                        inputElement9.value = JSONData[i]['RMS number'] ? JSONData[i]['RMS number'] : '';
                                        inputElement9.id = 'rmsno' + i;

                                        rowElement.appendChild(colElement9);
                                        colElement9.appendChild(colLableElement9);
                                        colLableElement9.appendChild(labelElement9);
                                        labelElement9.appendChild(node9);
                                        colLableElement9.appendChild(inputElement9);

                                        var element = document.getElementById("form1");
                                        element.appendChild(rowElement);

                                    }
                                }
                            };
                            reader.readAsArrayBuffer(f);
                        } else {
                            this._messageService.addMessage({
                                severity: 'error', summary: 'Error Message',
                                detail: 'Please remove special characters from filename'
                            });
                        }
                    } else {
                        this._messageService.addMessage({
                            severity: 'error', summary: 'Error Message',
                            detail: 'Please upload document of type of supperted type'
                        });
                    }
                } else {
                    this._messageService.addMessage({
                        severity: 'error', summary: 'Error Message',
                        detail: 'Please upload document of size less than 2 MB'
                    });
                }
            } else {
                this.fileName = '';
            }
        } catch (error) {
            document.write(error);
        }
    }
    /**General Functions */
    addMaterial() {
        let count;
        count = this.materialInfo.length + 1;
        let itemObj = {};
        let itemObj1 = {};
        if (this.itemcode !== '') {
            this.showItemCodeErr = false;
            if (this.quantity !== 0 && this.quantity !== '' && this.quantity !== null) {
                this.showQuantityErr = false;
                if (this.from === 'RMS/PLANT' && this.rmsno === '') {
                    this.showRMSNOErr = true;
                } else {
                    this.showRMSNOErr = false;
                    if (this.rmsno !== '' && this.rmsno !== null) {
                        this._commonService.getRMSTransactionByRMSIDandItemID(this.itemcode, this.rmsno)
                            .subscribe(
                            (results: any) => {
                                if (Object.keys(results).length > 0) {
                                    if (results.QTY_Received === null && this.quantity > Number(results.QTY_Required)) {
                                        itemObj = {
                                            'id': count,
                                            'ItemCode': this.itemcode ? this.itemcode.replace(/'/g, "\\'").trim() : '',
                                            'Qty': Number(results.QTY_Required),
                                            'From': this.from,
                                            'GRNumber': this.grno ? this.grno.replace(/'/g, "\\'").trim() : '',
                                            'Vendor': this.vendor ? this.vendor.replace(/'/g, "\\'").trim() : '',
                                            'Packing': this.packing ? this.packing.replace(/'/g, "\\'").trim() : '',
                                            'BINID': this.binid,
                                            'BINNO': this.binno,
                                            'Description': this.desc ? this.desc.replace(/'/g, "\\'").trim() : '',
                                            'Date': this.date,
                                            'RMSNO': this.rmsno ? this.rmsno.replace(/'/g, "\\'").trim() : ''
                                        };
                                        this.materialInfo.push(itemObj);
                                        let itemObj1 = {
                                            'id': count + 1,
                                            'ItemCode': this.itemcode ? this.itemcode.replace(/'/g, "\\'").trim() : '',
                                            'Qty': this.quantity - Number(results.QTY_Required),
                                            'From': this.from,
                                            'GRNumber': this.grno ? this.grno.replace(/'/g, "\\'").trim() : '',
                                            'Vendor': this.vendor ? this.vendor.replace(/'/g, "\\'").trim() : '',
                                            'Packing': this.packing ? this.packing.replace(/'/g, "\\'").trim() : '',
                                            'BINID': this.binid,
                                            'BINNO': this.binno,
                                            'Description': this.desc ? this.desc.replace(/'/g, "\\'").trim() : '',
                                            'Date': this.date,
                                        };
                                        this.materialInfo.push(itemObj1);
                                        this.itemcode = '';
                                        this.quantity = '';
                                        this.grno = '';
                                        this.vendor = '';
                                        this.packing = '';
                                        this.desc = '';
                                        this.rmsno = '';
                                        this.binid = 'Floor Area';
                                        this.binno = '';
                                        this.from = 'FBR/PO';
                                        this.materialInfoErr = false;

                                    } else if (this.quantity === Number(results.QTY_Received)) {
                                        itemObj = {
                                            'id': count,
                                            'ItemCode': this.itemcode ? this.itemcode.replace(/'/g, "\\'").trim() : '',
                                            'Qty': this.quantity,
                                            'From': this.from,
                                            'GRNumber': this.grno ? this.grno.replace(/'/g, "\\'").trim() : '',
                                            'Vendor': this.vendor ? this.vendor.replace(/'/g, "\\'").trim() : '',
                                            'Packing': this.packing ? this.packing.replace(/'/g, "\\'").trim() : '',
                                            'BINID': this.binid,
                                            'BINNO': this.binno,
                                            'Description': this.desc ? this.desc.replace(/'/g, "\\'").trim() : '',
                                            'Date': this.date,

                                        };
                                        this.materialInfo.push(itemObj);
                                        this.itemcode = '';
                                        this.quantity = '';
                                        this.grno = '';
                                        this.vendor = '';
                                        this.packing = '';
                                        this.desc = '';
                                        this.rmsno = '';
                                        this.binid = 'Floor Area';
                                        this.binno = '';
                                        this.from = 'FBR/PO';
                                        this.materialInfoErr = false;
                                    } else if ((Number(results.QTY_Received) + this.quantity) > Number(results.QTY_Required)) {

                                        itemObj = {
                                            'id': count,
                                            'ItemCode': this.itemcode ? this.itemcode.replace(/'/g, "\\'").trim() : '',
                                            'Qty': Number(results.QTY_Required),
                                            'From': this.from,
                                            'GRNumber': this.grno ? this.grno.replace(/'/g, "\\'").trim() : '',
                                            'Vendor': this.vendor ? this.vendor.replace(/'/g, "\\'").trim() : '',
                                            'Packing': this.packing ? this.packing.replace(/'/g, "\\'").trim() : '',
                                            'BINID': this.binid,
                                            'BINNO': this.binno,
                                            'Description': this.desc ? this.desc.replace(/'/g, "\\'").trim() : '',
                                            'Date': this.date,
                                            'RMSNO': this.rmsno ? this.rmsno.replace(/'/g, "\\'").trim() : ''
                                        };
                                        this.materialInfo.push(itemObj);
                                        let qty = this.quantity - Number(results.QTY_Received);
                                        let itemObj1 = {
                                            'id': count + 1,
                                            'ItemCode': this.itemcode ? this.itemcode.replace(/'/g, "\\'").trim() : '',
                                            'Qty': qty,
                                            'From': this.from,
                                            'GRNumber': this.grno ? this.grno.replace(/'/g, "\\'").trim() : '',
                                            'Vendor': this.vendor ? this.vendor.replace(/'/g, "\\'").trim() : '',
                                            'Packing': this.packing ? this.packing.replace(/'/g, "\\'").trim() : '',
                                            'BINID': this.binid,
                                            'BINNO': this.binno,
                                            'Description': this.desc ? this.desc.replace(/'/g, "\\'").trim() : '',
                                            'Date': this.date,
                                        };
                                        this.materialInfo.push(itemObj1);

                                        this.itemcode = '';
                                        this.quantity = '';
                                        this.grno = '';
                                        this.vendor = '';
                                        this.packing = '';
                                        this.desc = '';
                                        this.rmsno = '';
                                        this.binid = 'Floor Area';
                                        this.binno = '';
                                        this.from = 'FBR/PO';
                                        this.materialInfoErr = false;
                                    } else {
                                        itemObj = {
                                            'id': count,
                                            'ItemCode': this.itemcode ? this.itemcode.replace(/'/g, "\\'").trim() : '',
                                            'Qty': this.quantity,
                                            'From': this.from,
                                            'GRNumber': this.grno ? this.grno.replace(/'/g, "\\'").trim() : '',
                                            'Vendor': this.vendor ? this.vendor.replace(/'/g, "\\'").trim() : '',
                                            'Packing': this.packing ? this.packing.replace(/'/g, "\\'").trim() : '',
                                            'BINID': this.binid,
                                            'BINNO': this.binno,
                                            'Description': this.desc ? this.desc.replace(/'/g, "\\'").trim() : '',
                                            'Date': this.date,
                                            'RMSNO': this.rmsno ? this.rmsno.replace(/'/g, "\\'").trim() : ''
                                        };
                                        this.materialInfo.push(itemObj);
                                        this.itemcode = '';
                                        this.quantity = '';
                                        this.grno = '';
                                        this.vendor = '';
                                        this.packing = '';
                                        this.desc = '';
                                        this.rmsno = '';
                                        this.binid = 'Floor Area';
                                        this.binno = '';
                                        this.from = 'FBR/PO';
                                        this.materialInfoErr = false;
                                    }
                                }
                                else {
                                    itemObj = {
                                        'id': count,
                                        'ItemCode': this.itemcode ? this.itemcode.replace(/'/g, "\\'").trim() : '',
                                        'Qty': this.quantity,
                                        'From': this.from,
                                        'GRNumber': this.grno ? this.grno.replace(/'/g, "\\'").trim() : '',
                                        'Vendor': this.vendor ? this.vendor.replace(/'/g, "\\'").trim() : '',
                                        'Packing': this.packing ? this.packing.replace(/'/g, "\\'").trim() : '',
                                        'BINID': this.binid,
                                        'BINNO': this.binno,
                                        'Description': this.desc ? this.desc.replace(/'/g, "\\'").trim() : '',
                                        'Date': this.date,
                                        'RMSNO': this.rmsno ? this.rmsno.replace(/'/g, "\\'").trim() : ''
                                    };
                                    this.materialInfo.push(itemObj);
                                    this.itemcode = '';
                                    this.quantity = '';
                                    this.grno = '';
                                    this.vendor = '';
                                    this.packing = '';
                                    this.desc = '';
                                    this.rmsno = '';
                                    this.binid = 'Floor Area';
                                    this.binno = '';
                                    this.from = 'FBR/PO';
                                    this.materialInfoErr = false;
                                }
                            },
                            error => {
                                this.errorMessage = <any>error;
                                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                            });
                    } else {
                        itemObj = {
                            'id': count,
                            'ItemCode': this.itemcode ? this.itemcode.replace(/'/g, "\\'").trim() : '',
                            'Qty': this.quantity,
                            'From': this.from,
                            'GRNumber': this.grno ? this.grno.replace(/'/g, "\\'").trim() : '',
                            'Vendor': this.vendor ? this.vendor.replace(/'/g, "\\'").trim() : '',
                            'Packing': this.packing ? this.packing.replace(/'/g, "\\'").trim() : '',
                            'BINID': this.binid,
                            'BINNO': this.binno,
                            'Description': this.desc ? this.desc.replace(/'/g, "\\'").trim() : '',
                            'Date': this.date,
                        };
                        this.materialInfo.push(itemObj);
                        this.itemcode = '';
                        this.quantity = '';
                        this.grno = '';
                        this.vendor = '';
                        this.packing = '';
                        this.desc = '';
                        this.rmsno = '';
                        this.binid = 'Floor Area';
                        this.binno = '';
                        this.from = 'FBR/PO';
                        this.materialInfoErr = false;
                    }
                }
            } else {
                this.showQuantityErr = true;
            }
        } else {
            this.showItemCodeErr = true;
        }
    }

    onDeleteMaterialInfo(item: any) {
        let index = this.materialInfo.indexOf(item);
        this.materialInfo.splice(index, 1);
    }
    onEditMaterialInfo(item: any) {
        this.itemcode = item.ItemCode;
        this.quantity = item.Qty;
        this.from = item.From;
        this.grno = item.GRNumber;
        this.vendor = item.Vendor;
        this.packing = item.Packing;
        this.binno = item.BINID;
        this.binid = item.BINNO;
        this.desc = item.Description;
        this.date = item.Date;
        this.rmsno = item.RMSNO;
        let index = this.materialInfo.indexOf(item);
        this.materialInfo.splice(index, 1);
    }
    onSubmitRequest() {
        this.excelData = JSON.parse(localStorage.getItem('excel'));
        this.materialData = [];
        let itemCheck = false;
        for (let i = 0; i < this.excelData.length; i++) {
            var data = { 'ItemCode': '', 'Qty': '', 'From': '', 'GRNumber': '', 'Vendor': '', 'Packing': '', 'BINID': '', 'BINNO': '', 'Description': '', 'Date': '', 'RMSNO': '' };
            data = {
                'ItemCode': (<HTMLInputElement>document.getElementById('itemid' + i)).value,
                'Qty': (<HTMLInputElement>document.getElementById('quantity' + i)).value,
                'From': (<HTMLInputElement>document.getElementById('from' + i)).value,
                'GRNumber': (<HTMLInputElement>document.getElementById('grno' + i)).value,
                'Vendor': (<HTMLInputElement>document.getElementById('vendor' + i)).value,
                'Packing': (<HTMLInputElement>document.getElementById('packing' + i)).value,
                'BINID': (<HTMLInputElement>document.getElementById('binid' + i)).value,
                'BINNO': (<HTMLInputElement>document.getElementById('binno' + i)).value,
                'Description': (<HTMLInputElement>document.getElementById('desc' + i)).value,
                'Date': (<HTMLInputElement>document.getElementById('date' + i)).value,
                'RMSNO': (<HTMLInputElement>document.getElementById('rmsno' + i)).value
            }
            if (data.ItemCode === '') {
                itemCheck = true;
                var divElement = document.getElementById('checkItem');
                divElement.innerHTML = 'Please enter value for Item Code at Row ' + (i + 1);
                divElement.className = "required";
                divElement.style.display = 'block';
                divElement.style.marginTop = "10px";
                break;
            }
            if (data.Qty === '' || data.Qty === "0") {
                itemCheck = true;
                var divElement = document.getElementById('checkItem');
                divElement.innerHTML = 'Please enter valid value for Qty at Row ' + (i + 1);
                divElement.className = "required";
                divElement.style.display = 'block';
                divElement.style.marginTop = "10px";
                break;
            }
            if (data.From === 'RMS/PLANT' && data.RMSNO === '') {
                itemCheck = true;
                var divElement = document.getElementById('checkItem');
                divElement.innerHTML = 'Please enter value for RMS NO at Row ' + (i + 1);
                divElement.className = "required";
                divElement.style.display = 'block';
                divElement.style.marginTop = "10px";
                break;
            }
            if (!itemCheck) {
                data.ItemCode = data.ItemCode ? data.ItemCode.replace(/'/g, "\\'").trim() : '';
                data.GRNumber = data.GRNumber ? data.GRNumber.replace(/'/g, "\\'").trim() : '';
                data.Vendor = data.Vendor ? data.Vendor.replace(/'/g, "\\'").trim() : '';
                data.Packing = data.Packing ? data.Packing.replace(/'/g, "\\'").trim() : '';
                data.Description = data.Description ? data.Description.replace(/'/g, "\\'").trim() : '';
                data.RMSNO = data.RMSNO ? data.RMSNO.replace(/'/g, "\\'").trim() : '';
                this.materialData.push(data);
            }
        }
        if (!itemCheck) {
            var divElement = document.getElementById('checkItem');
            divElement.style.display = 'none';
            this._materialService.AddItems(this.materialData)
                .subscribe(
                (results: any) => {
                    if (results.StatusCode === 1) {
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        document.getElementById('addform').style.display = 'none';
                    }
                    if (results.StatusCode === 2) {
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: results.Message });
                    }
                    document.getElementById('file_input_file')[0].value = '';
                    // $('#file_input_file')[0].value = '';
                    this.getItemList();
                },
                error => {
                    this.errorMessage = <any>error;
                    this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                });
        }
    }
    onSubmitRequest2() {
        if (this.materialInfo.length > 0) {
            this.materialInfoErr = false;
            this._materialService.AddItems(this.materialInfo)
                .subscribe(
                (results: any) => {
                    if (results.StatusCode === 1) {
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        document.getElementById('addform').style.display = 'none';
                    }
                    if (results.StatusCode === 2) {
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: results.Message });
                    }
                   
                    this.getItemList();
                },
                error => {
                    this.errorMessage = <any>error;
                    this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                });
        }
        else {
            this.materialInfoErr = true;
        }
    }
    onSubmitUpdateForm() {
        if (this.EditData.ItemCode !== '') {
            this.showItemCodeErr = false;
            if (this.EditData.Qty !== 0 && this.EditData.Qty !== '' && this.EditData.Qty !== null) {
                this.showQuantityErr = false;
                if (this.EditData.From === 'RMS/PLANT' && this.EditData.RMSNO === null) {
                    this.showRMSNOErr = true;
                } else {
                    this._materialService.UpdateItems(this.EditData)
                        .subscribe(
                        (results: any) => {
                            if (results.StatusCode === 1) {
                                this._messageService.addMessage({
                                    severity: 'success',
                                    summary: 'Success Message', detail: results.Message
                                });
                                document.getElementById('addform').style.display = 'none';
                            }
                            if (results.StatusCode === 2) {
                                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: results.Message });
                            }
                            this.getItemList();
                        },
                        error => {
                            this.errorMessage = <any>error;
                            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                        });
                }
            } else {
                this.showQuantityErr = true;
            }
        } else {
            this.showItemCodeErr = true;
        }
    }
    onSubmitSearchItemCode({ value, valid }: { value: any, valid: boolean }) {
        if (valid) {
            this.errFlag = false;
            this.IPMRData = [];
            value.ItemCode = value.ItemCode.trim();
            this._materialService.getSearchItemCode(value.ItemCode)
                .subscribe(
                (results: any) => {
                    if (results.length > 0) {
                        this.IPMRData = results;
                    }
                },
                error => {
                    this.errorMessage = <any>error;
                    this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                });
        } else {
            this.errFlag = true;
        }
    }
    onCancelForm() {
        this.fileName = '';
        localStorage.clear();
        this.filesData = [];
        document.getElementById('addform').style.display = 'none';
        document.getElementById('file_input_file')[0].value = '';
        // $('#file_input_file')[0].value = '';

    }
    onCancelEditForm() {
        this.fileName = '';
        document.getElementById('addform').style.display = 'none';
        this.showEditForm = false
        document.getElementById('file_input_file')[0].value = '';
        // $('#file_input_file')[0].value = '';
    }
    onCancelSearchItemCode() {
        this.showSearchItemCode = false;
        this.getItemList();
    }
}