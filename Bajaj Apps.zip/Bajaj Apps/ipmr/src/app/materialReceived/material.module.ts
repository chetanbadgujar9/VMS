import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialComponent } from './components/material.component';
import { MaterialRoutingModule } from './material-routing.module';
import { BrowserModule } from '@angular/platform-browser';
import { SharedModule } from '../shared/shared.module';
import { MaterialService } from './services/material.service';
@NgModule({
    imports: [CommonModule, MaterialRoutingModule, SharedModule],
    declarations: [MaterialComponent],
    exports: [MaterialComponent],
    providers: [MaterialService]
})
export class MaterialModule { }
