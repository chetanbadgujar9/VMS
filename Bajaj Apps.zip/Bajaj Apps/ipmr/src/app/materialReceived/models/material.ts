export class Material {
    constructor(
        public BINID: any,
        public BINNO: any,
        public Date: string,
        public Description: any,
        public From: any,
        public GRNumber: any,
        public ID: any,
        public ItemCode: string,
        public Location: string,
        public Month: string,
        public Packing: Date,
        public Qty: string,
        public RMSNO: string,
        public Remarks: any,
        public RequestNumber: any,
        public SrNo: any,
        public Year: any,
        public Requester:
            {
                ID: string,
                Name: string
            }
    ) { }
}
