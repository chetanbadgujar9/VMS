/* angular dependencies */
import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/finally';

/** Third party dependencies */
import { AuthHttp } from '../../shared/services/authHttp.service';
import { Config } from '../../shared/config/config';
import { SpinnerService } from '../../shared/spinner/spinner.service';

@Injectable()
export class MaterialService {
    progress: any;
    progressObserver: any;
    constructor(private http: Http,
        private authHttp: AuthHttp,
        private _spinnerService: SpinnerService) {
    }

    getMyTestData() {
        let url = Config.GetURL('/Register/getHeight');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }

    getItemList() {
        let url = Config.GetURL('/api/IPMR/StoreMaterialReceived/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }

    AddItems(payload: any) {
        let url = Config.GetURL('/api/IPMR/StoreMaterialReceived/BulkAddStoreMaterialReceived');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    UpdateItems(payload: any) {
        let url = Config.GetURL('/api/IPMR/StoreMaterialReceived/UpdateStoreMaterialReceivedByID');
        this._spinnerService.show();
        return this.authHttp.post(url, payload)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getSearchItemCode(itemcode: any) {
        let url = Config.GetURL('/api/IPMR/StoreMaterialReceived/GetStoreMaterialByItemCode?itemCode=' + itemcode);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    /**Success Handler */
    private extractData(res: Response) {
        if (res.status < 200 || res.status >= 300) {
            throw new Error('Bad response status: ' + res.status);
        }
        let body = res.json();
        return body || {};
    }
    private extractDataForValidate(res: Response) {
        if (res.status < 200 || res.status >= 300) {
            throw new Error('Bad response status: ' + res.status);
        }
        let body = res.json();
        return body || false;
    }
    /**Error Handler */
    private handleError(error: Response) {
       // console.log(error);
        return Observable.throw(error.json().error || 'Server error');
    }
}
