import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MessageService } from '../../shared/services/message.service';
import { CommonService } from '../../shared/services/common.service';
import { DashboardService } from '../../dashboard/services/dashboard.service';
import { StoreModel } from '../../dashboard/models/storeModel';
@Component({
    moduleId: module.id,
    selector: 'sd-searchrms',
    templateUrl: 'searchRMS.component.html',
    styleUrls: ['searchRMS.component.css']
})

export class SearchRMSComponent implements OnInit {
    searchRMSForm: FormGroup;
    showErr: boolean = false;
    errFlag: boolean = false;
    IPMRData: any = [];
    _searchBy: string;
    errorMessage: any;
    constructor(private formBuilder: FormBuilder, private _router: Router,
        private _messageService: MessageService,
        private _commonService: CommonService,
        private _dashboardService: DashboardService) {
    }
    ngOnInit() {
        this.setsearchRMSForm();
        this.searchBy('RMSNo');
    }
    setsearchRMSForm() {
        this.searchRMSForm = this.formBuilder.group({
            RMSID: ['', [Validators.required]]
        });
    }
    onSubmit({ value, valid }: { value: any, valid: boolean }) {
        if (valid) {
            this.IPMRData = [];
            value.RMSID = value.RMSID ? value.RMSID.trim() : '';
            if (this._searchBy === 'RMSNo') {
                this._dashboardService.searchMultipleItemsByRMSID(value)
                    .subscribe(
                    (results: any) => {
                        if (results.length > 0) {
                            this.IPMRData = results;
                        }
                    },
                    (error: any) => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            } else {
                this._dashboardService.getSearchResultByItemID(value.RMSID)
                    .subscribe(
                    (results: any) => {
                        if (results.length > 0) {
                            this.IPMRData = results;
                        }
                    },
                    (error: any) => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
        } else {
            this.errFlag = true;
        }
    }

    searchBy(value: string) {
        this._searchBy = value;
        this.setsearchRMSForm();
        this.IPMRData = [];
        console.log(this._searchBy);
    }
}
