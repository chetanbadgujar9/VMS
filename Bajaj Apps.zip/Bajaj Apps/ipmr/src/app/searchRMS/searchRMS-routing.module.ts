import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SearchRMSComponent } from './components/searchRMS.component';

@NgModule({
  imports: [
    RouterModule.forChild([
      { path: 'searchRMSItem', component: SearchRMSComponent }
    ])
  ],
  exports: [RouterModule]
})
export class SearchRMSRoutingModule { }
