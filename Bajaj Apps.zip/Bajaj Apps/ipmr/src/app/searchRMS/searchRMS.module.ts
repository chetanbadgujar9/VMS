import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SearchRMSComponent } from './components/searchRMS.component';
import { SearchRMSRoutingModule } from './searchRMS-routing.module';
import { BrowserModule } from '@angular/platform-browser';
import { SharedModule } from '../shared/shared.module';
@NgModule({
    imports: [CommonModule, SearchRMSRoutingModule, SharedModule],
    declarations: [SearchRMSComponent],
    exports: [SearchRMSComponent],
    providers: []
})
export class SearchRMSModule { }
