import { Component, OnInit } from '@angular/core';
import { Location, LocationStrategy, PathLocationStrategy } from '@angular/common';
import { Router } from '@angular/router';

/**
 * This class represents the navigation bar component.
 */
@Component({
  moduleId: module.id,
  selector: 'sd-navbar',
  templateUrl: 'navbar.component.html',
  styleUrls: ['navbar.component.css'],
})
export class NavbarComponent implements OnInit {
  currentURL: string;
  loggedInUserName: string;
  constructor(private router: Router) { }
  ngOnInit() {
    this.currentURL = sessionStorage.getItem('currentURL');
    this.loggedInUserName = sessionStorage.getItem('UserTitle');
  }
  onSignInDiffUser() {
    localStorage.clear();
    sessionStorage.clear();
    window.location.href = this.currentURL + '/_layouts/15/closeConnection.aspx?loginasanotheruser=true';
  }
  onSignOut() {
    localStorage.clear();
    sessionStorage.clear();
    window.location.href = this.currentURL + '/_layouts/15/signout.aspx';
  }
  onAboutMe() {
    this.router.navigate(['/aboutMe']);
  }
  onTitleClick() {
      //window.location.reload();
      this.router.navigate(['/']);
  }
}
