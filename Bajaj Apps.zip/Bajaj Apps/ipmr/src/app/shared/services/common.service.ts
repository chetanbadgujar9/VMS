/* angular dependencies */
import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/finally';
import { Router } from '@angular/router';

/** Third party dependencies */
import { SpinnerService } from '../spinner/spinner.service';
import { Config } from '../config/config';
import { AuthHttp } from '../services/authHttp.service';
import { AuthInfo } from '../../dashboard/models/authInfo';

@Injectable()
export class CommonService {
    http: Http;
    constructor(http: Http,
        private authHttp: AuthHttp,
        private _spinnerService: SpinnerService,
        private router: Router) {
        this.http = http;
    }
    onTitleClick() {
        this.router.navigate(['/brand']);
    }
    //Get user auth token
    getAuthToken(credentials: AuthInfo) {
        let authenticateUrl = Config.GetURL('/api/Auth/Token');
        let headers = new Headers();
        let credentialString: string = 'grant_type=password&username=' + credentials.UserName + '&password=' + credentials.Password;
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let options = new RequestOptions({ headers: headers });
        return this.http.post(authenticateUrl, credentialString, options)
            .map((res: Response) => {
                this.setToken(res); //this.emitAuthEvent(true);
            })
            .catch(this.handleError);
    }

    //Get Logged In User Data
    getLoggedInUserDetails(username: any) {
        let url = Config.GetURL('/api/testrequest/BALRMSUGP/GetUGPDetailsByUserName?userName=' + username);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getCurrentUserGroup(id:any) {
        let url = Config.GetURL('/api/IPMR/BALRMSUGP/GetCurrentUserGroupByID/' + id);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }

    //  To get Group master
    getSystemMaster() {
        let url = Config.GetURL('/api/TestRequest/GroupMaster/GetGroupNames');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getSystem() {
        let url = Config.GetURL('/api/testrequest/GroupMaster/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }

    // To get subSytems of Systems
    getSubSystem(system: any) {
        let url = Config.GetURL('/api/testrequest/GroupMaster/GetSubGroupByGroupName?groupName=' + system);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    //  To get Stage master
    getStageMaster() {
        let url = Config.GetURL('/api/testrequest/StageMaster/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }

    //  To get Test Type master
    getTestType() {
        let url = Config.GetURL('/api/testrequest/TestTypeMaster/GetTestTypes');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getTestTypeData() {
        let url = Config.GetURL('/api/testrequest/TestTypeMaster/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    //To get sub Type of types
    getSubTypeOfSubType(type: any) {
        let url = Config.GetURL('/api/testrequest/TestTypeMaster/GetTestSubTypeByTestType?testType=' + type);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    // To get Vehicle model
    getVehicleModel() {
        let url = Config.GetURL('/api/testrequest/VehicleModelMaster/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }

    // To get brand data
    getBrandData() {
        let url = Config.GetURL('/api/rms/BPM/GetBrandNames');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }

    // To get project data
    getProject(brand: any) {
        let url = Config.GetURL('/api/rms/BPM/GetProjectByBrandName?brandName=' + brand);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }

    // Users 
    getAssignToUsers(username: string) {
        let url = Config.GetURL('/api/ahead/UserInformationList/GetUserInformationListByName?userName=' + username);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getBrandNames() {
        let url = Config.GetURL('/api/testrequest/BPM/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getBrandsByNames() {
        let url = Config.GetURL('/api/IPMR/BPM/GetBrandNames');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    addBrand(value: any) {
        let url = Config.GetURL('/api/testrequest/BPM/Post');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    updateBrand(value: any) {
        let url = Config.GetURL('/api/testrequest/BPM/UpdateBrandProjectByID');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    deleteBrand(value: any) {
        let url = Config.GetURL('/api/IPMR/BPM/DeleteBrandProjectByID/' + value);
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getAllProject() {
        let url = Config.GetURL('/api/cachpurchase/ProjectMaster/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getProjectMaster() {
        let url = Config.GetURL('/api/cashpurchase/ProjectMaster/GetActiveProjectMaster');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    addProject(value: any) {
        let url = Config.GetURL('/api/cachpurchase/ProjectMaster/Post');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    updateProject(value: any) {
        let url = Config.GetURL('/api/cachpurchase/ProjectMaster/UpdateProjectMasterByID');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getRMSMenus() {
        let url = Config.GetURL('/api/CashPurchase/NavigationMaster/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    addRMSMenu(value: any) {
        let url = Config.GetURL('/api/IPMR/NavigationMaster/Post');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    updateRMSMenu(value: any) {
        let url = Config.GetURL('/api/IPMR/NavigationMaster/UpdateNavigationMasterByID');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    deleteRMSMenu(value: any) {
        let url = Config.GetURL('/api/IPMR/NavigationMaster/DeleteNavigationMasterByID/' + value);
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getUGPUserList() {
        let url = Config.GetURL('/api/IPMR/BALRMSUGP/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    //Get Admin Access
    getAdminAccess(username: any) {
        let url = Config.GetURL('/api/rms/farmadminusers/FarmAdminUsersByUserLoginName?userLoginName=' + username);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getMyData(username: any) {
        let url = Config.GetURL('/api/cashpurchase/RndUsers/GetRndUsersListByName?userName=' + username);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getBinList() {
        let url = Config.GetURL('/api/IPMR/Binlist/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    addBINList(value: any) {
        let url = Config.GetURL('/api/IPMR/Binlist/Post');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    updateBINList(value: any) {
        let url = Config.GetURL('/api/IPMR/Binlist/UpdateBinlistByID');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    deleteBINLISt(value: any) {
        let url = Config.GetURL('/api/IPMR/Binlist/DeleteBinlistByID/' + value);
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getBINID() {
        let url = Config.GetURL('/api/IPMR/Binlist/GetBINIDs');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getBINNO(binid: any) {
        let url = Config.GetURL('/api/IPMR/Binlist/GetBINNumberByBINID?binId=' + binid);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getFromList() {
        let url = Config.GetURL('/api/IPMR/FromMaster/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    addFrom(value: any) {
        let url = Config.GetURL('/api/IPMR/FromMaster/Post');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    updateFrom(value: any) {
        let url = Config.GetURL('/api/IPMR/FromMaster/UpdateFromMasterByID');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    deleteFrom(value: any) {
        let url = Config.GetURL('/api/IPMR/FromMaster/DeleteFromMasterByID/' + value);
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getPlantList() {
        let url = Config.GetURL('/api/IPMR/PlantMaster/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    addPlant(value: any) {
        let url = Config.GetURL('/api/IPMR/PlantMaster/Post');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    updatePlant(value: any) {
        let url = Config.GetURL('/api/IPMR/PlantMaster/UpdatePlantMasterByID');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    deletePlant(value: any) {
        let url = Config.GetURL('/api/IPMR/PlantMaster/DeletePlantMasterByID/' + value);
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getEmailmasterById(value: any) {
        let url = Config.GetURL('/api/IPMR/UserInformationList/GetUserInformationEMailListByEmail?email=' + value);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getUsermasterById(value: any) {
        let url = Config.GetURL('/api/IPMR/UserInformationList/GetUserInformationListByName?userName=' + value);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getDomainmasterById(value: any) {
        let url = Config.GetURL('/api/IPMR/UserInformationList/GetUserInformationDomainIDListByUserName?userName=' + value);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    addUserDetails(value: any) {
        let url = Config.GetURL('/api/IPMR/BALRMSUGP/Post');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    updateUserDetails(value: any) {
        let url = Config.GetURL('/api/testrequest/BALRMSUGP/UpdatePlantMasterByID');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getItemList() {
        let url = Config.GetURL('/api/IPMR/BALRMSItemInfo/Get');
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    validateItem(itemid: any) {
        let url = Config.GetURL('/api/IPMR/BALRMSItemInfo/GetItemInfoByPartNumber?partNumber=' + itemid);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    addItem(value: any) {
        let url = Config.GetURL('/api/IPMR/BALRMSItemInfo/Post');
        this._spinnerService.show();
        return this.authHttp.post(url, value)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    getRMSTransactionByRMSIDandItemID(itemid: any, rmsid: any) {
        let url = Config.GetURL('/api/IPMR/BALRMSItemslist/BALRMSTransactionByRMSIDAndItemID?rmsID=' + rmsid + '&itemID=' + itemid);
        this._spinnerService.show();
        return this.authHttp.get(url)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(() => this._spinnerService.hide());
    }
    /**Set Token in localstorage */
    private setToken(res: Response) {
        if (res.status < 200 || res.status >= 300) {
            throw new Error('Bad response status: ' + res.status);
        }
        let body = res.json();
        sessionStorage.setItem('access_token', body.access_token);
        return body || {};
    }

    /**Success Handler */
    private extractData(res: Response) {
        if (res.status < 200 || res.status >= 300) {
            throw new Error('Bad response status: ' + res.status);
        }
        let body = res.json();
        return body || {};
    }

    /**Error Handler */
    private handleError(error: Response) {
       // console.log(error);
        return Observable.throw(error.json().error || 'Server error');
    }

}
