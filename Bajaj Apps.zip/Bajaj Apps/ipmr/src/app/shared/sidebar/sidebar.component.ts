import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Config } from '../../shared/config/config';
import { MessageService } from '../services/message.service';
/**
 * This class represents the toolbar component.
 */
@Component({
  moduleId: module.id,
  selector: 'sd-sidebar',
  templateUrl: 'sidebar.component.html',
  styleUrls: ['sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  menuItems: any = [];
  rmsMenu: any = [];
  userRoles: any = [];
  show: boolean = false;
  showRMS: boolean = true;
  showAddItem: boolean = false;
  showRMSPart: boolean = false;
  showRMSPartPM: boolean = false;
  hasAdminAccess: boolean = false;
  constructor(private router: Router, private _messageService: MessageService) { }
  ngOnInit() {
    // System.import('../../../js/sidebar-moving-tab.js');
    this._messageService.getAdminAccess()
      .subscribe((value: any) => {
        this.hasAdminAccess = value;
      });
    this._messageService.getUserRole()
      .subscribe((value: any) => {
        if (value.indexOf('SM') >= 0 && value.indexOf('Stores') >= 0) {
          this.showAddItem = true;
        } else {
          this.showAddItem = false;
        }
        if (value.indexOf('Stores') >= 0) {
          this.showRMSPart = true;
        } else {
          this.showRMSPart = false;
        }
      });
    this._messageService.getUserGroup()
      .subscribe((value: any) => {
        // console.log('User Group');
        // console.log(value);
        if (value.indexOf('PROJECT MANAGEMENT') >= 0) {
          this.showRMSPartPM = true;
        } else {
          this.showRMSPartPM = false;
        }
      });

    this._messageService.getRMSMenu()
      .subscribe((value: any) => {
        this.rmsMenu = value;
      });
    this.menuItems = [{ path: '', title: 'Dashboard', icon: 'fa fa-home fa-fw', class: '' },
    { path: 'voucher', title: 'Reports', icon: 'fa fa-file-text fa-fw', class: '' },];
  }
  check() {
    // this.showRMS = false;
    if (this.show) {
      this.show = false;
    } else {
      this.show = true;
    }
  }
  checkRMSMenu() {
    this.show = false;
    if (this.showRMS) {
      this.showRMS = false;
    } else {
      this.showRMS = true;
    }
  }
  onLogoClick() {
    window.location.href = Config.getLogoURL();
  }
  onTitleClick() {
    this.router.navigate(['/']);
  }
  onRoute(route: any) {
    this.router.navigate([route]);
  }
  menuClick(route: any) {
    this.show = false;
    //this.showRMS = false;
    this.router.navigate([route]);
  }
}

