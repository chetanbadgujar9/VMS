import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MessageService } from '../../shared/services/message.service';
import { CommonService } from '../../shared/services/common.service';
import { DashboardService } from '../../dashboard/services/dashboard.service';
import { StoreModel } from '../../dashboard/models/storeModel';
@Component({
    moduleId: module.id,
    selector: 'sd-updateRMS',
    templateUrl: 'updateRMS.component.html',
    styleUrls: ['updateRMS.component.css']
})

export class UpdateRMSComponent implements OnInit {
    UpdateForm: FormGroup;
    showErr: boolean = false;
    IPMRData: StoreModel;
    errorMessage: any;
    rmsno: any = '';
    partno: any = '';
    constructor(private formBuilder: FormBuilder, private _router: Router,
        private _messageService: MessageService,
        private _commonService: CommonService,
        private _dashboardService: DashboardService) {
    }
    ngOnInit() {
        this.setUpdateForm();
    }
    setUpdateForm() {
        this.UpdateForm = this.formBuilder.group({
            RequestId: ['', [Validators.required]],
            OldItemId: ['', [Validators.required]],
            NewItemId: ['', [Validators.required]]
        });
    }
    searchRMS(rmsno: any) {
        if (rmsno !== '') {
            let val = { 'RequestID': rmsno };
            this._dashboardService.getSearchResult(val)
                .subscribe(
                (results: any) => {
                    if (results.ID != 0) {
                        var valid = document.getElementById('validation');
                        valid.style.display = 'none';
                        this.IPMRData = results;
                    }
                    else {
                        var valid = document.getElementById('validation');
                        valid.className = "required";
                        valid.innerHTML = "RMS NO Not Found";
                        valid.style.display = 'block';
                    }
                },
                error => {
                    this.errorMessage = <any>error;
                    this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                });
        }
    }
    searchPart(partno: any) {
        if (partno !== '') {
            let check;
            for (let i = 0; i < this.IPMRData.Items.length; i++) {
                if (partno === this.IPMRData.Items[i].Item_ID) {
                    var valid = document.getElementById('validation');
                    valid.style.display = 'none';
                    break;
                } else {
                    check = true;
                }
            }
            if (check) {
                var valid = document.getElementById('validation');
                valid.className = "required";
                valid.innerHTML = "Part NO Not Found";
                valid.style.display = 'block';
            }
        }

    }
    validateItemIDLength(num: any) {
        let maxlength = 15;
        if (maxlength >= num.toString().length) {

        }
        else {
            this.rmsno = num.toString().substr(0, num.toString().length - 1);
        }

    }
    onSubmit({ value, valid }: { value: any, valid: boolean }) {
        if (valid) {
            console.log(value);
            this._dashboardService.UpdatePartNumber(value)
                .subscribe(
                (results: any) => {
                    this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                    this.rmsno = '';
                    this.partno = '';
                    this.UpdateForm.setValue({
                        RequestId: '',
                        OldItemId: '',
                        NewItemId: ''
                    })
                },
                error => {
                    this.errorMessage = <any>error;
                    this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                });
        }
        else {
            this.showErr = true;
        }
    }
}