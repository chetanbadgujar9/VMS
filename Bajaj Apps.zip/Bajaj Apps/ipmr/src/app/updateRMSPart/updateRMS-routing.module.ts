import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { UpdateRMSComponent } from './components/updateRMS.componen';

@NgModule({
  imports: [
    RouterModule.forChild([
      { path: 'updateRMSPart', component: UpdateRMSComponent }
    ])
  ],
  exports: [RouterModule]
})
export class UpdateRMSRoutingModule { }
