import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UpdateRMSComponent } from './components/updateRMS.componen';
import { UpdateRMSRoutingModule } from './updateRMS-routing.module';
import { BrowserModule } from '@angular/platform-browser';
import { SharedModule } from '../shared/shared.module';
@NgModule({
    imports: [CommonModule, UpdateRMSRoutingModule, SharedModule],
    declarations: [UpdateRMSComponent],
    exports: [UpdateRMSComponent],
    providers: []
})
export class UpdateRMSModule { }
