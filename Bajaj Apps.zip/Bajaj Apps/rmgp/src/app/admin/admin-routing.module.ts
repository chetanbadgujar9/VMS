import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AdminComponent } from './components/admin/admin.component';
import { SecurityComponent } from './components/security/security.component';
import { DesignationComponent } from './components/designation/designation.component';
import { ApproverComponent } from './components/approvers/approver.component';
import { GLComponent } from './components/GLApproval/GL.component';
import { RequestClosureComponent } from './components/requestClosure/requestClosure.component';
@NgModule({
  imports: [
    RouterModule.forChild([
          { path: 'admin', component: AdminComponent },
          { path: 'security', component: SecurityComponent },
          { path: 'designation', component: DesignationComponent },
          { path: 'GL', component: GLComponent },
          { path: 'closure', component: RequestClosureComponent },
          { path: 'approver', component: ApproverComponent }
    ])
  ],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
