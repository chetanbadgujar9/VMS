import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminComponent } from './components/admin/admin.component';
import { SecurityComponent } from './components/security/security.component';
import { DesignationComponent } from './components/designation/designation.component';
import { ApproverComponent } from './components/approvers/approver.component';
import { GLComponent } from './components/GLApproval/GL.component';
import { RequestClosureComponent } from './components/requestClosure/requestClosure.component';
import { AdminRoutingModule } from './admin-routing.module';
import { BrowserModule } from '@angular/platform-browser';
import { SharedModule } from '../shared/shared.module';
import { CommonService } from '../shared/services/common.service';
@NgModule({
    imports: [CommonModule, AdminRoutingModule, SharedModule],
    declarations: [AdminComponent, SecurityComponent, DesignationComponent, ApproverComponent, GLComponent, RequestClosureComponent],
    exports: [AdminComponent, SecurityComponent, DesignationComponent, GLComponent, ApproverComponent, RequestClosureComponent],
    providers: [CommonService]
})
export class AdminModule { }
