import { Component, OnInit, NgModule, trigger, transition, style, animate, state, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { MessageService } from '../../../shared/services/message.service';
import { CommonService } from '../../../shared/services/common.service';
import { ConfirmationService } from 'primeng/primeng';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SelectItem } from 'primeng/primeng';
import { DashboardService } from '../../../dashboard/services/dashboard.service';
import { Brand } from '../../model/brand';
import { RMGP } from '../../../dashboard/models/RMGP';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-GL',
    templateUrl: 'GL.component.html',
    styleUrls: ['GL.component.css'],
    providers: [ConfirmationService]
})
export class GLComponent implements OnInit {
    RMGPData: any[];
    cols: any[];
    columnOptions: any[];
    systemData: any[];
    groupData: any[];
    stageData: any[];
    testTypeData: any[];
    vehicleModelData: any[];
    SubSystemData: any[];
    subTypeData: any[];
    brandData: any[];
    projectData: any[];
    loggedInUserData: any = '';
    GLName: string;
    CHName: string;
    RequesterName: string;
    TestUserName: string;
    errorMessage: string;
    CHStatus: string;
    TestUserStatus: string;
    attachmentURL: string;
    TestType: string;
    showApproveRejectForm: boolean = false;
    errorFlagForApproveReject: boolean = false;
    ApproveButton: boolean = false;
    RejectButton: boolean = false;
    ApproveRejectRequestForm: FormGroup;
    Id: any = '';
    errorFlag: boolean = false;
    @Output() dashboardFlag = new EventEmitter();
    constructor(private _messageService: MessageService,
        private _commonService: CommonService,
        private _confirmationService: ConfirmationService,
        private _dashboardservice: DashboardService,
        private formBuilder: FormBuilder) {
    }
    ngOnInit() {
        this._messageService.AddDashboardFlag(false);
        this.setForm();
        this.getAllGLPendingRequest();
    }
    setForm() {
        this.ApproveRejectRequestForm = this.formBuilder.group({
            ID: [null],
            TRID: [null],
            Title: [null],
            TargetDate: [null],
            UGPGroup: [null],
            Brand: [null],
            Project: [null],
            Model: [null],
            Stage: [null],
            Group: [null],
            SubGroup: [null],
            PartNumber: [null],
            ModelNumber: [null],
            PartDescription: [null],
            Make: [null],
            TestType: [null],
            TestSubType: [null],
            TestStandards: [null],
            TestPurpose: [null],
            SetupDetails: [null],
            RequesterComments: [null],
            GLComments: ['', [Validators.required]]
        })
    }
   
    getAllGLPendingRequest() {
        this.RMGPData = [];
        this._commonService.getAllPendingGLRequest_Admin()
            .subscribe(
            (results: any) => {
                if (results.length > 0) {
                    this.RMGPData = results;
                }
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onApproveRequest(request:RMGP){
        let payload = {
          'ID':request.ID,
          'RaisedBy':request.RaisedBy,
          'CreatedBy':request.CreatedBy,
          'GroupLead_Approval': 'Approved'
        }
        this._commonService.glApproval_Admin(payload)
          .subscribe(
          (results: any) => {
            this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
            this.getAllGLPendingRequest()
          },
          error => {
            this.errorMessage = <any>error;
            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
          });
      }
      onRejectRequest(request:RMGP){
        let payload = {
          'ID':request.ID,
          'RaisedBy':request.RaisedBy,
          'CreatedBy':request.CreatedBy,
          'GroupLead_Approval': 'Rejected'
        }
        this._commonService.glApproval_Admin(payload)
          .subscribe(
          (results: any) => {
            this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
            this.getAllGLPendingRequest();
          },
          error => {
            this.errorMessage = <any>error;
            this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
          });
      }
    
   
}
