import { Component, OnInit, NgModule, trigger, transition, style, animate, state } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { MessageService } from '../../../shared/services/message.service';
import { CommonService } from '../../../shared/services/common.service';
import { ConfirmationService } from 'primeng/primeng';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SelectItem } from 'primeng/primeng';
import { Brand } from '../../model/brand';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-admin',
    templateUrl: 'admin.component.html',
    styleUrls: ['admin.component.css'],
    providers: [ConfirmationService]
})
export class AdminComponent implements OnInit {
    adminData: any[] = [];
    userData: any[];
    aData:any[];
    errorMessage: string;
    showAdminForm: boolean = false;
    AdminForm: FormGroup;
    Id: any = '';
    errorFlag: boolean = false;
    project: any;
    brand: any;
    constructor(private _messageService: MessageService,
        private _commonService: CommonService,
        private _confirmationService: ConfirmationService,
        private formBuilder: FormBuilder) {
    }
    ngOnInit() {
        this._messageService.AddDashboardFlag(false);
        this.setForm();
        this.getAdminList();
    }
    setForm() {
        this.AdminForm = this.formBuilder.group({
            Admin1: ['', [Validators.required]],
            Admin2: [''],
            Admin3: [''],
            Admin4: ['']
        });
    }
    onAddAdmin() {
        this.setForm();
        this.showAdminForm = true;
    }
    onCancel() {
        this.AdminForm.setValue({
            Admin1: '',
            Admin2: '',
            Admin3:'',
            Admin4:''
        })
        this.showAdminForm = false;
    }
    getAdminList() {
        this._commonService.getRMGPAdmin()
            .subscribe(
            (results: any) => {
                this.adminData = results;
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    getAssignToUsers(event: any) {
        let query = event.query;
        this._commonService.getAssignToUsers(query)
            .subscribe(
            (results: any) => {
                this.userData = results;
                //this.assignToUsers =[ {'ID':1,'name':'Amol'},{'ID':2,'name':'Amul'}];
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onEdit(brand: any) {
        this.showAdminForm = true;
        this.Id = brand.ID;
        this.AdminForm.setValue({
            Admin1: brand.Admin1 ? brand.Admin1.Name : '',
            Admin2: brand.Admin2 ? brand.Admin2.Name : '',
            Admin3: brand.Admin3 ? brand.Admin3.Name : '',
            Admin4: brand.Admin4 ? brand.Admin4.Name : ''
        });
    }
    onDelete(brand: any) {
        this._confirmationService.confirm({
            message: 'Are you sure that you want to delete?',
            accept: () => {
                this._commonService.deleteAdmin(brand)
                    .subscribe(
                    (results: any) => {
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getAdminList();
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
        });
        
    }
    onSubmit({ value, valid }: { value: any, valid: boolean }) {
        if (valid) {
            if (this.Id === '') {
                let payload = {'Admin1':{'Title':value.Admin1,'Name':value.Admin1,'Id':''},
                'Admin2':{'Title':value.Admin1,'Name':value.Admin1,'Id':''},
                'Admin3':{'Title':value.Admin1,'Name':value.Admin1,'Id':''},
                'Admin4':{'Title':value.Admin1,'Name':value.Admin1,'Id':''}}
                this._commonService.addAdmin(payload)
                    .subscribe(
                    (results: any) => {
                        this.Id = '';
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getAdminList();
                        this.showAdminForm = false;
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
            if (this.Id !== '') {
                value.ID = this.Id;
                let payload = {'Admin1':{'Title':value.Admin1,'Name':value.Admin1,'Id':value.Admin1},
                'Admin2':{'Title':value.Admin1,'Name':value.Admin1,'Id':value.Admin2},
                'Admin3':{'Title':value.Admin1,'Name':value.Admin1,'Id':value.Admin3},
                'Admin4':{'Title':value.Admin1,'Name':value.Admin1,'Id':value.Admin4}}
                this._commonService.updateAdmin(value)
                    .subscribe(
                    (results: any) => {
                        this.Id = '';
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getAdminList();
                        this.showAdminForm = false;
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }

        } else {
            this.errorFlag = true;
        }

    }
}
