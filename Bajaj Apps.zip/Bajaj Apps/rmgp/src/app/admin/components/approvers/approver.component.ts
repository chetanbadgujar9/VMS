import { Component, OnInit, NgModule, trigger, transition, style, animate, state } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { MessageService } from '../../../shared/services/message.service';
import { CommonService } from '../../../shared/services/common.service';
import { ConfirmationService } from 'primeng/primeng';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SelectItem } from 'primeng/primeng';
import { Brand } from '../../model/brand';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-approver',
    templateUrl: 'approver.component.html',
    styleUrls: ['approver.component.css'],
    providers: [ConfirmationService]
})
export class ApproverComponent implements OnInit {
    userData: any[];
    approvalList: any = [];
    designationList: any = [];
    errorMessage: string;
    showApproverForm: boolean = false;
    ApproverForm: FormGroup;
    Id: any = '';
    errorFlag: boolean = false;
    project: any;
    brand: any;
    constructor(private _messageService: MessageService,
        private _commonService: CommonService,
        private _confirmationService: ConfirmationService,
        private formBuilder: FormBuilder) {
    }
    ngOnInit() {
        this._messageService.AddDashboardFlag(false);
        this.setForm();
        this.getApproverList();
    }
    setForm() {
        this.ApproverForm = this.formBuilder.group({
            Title: ['', [Validators.required]],
            Designation: ['', [Validators.required]]
        });
    }
    onAddApprover() {
        this.getDesignation();
        this.setForm();
        this.showApproverForm = true;
        this.errorFlag = false;
    }
    getDesignation() {
        this._commonService.getDesignation()
            .subscribe(
            (results: any) => {
                this.designationList = results;
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onCancel() {
        this.showApproverForm = false;
    }
    getApproverList() {
        this._commonService.getApprovalList()
            .subscribe(
            (results: any) => {
                this.approvalList = results;
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    getAssignToUsers(event: any) {
        let query = event.query;
        this._commonService.getAssignToUsers(query)
            .subscribe(
            (results: any) => {
                this.userData = results;
                //this.assignToUsers =[ {'ID':1,'name':'Amol'},{'ID':2,'name':'Amul'}];
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onEdit(app: any) {
        this.showApproverForm = true;
        this.getDesignation();
        this.Id = app.ID;
        this.ApproverForm.setValue({
            Title: app.Title ? app.Title : '',
            Designation : app.Designation ? app.Designation  : ''
        });
    }
    onDelete(brand: any) {
        this._confirmationService.confirm({
            message: 'Are you sure that you want to delete?',
            accept: () => {
                this._commonService.deleteApprover(brand)
                    .subscribe(
                    (results: any) => {
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getApproverList();
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
        });
    }
    onSubmit({ value, valid }: { value: any, valid: boolean }) {
        if (valid) {
            if (this.Id === '') {
                let payload = {
                    'Approver': { 'Title': value.Title.Name, 'Name': value.Title.Name, 'Id': value.Title.ID },
                    'Title' : value.Title.Name,
                    'Designation': value.Designation
                };
                this._commonService.addApprover(payload)
                    .subscribe(
                    (results: any) => {
                        this.Id = '';
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getApproverList();
                        this.showApproverForm = false;
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
            if (this.Id !== '') {
                let payload = {
                    'Approver': { 'Title': value.Title.Name, 'Name': value.Title.Name, 'Id': value.Title.ID },
                    'Title' : value.Title.Name,
                    'Designation': value.Designation,
                    'ID' : this.Id
                };
                this._commonService.updateApprover(payload)
                    .subscribe(
                    (results: any) => {
                        this.Id = '';
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getApproverList();
                        this.showApproverForm = false;
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }

        } else {
            this.errorFlag = true;
        }

    }
}
