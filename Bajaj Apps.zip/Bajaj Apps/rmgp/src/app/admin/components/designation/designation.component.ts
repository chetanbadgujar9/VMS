import { Component, OnInit, NgModule, trigger, transition, style, animate, state, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { MessageService } from '../../../shared/services/message.service';
import { CommonService } from '../../../shared/services/common.service';
import { ConfirmationService } from 'primeng/primeng';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SelectItem } from 'primeng/primeng';
import { System } from '../../model/system';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-designation',
    templateUrl: 'designation.component.html',
    styleUrls: ['designation.component.css'],
    providers: [ConfirmationService]
})
export class DesignationComponent implements OnInit {
    DesignData: any[];
    errorMessage: string;
    showDesignForm: boolean = false;
    DesignForm: FormGroup;
    Id: any = '';
    errorFlag:boolean=false;
   // @Output() dashboardFlag = new EventEmitter();
    constructor(private _messageService: MessageService,
        private _commonService: CommonService,
        private _confirmationService: ConfirmationService,
        private formBuilder: FormBuilder) {
    }
    ngOnInit() {
        
        this._messageService.AddDashboardFlag(false);
        this.setForm();
        this.getDesignList();
    }
    setForm() {
        this.DesignForm = this.formBuilder.group({
            Title: ['', [Validators.required]]
        });
    }
    onAddDesign() {
        this.setForm();
        this.showDesignForm = true;
        this.errorFlag = false;
    }
    onCancel() {
        this.DesignForm.setValue({
            Title: '',
            
        })
        this.showDesignForm = false;
    }
    getDesignList() {
        this._commonService.getDesignation()
            .subscribe(
            (results: any) => {
                this.DesignData = results;
            },
            error => {
                this.errorMessage = <any>error;
                this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
            });
    }
    onEdit(system: any) {
        this.showDesignForm = true;
        this.Id = system.ID;
        this.DesignForm.setValue({
            Title: system.Title,
            
        })
    }
    
    onDelete(system: System) {
        this._confirmationService.confirm({
            message: 'Are you sure that you want to delete?',
            accept: () => {
                this._commonService.deleteDesignation(system)
                    .subscribe(
                    (results: any) => {
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getDesignList();
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
        });
       
    }
    onSubmit({ value, valid }: { value: any, valid: boolean }) {
        if (valid) {
            value.Title = value.Title ? value.Title.replace(/'/g, "\\'").trim() : '';
            if (this.Id === '') {
                this._commonService.addDesignation(value)
                    .subscribe(
                    (results: any) => {
                        this.Id = '';
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getDesignList();
                        this.showDesignForm = false;
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }
            if (this.Id !== '') {
                value.ID = this.Id;
                this._commonService.updateDesignation(value)
                    .subscribe(
                    (results: any) => {
                        this.Id = '';
                        this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results.Message });
                        this.getDesignList();
                        this.showDesignForm = false;
                    },
                    error => {
                        this.errorMessage = <any>error;
                        this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                    });
            }

        } else {
            this.errorFlag = true;
        }

    }
}
