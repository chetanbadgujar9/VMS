import { Component, OnInit, NgModule, trigger, transition, style, animate, state, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { MessageService } from '../../../shared/services/message.service';
import { CommonService } from '../../../shared/services/common.service';
import { ConfirmationService } from 'primeng/primeng';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SelectItem } from 'primeng/primeng';
import { RMGP } from '../../../dashboard/models/RMGP';
import { DashboardService } from '../../../dashboard/services/dashboard.service';
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
    moduleId: module.id,
    selector: 'sd-closure',
    templateUrl: 'requestClosure.component.html',
    styleUrls: ['requestClosure.component.css'],
    providers: [ConfirmationService]
})
export class RequestClosureComponent implements OnInit {
    RMGPData: any[];
    errorMessage: string;
    errorFlagForSearch: boolean = false;
    SearchRMGPForm: FormGroup;
    Id: any = '';
    filesData: any;
    fileName: string = '';
    constructor(private _messageService: MessageService,
        private _commonService: CommonService,
        private _confirmationService: ConfirmationService,
        private _dashboardService: DashboardService,
        private formBuilder: FormBuilder) {
        this.filesData = new Array<File>();
    }
    ngOnInit() {
        this.setSearchRMGPForm();
    }
    setSearchRMGPForm() {
        this.SearchRMGPForm = this.formBuilder.group({
            RMGPNO: ['', [Validators.required]]
        });
    }
    postFile(inputValue: any, type: string): void {
        var format = /[!@#$%^&*+\=\[\]{};':'\\|,.<>\/?]+/;
        try {
            let FileList: FileList = inputValue.target.files;
            if (FileList.length > 0) {
                if (inputValue.target.files[0].size < 10000000) {
                    if (inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'docx' ||
                        inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'doc' ||
                        inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'xls' ||
                        inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'xlsx' ||
                        inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'tif' ||
                        inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'tiff' ||
                        inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'gif' ||
                        inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'jpeg' ||
                        inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'jpg' ||
                        inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'png' ||
                        inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'pdf' ||
                        inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'ppt' ||
                        inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'pptx' ||
                        inputValue.target.files[0].name.split('.')[1].toLowerCase() === 'zip') {
                        if (!format.test(inputValue.target.files[0].name.split('.')[0])) {
                            this.filesData.length = 0;
                            for (let i = 0, length = FileList.length; i < length; i++) {
                                this.filesData.push(FileList.item(i));
                                this.fileName = FileList.item(i).name;
                            }
                        } else {
                            this._messageService.addMessage({
                                severity: 'error', summary: 'Error Message',
                                detail: 'Please remove special characters from filename'
                            });
                        }
                    } else {
                        this._messageService.addMessage({
                            severity: 'error', summary: 'Error Message',
                            detail: 'Please upload document of type of supperted type'
                        });
                    }
                } else {
                    this._messageService.addMessage({
                        severity: 'error', summary: 'Error Message',
                        detail: 'Please upload document of size less than 2 MB'
                    });
                }
            } else {
                //this.AttachmentURL = false;
                this.fileName = '';
            }
        } catch (error) {
            document.write(error);
        }

    }

    onSubmitEdit() {
        if (this.fileName !== '') {
            document.getElementById('fileError').style.display = "none";
            let payload = { 'ID': this.RMGPData[0].ID, 'RaisedBy': this.RMGPData[0].RaisedBy, 'CreatedBy': this.RMGPData[0].CreatedBy, 'Status': 'Closed', 'RMGP_Status': this.RMGPData[0].RMGP_Status }
            this._dashboardService.requesterClosureWithAttachment(payload, this.filesData).then(
                (results: any) => {
                    this._messageService.addMessage({ severity: 'success', summary: 'Success Message', detail: results });
                },
                (error: any) => {
                    this.errorMessage = <any>error;
                    this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                })
        }
        else {
            document.getElementById('fileError').innerHTML = "Please Select file to upload";
            document.getElementById('fileError').style.display = "block";
        }
    }
    onSubmitSearchRMGP({ value, valid }: { value: any, valid: boolean }) {
        if (valid) {
            this._dashboardService.getSearchResult(value.RMGPNO)
                .subscribe(
                (results: any) => {
                    if (results.length > 0) {
                        this.RMGPData = results;
                    }
                },
                error => {
                    this.errorMessage = <any>error;
                    this._messageService.addMessage({ severity: 'error', summary: 'Error Message', detail: this.errorMessage });
                });
        } else {
            this.errorFlagForSearch = true;
        }
    }
}
